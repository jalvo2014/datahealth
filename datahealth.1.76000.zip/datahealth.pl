#!/usr/local/bin/perl -w
#------------------------------------------------------------------------------
# Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2010, 2010
# All Rights Reserved US Government Users Restricted Rights - Use, duplication
# or disclosure restricted by GSA ADP Schedule Contract with IBM Corp
#------------------------------------------------------------------------------

#  perl datahealth.pl
#
#  Identify cases where TEMS database is inconsistent
#   Version 0.88000 checks TNODESAV, TNODELST, TSITDESC, TNAME, TOBJACCL
#
#  john alvord, IBM Corporation, 5 July 2014
#  jalvord@us.ibm.com
#
# tested on Windows Activestate 5.16.2
# Should work on Linux/Unix but not yet tested
#
#    # remember debug breakpoint
# $DB::single=2;   # remember debug breakpoint

## todos
#  QA1DAPPL     TAPPLPROPS  ??
#  QA1CSPRD     TUSER       ??
#  STSH - multi-row events... 001->998
# The pure event situation of the Extended Oracle Database agent does not fire on the subnode where the subnode ID is longer than or equal to 25 characters.
# https://eclient.lenexa.ibm.com:9445/search/?fetch=source/TechNote/1430630
# Identify cases where TEMA 32 bit *NE TEMA 64 bit level at a system
# when calculating send status, subtract hub TEMS reconnects

## calculate STSH wrap time

# When same system [ip address] but different hostname, advisory on unable to use remote deploy, also possible TEP issues.

# APAR: IV96304 - AIX Unix OS Agent only *MISSING process
# Risky if 6.3.7 IF<2  or 6.3.5 IF<8
# Require Persist=2
# Might belong in Situation Audit

# SP1 signal in cinfo.info
# Windows: Host Name  : USMDCEDAP6024         Installer : Ver: 063007060
# AIX: Host name : catrhom011itdxa-nim Installer Lvl:06.30.07.06
# Linux: Host name : hlxd00tm03_bak   Installer Lvl:06.30.07.06

# SP2 signam in cinfo.info
# Windows: Host Name  : ITM1101                                   Installer : Ver: 063007070

#use warnings::unused; # debug used to check for unused variables
use strict;
use warnings;

# See short history at end of module

my $gVersion = "1.76000";
my $gWin = (-e "C://") ? 1 : 0;    # 1=Windows, 0=Linux/Unix

use Data::Dumper;               # debug only

# a collection of variables which are used throughout the program.
# defined globally


# Requests to access, (insert or query), the TSITSTSH table at
# the Hub TEMS hang when EIF forwarding is enabled.
# When this happens, the TEP client becomes unresponsive if
# workspaces are opened that access the TSITSTSH table.
# Root cause :
# If the Host Name is missing from the HOSTADDR column in the
# INODESTS table, the EIF code attempts to determine the hostname
# from the IP address.
# While searching for the hostname, access to the TSITSTSH table
#  is restricted.
# If the request to determine the hostname does not complete
# quickly and if there is a sufficiently high number of events to
# emit, requests to the TSITSTSH begin to back up.
# This can cause requests from clients, such as TEP and an RTEMS,
# to take an excessively long time to complete.

my $args_start = join(" ",@ARGV);      # capture arguments for later processing
my $run_status = 0;                    # A count of pending runtime errors - used to allow multiple error detection before stopping process

# some common variables

my $rc;                                  # command return code
my @words = ();
my $rt;
my $ll;
my $pcount;
my $oneline;
my $sx;
my $i;
my $tlstdate;                            # tomorrow date expressed in ITM Stamp
my $top20;

my $outline;
my @oline;
my $cnt = -1;
my @sline;
my $scnt = -1;
my $f;

# forward declarations of subroutines

sub init;                                # read command line and ini file
sub logit;                               # queue one record to survey log
sub datadumperlog;                       # dump a variable using Dump::Data if installed
sub gettime;                             # get time
sub init_txt;                            # input from txt files
sub init_lst;                            # input from lst files
sub parse_lst;                           # parse the KfwSQLClient output
sub new_tnodesav;                        # process the TNODESAV columns
sub new_tnodelstv;                       # process the TNODELST NODETYPE=V records
sub new_tobjaccl;                        # process the TOBJACCL records
sub fill_tnodelstv;                      # reprocess new TNODELST NODETYPE=V data
sub valid_lstdate;                       # validate the LSTDATE
sub get_epoch;                           # convert from ITM timestamp to epoch seconds
sub sitgroup_get_sits;                   # calculate situations associated with Situation Group

my %asysnamex;
my %uadvx;
my %sit_tarx;
my %tar_nodex;

my %dupndx;

my %ms_offlinex;

my %pdtx;

my @grp;
my %grpx = ();
my @grp_sit = ();
my @grp_grp = ();
my @grp_name = ();
my %sum_sits;
my $gx;
my $grpi = -1;

my %ipx;

my $sitdata_start_time = gettime();     # formated current time for report


my %miss = ();                          # collection of missing cases

my %offline_agentx;
my %offline_thrunodex;
my %offline_productx;
my %offline_productversionx;
my %offline_temax;

# TNODELST type V record data           Alive records - list thrunode most importantly
my $vlx;                                # Access index
my $nlistvi = -1;                       # count of type V records
my @nlistv = ();                        # node name
my %nlistvx = ();                       # hash from name to index
my @nlistv_thrunode = ();               # agent thrunode
my @nlistv_tems = ();                   # TEMS if thrunode is agent
my @nlistv_ct = ();                     # count of agents
my @nlistv_lstdate = ();                # last update date
my @nlistv_sitx = ();                   # Situations running on Agent

# TNODELST type M record data           Managed Systemlists
my $mlx;
my $nlistmi = -1;
my @nlistm = ();
my %nlistmx = ();
my @nlistm_miss = ();
my @nlistm_nov = ();

my $mkey;
my $mlisti = -1;
my @mlist = ();
my %mlistx = ();
my @mlist_ct = ();
my @mlist_nodelist = ();
my @mlist_node = ();
my @mlist_lstdate = ();

my $nlx;
my $nlisti = -1;
my @nlist = ();
my %nlistx = ();
my @nlist_agents = ();


# TNODESAV record data                  Disk copy of INODESTS [mostly]
my $nsx;
my $nsavei = -1;
my @nsave = ();
my %nsavex = ();
my @nsave_product = ();
my @nsave_arch = ();
my @nsave_version = ();
my @nsave_subversion = ();
my @nsave_hostaddr = ();
my @nsave_hostinfo = ();
my @nsave_sysmsl = ();
my @nsave_ct = ();
my @nsave_o4online = ();
my @nsave_affinities = ();
my @nsave_temaver = ();
my @nsave_common = ();

my $nsave_online = 0;
my $nsave_offline = 0;

my %agtosx = ( 'NT' => 1,
               'LZ' => 1,
               'UX' => 1,
             );

# TNODESAV HOSTADDR duplications
my $hsx;
my $hsavei = -1;
my @hsave = ();
my %hsavex = ();
my @hsave_sav = ();
my @hsave_ndx = ();
my @hsave_ct = ();
my @hsave_thrundx = ();

my %sysnamex = ();

# TOBJACCL data
my %tobjaccl = ();
my %tgroupi = ();
my $obji = -1;
my @obj = ();
my %objx = ();
my @obj_objclass = ();
my @obj_objname = ();
my @obj_nodel = ();
my @obj_ct = ();
my @obj_lstdate = ();


my $tx;                                  # TEMS information
my $temsi = -1;                          # count of TEMS
my @tems = ();                           # Array of TEMS names
my %temsx = ();                          # Hash to TEMS index
my @tems_hub = ();                       # When 1, is the hub TEMS
my @tems_ct = ();                        # Count of managed systems
my @tems_ctnok = ();                     # Count of managed systems excluding OK at FTO hub TEMS
my @tems_version = ();                   # TEMS version number
my @tems_o4online = ();                  # TEMS online status
my @tems_arch = ();                      # TEMS architecture
my @tems_thrunode = ();                  # TEMS THRUNODE, when NODE=THRUNODE that is a hub TEMS
my @tems_hostaddr = ();                  # TEMS THRUNODE, when NODE=THRUNODE that is a hub TEMS
my @tems_affinities = ();                # TEMS AFFINITIES
my @tems_sampload = ();                  # Sampled Situaton dataserver load
my @tems_sampsit = ();                   # Sampled Situation Count
my @tems_puresit = ();                   # Pure Situation Count
my @tems_sampload_dedup = ();            # Sampled Situaton dataserver load - without duplicate PDTs
my @tems_sampsit_dedup = ();             # Sampled Situation Count - without duplicate PDTs
my @tems_puresit_dedup = ();             # Pure Situation Count - without duplicate PDTs
my @tems_sits = ();                      # Situations hash
my @tems_vtbl = ();                      # Virtual Hub Table hash
my @tems_spipe = ();                     # Virtual Hub Table hash
my $hub_tems = "";                       # hub TEMS nodeid
my $hub_tems_version = "";               # hub TEMS version
my $hub_tems_no_tnodesav = 0;            # hub TEMS nodeid missing from TNODESAV
my $hub_tems_ct = 0;                     # total agents managed by a hub TEMS
my $tems_vtbl_ref;

my $affchars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz*#";

my %tepsx;
my $tepsi = -1;
my @teps = ();
my @teps_version = ();
my @teps_arch = ();

my %ka4x;
my $ka4i = -1;
my @ka4 = ();
my @ka4_product = ();
my @ka4_version = ();
my @ka4_version_count = ();

my $mx;                                  # index
my $magenti = -1;                        # count of managing agents
my @magent = ();                         # name of managing agent
my %magentx = ();                        # hash from managing agent name to index
my @magent_subct = ();                   # count of subnode agents
my @magent_sublen = ();                  # length of subnode agent list
my @magent_tems_version = ();            # version of managing agent TEMS
my @magent_tems = ();                    # TEMS name where managing agent reports

my %pcx;                                 # Product Summary hash

# allow user to set impact
my %advcx = (
              "DATAHEALTH1001E" => "100",
              "DATAHEALTH1002E" => "90",
              "DATAHEALTH1003I" => "0",
              "DATAHEALTH1004I" => "0",
              "DATAHEALTH1005W" => "75",
              "DATAHEALTH1006W" => "75",
              "DATAHEALTH1007E" => "105",
              "DATAHEALTH1008E" => "105",
              "DATAHEALTH1009E" => "105",
              "DATAHEALTH1010W" => "80",
              "DATAHEALTH1011E" => "105",
              "DATAHEALTH1012E" => "105",
              "DATAHEALTH1013W" => "10",
              "DATAHEALTH1014W" => "10",
              "DATAHEALTH1015W" => "9",
              "DATAHEALTH1016E" => "50",
              "DATAHEALTH1017E" => "50",
              "DATAHEALTH1018W" => "90",
              "DATAHEALTH1019W" => "10",
              "DATAHEALTH1020W" => "80",
              "DATAHEALTH1021E" => "105",
              "DATAHEALTH1022E" => "105",
              "DATAHEALTH1023W" => "00",
              "DATAHEALTH1024E" => "90",
              "DATAHEALTH1025E" => "0",
              "DATAHEALTH1026E" => "50",
              "DATAHEALTH1027E" => "50",
              "DATAHEALTH1028E" => "105",
              "DATAHEALTH1029W" => "0",
              "DATAHEALTH1030W" => "0",
              "DATAHEALTH1031E" => "50",
              "DATAHEALTH1032E" => "50",
              "DATAHEALTH1033E" => "50",
              "DATAHEALTH1034W" => "10",
              "DATAHEALTH1035W" => "0",
              "DATAHEALTH1036E" => "25",
              "DATAHEALTH1037W" => "25",
              "DATAHEALTH1038E" => "105",
              "DATAHEALTH1039E" => "100",
              "DATAHEALTH1040E" => "100",
              "DATAHEALTH1041W" => "10",
              "DATAHEALTH1042E" => "90",
              "DATAHEALTH1043E" => "100",
              "DATAHEALTH1044E" => "100",
              "DATAHEALTH1045E" => "100",
              "DATAHEALTH1046W" => "90",
              "DATAHEALTH1047E" => "20",
              "DATAHEALTH1048E" => "110",
              "DATAHEALTH1049W" => "25",
              "DATAHEALTH1050W" => "25",
              "DATAHEALTH1051W" => "25",
              "DATAHEALTH1052W" => "25",
              "DATAHEALTH1053E" => "20",
              "DATAHEALTH1054E" => "105",
              "DATAHEALTH1055E" => "10",
              "DATAHEALTH1056E" => "100",
              "DATAHEALTH1057E" => "100",
              "DATAHEALTH1058E" => "105",
              "DATAHEALTH1059E" => "105",
              "DATAHEALTH1060E" => "20",
              "DATAHEALTH1061E" => "75",
              "DATAHEALTH1062E" => "75",
              "DATAHEALTH1063W" => "10",
              "DATAHEALTH1064W" => "50",
              "DATAHEALTH1065W" => "10",
              "DATAHEALTH1066W" => "10",
              "DATAHEALTH1067E" => "110",
              "DATAHEALTH1068E" => "90",
              "DATAHEALTH1069E" => "100",
              "DATAHEALTH1070W" => "50",
              "DATAHEALTH1071W" => "20",
              "DATAHEALTH1072W" => "20",
              "DATAHEALTH1073W" => "25",
              "DATAHEALTH1074W" => "90",
              "DATAHEALTH1075W" => "60",
              "DATAHEALTH1076W" => "50",
              "DATAHEALTH1077E" => "100",
              "DATAHEALTH1078W" => "0",
              "DATAHEALTH1079E" => "50",
              "DATAHEALTH1080W" => "95",
              "DATAHEALTH1081W" => "75",
              "DATAHEALTH1082W" => "55",
              "DATAHEALTH1083W" => "75",
              "DATAHEALTH1084W" => "55",
              "DATAHEALTH1085W" => "95",
              "DATAHEALTH1086W" => "90",
              "DATAHEALTH1087E" => "100",
              "DATAHEALTH1088W" => "100",
              "DATAHEALTH1089E" => "100",
              "DATAHEALTH1090W" => "80",
              "DATAHEALTH1091W" => "95",
              "DATAHEALTH1092W" => "85",
              "DATAHEALTH1093W" => "75",
              "DATAHEALTH1094W" => "95",
              "DATAHEALTH1095W" => "100",
              "DATAHEALTH1096W" => "80",
              "DATAHEALTH1097W" => "50",
              "DATAHEALTH1098E" => "100",
              "DATAHEALTH1099W" => "25",
              "DATAHEALTH1100W" => "25",
              "DATAHEALTH1101E" => "25",
              "DATAHEALTH1102W" => "10",
              "DATAHEALTH1103W" => "90",
              "DATAHEALTH1104E" => "100",
              "DATAHEALTH1105E" => "100",
              "DATAHEALTH1106W" => "60",
              "DATAHEALTH1107W" => "96",
              "DATAHEALTH1108W" => "50",
              "DATAHEALTH1109W" => "90",
              "DATAHEALTH1110W" => "95",
              "DATAHEALTH1111W" => "95",
              "DATAHEALTH1112W" => "25",
              "DATAHEALTH1113W" => "75",
              "DATAHEALTH1114E" => "100",
              "DATAHEALTH1115W" => "95",
              "DATAHEALTH1116W" => "95",
            );


# known product codes - from many sources
my %knownpc = (
                 "06" => "Monitoring Agent for GSMA BlueCARE Windows OS",
                 "07" => "Monitoring Agent for GSMA BlueCARE AIX OS",
                 "08" => "Monitoring Agent for GSMA BlueCARE Linux OS",
                 "09" => "Monitoring Agent for GSMA BlueCARE Solaris OS",
                 "10" => "Monitoring Agent for GSMA BlueCARE HP-UX OS",
                 "13" => "Monitoring Agent for GSMA BLUECARE TSM",
                 "14" => "Monitoring Agent for GSMA BlueCARE TWS",
                 "24" => "Monitoring Agent for TWS Logs",
                 "87" => "Monitoring Agent for GSMA Symantec SE Agent",
                 "1B" => "Monitoring Agent for JBOSS EAP 5.1",
                 "2N" => "Agentless Agent",
                 "3Z" => "Monitoring Agent for Active Directory",
                 "4S" => "Monitoring Agent for SSL Certificate Expiration Agent",
                 "5D" => "Monitoring Agent for Unix SAN Multipath",
                 "5E" => "Monitoring Agent for Windows SAN Multipath",
                 "5I" => "Monitoring Agent for Sybase IQ DB",
                 "A2" => "AF/Remote Alert Adapter",
                 "A4" => "Monitoring Agent for i5/OS",
                 "AD" => "Active Directory",
                 "AH" => "System Automation for z/OS",
                 "AM" => "IBM Tivoli Alert Adapter for OMEGACENTER Gateway",
                 "AS" => "Tivoli Enterprise Monitoring Automation Server",
                 "AU" => "CA-Unicenter Alert Emitter",
                 "AX" => "IBM Tivoli Monitoring Shared Libraries",
                 "B2" => "Monitoring Agent for Symantec Endpoint Protection",
                 "BB" => "RAS1 programming building blocks",
                 "BC" => "ITCAM System Edition for WebSphere DataPower",
                 "BL" => "CASP Directory Server Monitoring Agent",
                 "BN" => "ITCAM Agent for WebSphere DataPower Appliance",
                 "BR" => "CASP Exchange Connector Monitoring Agent",
                 "BS" => "Basic Services",
                 "C2" => "OMEGAMON II for CICS",
                 "C3" => "IBM Tivoli Monitoring for CICS",
                 "C5" => "IBM Tivoli OMEGAMON XE for CICS on z/OS",
                 "CA" => "Agent Management Services Watchdog",
                 "CE" => "Candle Technology Engine",
                 "CF" => "TEMS Configurator",
                 "CG" => "IBM Tivoli Monitoring for Cryptographic Coprocessors",
                 "CI" => "IBM Tivoli Monitoring Product Installer",
                 "CICATRSQ" => "IBM Tivoli Monitoring SQL Files",
                 "CIENV" => "IBM Tivoli Monitoring Product Installer",
                 "CJ" => "Tivoli Enterprise Portal Desktop Client",
                 "CO" => "Command and Control",
                 "CP" => "IBM Tivoli Monitoring for CICS",
                 "CQ" => "Tivoli Enterprise Portal Server",
                 "CU" => "ICU globalization support",
                 "CW" => "Tivoli Enterprise Portal Browser Client",
                 "CZ" => "IBM Tivoli Monitoring CommandPro",
                 "D3" => "IBM Tivoli Monitoring for DB2",
                 "D4" => "ITCAM for SOA",
                 "D5" => "OMEGAMON XE for PE and PM on z/OS",
                 "D9" => "ITM Systems Director",
                 "DC" => "distributed communications",
                 "DD" => "Distributed Database common",
                 "DE" => "distributed communications transport protocol",
                 "DF" => "OMEGAMON II for SMS",
                 "DH" => "Internet http server",
                 "DO" => "IBM Tivoli Decision Support for z/OS",
                 "DP" => "IBM Tivoli OMEGAMON XE for DB2",
                 "DS" => "Tivoli Enterprise Management Server",
                 "DY" => "remote deploy (os agent only)",
                 "E1" => "Monitoring Agent for OPC Servers",
                 "E3" => "R/3 Clients (for ETEWatch) Monitoring Agent",
                 "E4" => "Siemens APOGEE Agent",
                 "E5" => "OSIsoft PI Agent",
                 "E6" => "Johnson Controls Metasys Agent",
                 "E7" => "APC InfraStruXure Agent",
                 "E8" => "Eaton Power Xpert Agent",
                 "E9" => "Active Energy Manager Agent",
                 "EA" => "Internet Monitoring Agent",
                 "EL" => "Lotus Notes Clients (for ETEWatch) Monitoring Agent",
                 "EM" => "Event manager",
                 "EN" => "SNMP Gateway on Windows NT",
                 "ER" => "Management Agent for Tivoli Enterprise Console Gateway",
                 "ES" => "EIF to WS-Notification",
                 "ET" => "End-to-End",
                 "EU" => "Custom Clients (for ETEWatch) Monitoring Agent",
                 "EW" => "Web Browsers (for ETEWatch) Monitoring Agent",
                 "EX" => "Monitoring Agent for Microsoft Exchange Server",
                 "EZ" => "OMA for eBA Solutions",
                 "FN" => "Monitoring Agent for Tivoli Management Framework",
                 "FW" => "Windows NT Tivoli Enterprise Portal",
                 "GA" => "SNMP Gateway on AIX",
                 "GB" => "IBM Tivoli Monitoring for Domino",
                 "GL" => "general library",
                 "GR" => "Graphics and Sound Library for TEP",
                 "GS" => "IBM GSKit Security Interface",
                 "GW" => "OMEGAMON XE for CICS TG on z/OS",
                 "H8" => "Monitoring Agent for Hadoop",
                 "HC" => "HMC Alert Adapter",
                 "HD" => "Warehouse Proxy",
                 "HI" => "HP OpenView IT/Operations Alert Adapter",
                 "HL" => "IBM OMEGAMON z/OS Management Console",
                 "HO" => "HP OpenView NNM Alert Adapter",
                 "HT" => "Monitoring Agent for Web Servers",
                 "HV" => "Monitoring Agent for Microsoft Hyper-V Server",
                 "I2" => "OMEGAMON II for IMS",
                 "I3" => "IBM Tivoli OMEGAMON XE for IMS",
                 "I5" => "OMEGAMON XE for IMS on z/OS",
                 "IC" => "OMEGAMON XE for WebSphere Interchange Server",
                 "IE" => "WebSphere InterChange Server Data Source",
                 "IH" => "OpenView ITO Alert Emitter",
                 "II" => "IBM Installation Manager",
                 "IP" => "OMEGAMON XE for IMS on z/OS",
                 "IS" => "IBM Tivoli Composite Application Manager for Internet Service Monitoring",
                 "IT" => "TEC GUI Integration",
                 "IU" => "BM HTTP Server",
                 "IV" => "IBM Tivoli Enterprise Portal Server Extensions Update",
                 "IW" => "IBM Tivoli Enterprise Portal Server Extensions",
                 "JJ" => "IBM OMEGAMON for JVM on z/OS",
                 "JM" => "Embedded JVM",
                 "JR" => "Tivoli Enterprise-supplied JRE",
                 "JS" => "Monitoring Agent for mySAP JMX",
                 "JU" => "Monitoring Agent for JMX JSR-77",
                 "K3" => "ITCAM TXN MB DC",
                 "K4" => ".NET�Data�Collector",
                 "KA" => "Monitoring Agent for Tivoli Enterprise Console",
                 "KF" => "IBM Eclipse Help Server",
                 "KJ" => "SCM Mongo Database",
                 "KM" => "SCM Ruby Database",
                 "KT" => "ITCAM for Response Time Enabler on z/OS",
                 "LA" => "IBM Tivoli LAP tool",
                 "LN" => "Lotus Notes Monitoring Agent",
                 "LO" => "Monitoring Agent for Netcool-OMNIbus Logfiles",
                 "LV" => "ITMS:Engine",
                 "LX" => "POSIX pthread mapping service",
                 "LZ" => "Monitoring Agent for Linux OS",
                 "M1" => "Discovery and Deployment",
                 "M2" => "OMEGAMON II for MVS",
                 "M3" => "IBM Tivoli Monitoring for OS/390",
                 "M5" => "IBM Tivoli OMEGAMON XE for z/OS",
                 "M6" => "ITCAM Agent for WebSphere MQ File Transfer Edition",
                 "MA" => "Remedy ARS Alert Adapter",
                 "MC" => "WebSphere MQ Configuration",
                 "MD" => "PQEdit",
                 "MQ" => "Monitoring for Websphere MQ",
                 "MV" => "OMEGAVIEW",
                 "MS" => "Tivoli Enterprise Monitoring Server",
                 "N3" => "IBM Tivoli OMEGAMON XE for Mainframe Networks",
                 "N4" => "Monitoring Agent for Network Devices",
                 "NA" => "IBM Tivoli NetView for z/OS Enterprise Management Agent",
                 "ND" => "Monitoring Agent for Tivoli NetView Server",
                 "NJ" => "Node.js",
                 "NO" => "Tivoli Omnibus ObjectServer Agent",
                 "NP" => "IBM Tivoli Network Manager",
                 "NT" => "Monitoring Agent for Windows OS",
                 "NU" => "Monitoring Agent for NetApp Storage",
                 "NV" => "IBM Tivoli OMEGAMON Alert Manager For TME10 NetView",
                 "NW" => "Novell NetWare Monitoring Agent",
                 "OB" => "OMNIMON BASE",
                 "OE" => "CCC for OS/390 Unix System Services",
                 "OF" => "Monitoring Agent for AFOper",
                 "ON" => "OMEGAMON II for Mainframe Network",
                 "OQ" => "Monitoring Agent for Microsoft SQL Server",
                 "OR" => "Monitoring Agent for Oracle",
                 "OS" => "IBM Tivoli Monitoring for Sysplex",
                 "OX" => "Informix Monitoring Agent",
                 "OY" => "Monitoring Agent for Sybase Server",
                 "P0" => "Tivoli Performance Analyzer Domain for DB2",
                 "P1" => "Monitoring Agent for TPC",
                 "P3" => "Tivoli Performance Analyzer Domain for OS agent",
                 "P4" => "Tivoli Performance Analyzer Domain for Oracle",
                 "P5" => "Base Monitoring Agent for AIX",
                 "P6" => "Tivoli Performance Analyzer Domain for System P",
                 "P8" => "ITCAM Agent for PeopleSoft Enterprise Application Domain",
                 "P9" => "ITCAM Agent for PeopleSoft Enterprise Process Scheduler",
                 "PA" => "Performance Analytics for TEP",
                 "PC" => "DEC Polycenter Alert Adapter",
                 "PE" => "MonitorFng Agent for Provisioning",
                 "PG" => "Python",
                 "PH" => "Base Monitoring Agent for HMC",
                 "PI" => "Tivoli Performance Analyzer Domain for ITCAM RT",
                 "PK" => "Base Monitoring Agent for CEC",
                 "PL" => "CandleLight Workstation",
                 "PS" => "PeopleSoft Monitoring Agent",
                 "PT" => "Peregrine ServiceCenter Alert Adapter",
                 "PU" => "Tivoli Performance Analyzer Domain for VMware",
                 "PV" => "Base Monitoring Agent for VIOS",
                 "PX" => "Premium Monitoring Agent for AIX",
                 "Q4" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: ISA Server 2004",
                 "Q5" => "Monitoring Agent for Microsoft Cluster Server",
                 "Q7" => "Microsoft Internet Information Services (IIS) Agent",
                 "Q8" => "Monitoring Agent for IBM PureApplication System",
                 "Q9" => "agent pureapplication",
                 "QA" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: ISA Server 2000",
                 "QB" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: BizTalk Server",
                 "QC" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: Commerce Server",
                 "QD" => "IBM Tivoli Monitoring for IBM Director",
                 "QF" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: .NET Framework",
                 "QH" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: Host Integration Server",
                 "QI" => "Monitoring for WebSphere Integration Brokers",
                 "QL" => "Monitoring Agent for Microsoft Lync Server",
                 "QP" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: SharePoint Portal Server",
                 "QQ" => "IBM DB2 Query Monitor for z/OS",
                 "QR" => "Monitoring Agent for Microsoft Virtual Server",
                 "QS" => "Monitoring Agent for IBM Workload Scheduler",
                 "QT" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: Content Management Server",
                 "QU" => "IBM Tivoli OMEGAMON XE for Microsoft .NET: UDDI Services",
                 "QV" => "Monitoring Agent for VMware ESX",
                 "QX" => "Monitoring Agent for Citrix Access Suite",
                 "R0" => "Agentless Monitoring for Dell OpenManage Hardware",
                 "R2" => "Agentless Monitoring for Windows Operating Systems",
                 "R3" => "Agentless Monitoring for AIX Operating Systems",
                 "R4" => "Agentless Monitoring for Linux Operating Systems",
                 "R5" => "Agentless Monitoring for HP-UX Operating Systems",
                 "R6" => "Agentless Monitoring for Solaris Operating Systems",
                 "R7" => "Agentless Monitoring for HP InsightManager Hardware",
                 "R8" => "Agentless Monitoring for Sun Management Center Hardware",
                 "R9" => "Business System Manager Common Agent",
                 "RA" => "distributed agent remote manager",
                 "RC" => "IBM Tivoli Monitoring for Rational Applications",
                 "RG" => "IBM Tivoli Advanced Audit for DFSMShsm",
                 "RH" => "IBM Tivoli Advanced Reporting for DFSMShsm",
                 "RJ" => "IBM Tivoli Allocation Optimizer for z/OS",
                 "RK" => "IBM Tivoli Automated Tape Allocation Manager",
                 "RN" => "IBM Tivoli Advanced Catalog Management for z/OS",
                 "RV" => "IBM Tivoli Advanced Backup and Recovery for z/OS",
                 "RW" => "IBM Tivoli Tape Optimizer",
                 "RZ" => "ITCAM Extended Agent for Oracle Database",
                 "S1" => "ITCAM Lotus Sametime Agent",
                 "S2" => "OS/2 Monitoring Agent",
                 "S3" => "IBM Tivoli OMEGAMON XE for SMS",
                 "S7" => "Monitoring Agent for SAP HANA Database",
                 "SA" => "IBM Tivoli OMEGAMON XE for R/3",
                 "SB" => "shared probes",
                 "SD" => "Status Data Manager",
                 "SE" => "Monitoring Agent for MySQL",
                 "SG" => "Monitoring agent for OpenStack",
                 "SH" => "Tivoli Enterprise Monitoring SOAP Server",
                 "SJ" => "Best Practices for WebSphere",
                 "SK" => "Reporting Agent for Tivoli Storage Manager",
                 "SL" => "ITCAM for MS Apps Discovery and Launchpad",
                 "SP" => "SNMP Alert Adapter",
                 "SR" => "IBM Tivoli Service Level Advisor",
                 "SS" => "Windows NT SNA Server Monitoring Agent",
                 "SY" => "Summarization and Pruning Agent",
                 "T1" => "ITCAM File Transfer Enablement",
                 "T2" => "ITCAM for Response Time Tracking",
                 "T3" => "ITCAM Application Management Console (AMC)",
                 "T4" => "ITCAM for Client Response Time (CRT) Agent",
                 "T5" => "ITCAM for Web Response Time (WRT) Agent",
                 "T6" => "ITCAM for Robotic Response Time (RRT) Agent",
                 "T7" => "ITCAM for TXN CICS TX DC",
                 "TH" => "ITCAM for MQ Tracking",
                 "TJ" => "K4/QF",
                 "TL" => "Omegamon XE for Message Transaction Tracker",
                 "TM" => "Monitoring Agent for IBM Tivoli Monitoring 5.x Endpoint",
                 "TN" => "Unicenter TNG Alert Emitter",
                 "TO" => "ITCAM Transaction Reporter",
                 "TR" => "IBM Tivoli OMEGAMON Alert Emitter For TME10 NetView",
                 "TU" => "ITCAM Transaction Collector",
                 "TV" => "Tivoli Enterprise Console Alert Adapter",
                 "TX" => "Tuxedo Monitoring Agent",
                 "UA" => "CA-Unicenter Alert Adapter",
                 "UB" => "IBM Tivoli Monitoring for Applications: Siebel Agent",
                 "UD" => "IBM Tivoli Composite Application Manager Agent for DB2",
                 "UE" => "Tivoli Enterprise Services User Interface Extensions",
                 "UF" => "Universal Agent Framework",
                 "UI" => "Tivoli Enterprise Services User Interface",
                 "UJ" => "Unison Maestro Alert Adapter",
                 "UL" => "Monitoring Agent for UNIX Logs",
                 "UM" => "Universal Agent",
                 "UR" => "Unison RoadRuner Alert Adapter",
                 "UT" => "Unicenter TNG Alert Adapter",
                 "UX" => "Monitoring Agent for UNIX OS",
                 "V1" => "Monitoring Agent for Linux Kernel-based Virtual Machines",
                 "V5" => "Citrix XenDesktop Agent",
                 "V6" => "Cisco (UCS) Agent",
                 "VA" => "Premium Monitoring Agent for VIOS",
                 "VD" => "Citrix Virtual Desktop Infrastructure",
                 "VI" => "HP OpenView Alert Emitter",
                 "VL" => "OMEGAMON XE on z/VM and Linux",
                 "VM" => "IBM Tivoli Monitoring for Virtual Servers",
                 "VT" => "Tivoli Enterprise Console Alert Emitter",
                 "VW" => "NetView for z/OS Agent Support",
                 "W0" => "RICOH Monitoring for Multi-function",
                 "W2" => "IBM Message Service Client Library",
                 "W3" => "RICOH Monitoring for Device Profiler for Multi-function",
                 "WE" => "OMEGAMON XE for Websphere Application Server on Distributed Systems",
                 "WJ" => "IBM Tivoli Composite Application Manager Common Components",
                 "WL" => "BEA Weblogic Server Monitoring Agent",
                 "WO" => "IBM Tivoli Monitoring for OMEGAVIEW II for the Enterprise",
                 "WW" => "OMEGAMON XE for WebSphere Application Server on OS/390",
                 "YB" => "IBM Tivoli Information Management for z/OS",
                 "XA" => "Citrix XenApp Agent",
                 "XB" => "CMA/XML support libraries",
                 "XF" => "Ping Probe",
                 "XH" => "PHP",
                 "XI" => "Monitoring Agent for Citrix XenServer",
                 "XY" => "Editor for Messages",
                 "YB" => "IBM Tivoli Information Management for z/OS",
                 "YJ" => "Monitoring Agent for J2EE",
                 "YN" => "ITCAM for Web Resources",
                 "ZA" => "Monitoring Agent for TADDM Serviceabily",
                 "ZE" => "Tivoli zEnterprise Monitoring Agent",
              );

my %advtextx = ();
my $advkey = "";
my $advtext = "";
my $advline;
my %advgotx = ();
my %advrptx = ();

my $advi = -1;
my @advonline = ();
my @advsit = ();
my @advimpact = ();
my @advcode = ();
my %advx = ();


my $hubi;
my $max_impact = 0;
my $isFTO = 0;
my %FTOver = ();

my $test_node;
my $invalid_node;
my $invalid_affinities;


my $key;
my $vtx;                                 # index
my $vti = -1;                            # count of node types affecting virtual hub table
my @vtnode = ();                         # virtual hub table agent type
my %vtnodex = ();                        # virtual hub table agent index
my @vtnode_rate = ();                    # how many minutes apart
my @vtnode_tab = ();                     # number of virtual hub tables updates found in *SYN autostart mode
my @vtnode_ct = ();                      # count of virtual table hub agents
my @vtnode_hr = ();                      # virtual hub table updates per hour
my $vtnode_tot_ct = 0;                   # total count of virtual table hub agents
my $vtnode_tot_hr = 0;                   # total virtual hub table updates per hour
my $vtnodes = "";                        # list of node types affecting virtual hub table updates

# initialize above table
$vti = 0;$key="UX";$vtnode[$vti]=$key;$vtnodex{$key}=$vti;$vtnode_rate[$vti]=3;$vtnode_tab[$vti]=0;$vtnode_ct[$vti]=0;$vtnode_hr[$vti]=0;
$vti = 1;$key="OQ";$vtnode[$vti]=$key;$vtnodex{$key}=$vti;$vtnode_rate[$vti]=2;$vtnode_tab[$vti]=0;$vtnode_ct[$vti]=0;$vtnode_hr[$vti]=0;
$vti = 2;$key="OR";$vtnode[$vti]=$key;$vtnodex{$key}=$vti;$vtnode_rate[$vti]=2;$vtnode_tab[$vti]=0;$vtnode_ct[$vti]=0;$vtnode_hr[$vti]=0;
$vti = 3;$key="OY";$vtnode[$vti]=$key;$vtnodex{$key}=$vti;$vtnode_rate[$vti]=2;$vtnode_tab[$vti]=0;$vtnode_ct[$vti]=0;$vtnode_hr[$vti]=0;
$vti = 4;$key="Q5";$vtnode[$vti]=$key;$vtnodex{$key}=$vti;$vtnode_rate[$vti]=1;$vtnode_tab[$vti]=0;$vtnode_ct[$vti]=0;$vtnode_hr[$vti]=0;
$vti = 5;$key="HV";$vtnode[$vti]=$key;$vtnodex{$key}=$vti;$vtnode_rate[$vti]=2;$vtnode_tab[$vti]=0;$vtnode_ct[$vti]=0;$vtnode_hr[$vti]=0;

my %hSP2OS = (
   UADVISOR_OMUNX_SP2OS => 'UX',
   UADVISOR_KOQ_VKOQDBMIR => 'OQ',
   UADVISOR_KOQ_VKOQLSDBD => 'OQ',
   UADVISOR_KOQ_VKOQSRVR => 'OQ',
   UADVISOR_KOQ_VKOQSRVRE => 'OQ',
   UADVISOR_KOR_VKORSRVRE => 'OR',
   UADVISOR_KOR_VKORSTATE => 'OR',
   UADVISOR_KOY_VKOYSRVR => 'OY',
   UADVISOR_KOY_VKOYSRVRE => 'OY',
   UADVISOR_KQ5_VKQ5CLUSUM => 'Q5',
   UADVISOR_KHV_VKHVHYPERV => 'HV',
);

my $snx;

my %hnodelist = (
   KKT3S => '*EM_SERVER_DB',                                     # T3
   KKYJW => '*CAM_J2EE_WLS_SERVER',                              # YJ
   KWMI => '*IBM_RemoteWinOS_WMI',                               # R2
   KR2 => '*IBM_RemoteWinOS',                                    # R2
   KRZ => '*IBM_OracleAgents',                                   # RZ
   KEX => '*NT_EXCHANGE',                                        # EX
   KRDB => '*IBM_OracleAgentRD',                                 # RZ
   KSVR => '*HMC_BASE_SERVERS',                                  # SVR
   KM6 => '*IBM_WM',                                             # M6
   KFTE => '*IBM_WMQFTEAgent',                                   # FTE
   KVM => '*VMWARE_VI_AGENT',                                    # VM
   KT5 => '*EM_WRM',                                             # T5
   KT3 => '*EM_DB',                                              # T3
   KQS => '*IBM_KQS',                                            # QS
   KIS => '*NETCOOL_ISM_AGENT',                                  # IS
   KUD => '*UNIVERSAL_DATABASE',                                 # UD
   KQ8 => '*IBM_IPAS_A',                                         # Q8
   KQ7 => '*IBM_IIS',                                            # Q7
   KQ5 => '*MS_CLUSTER',                                         # Q5
   KR3 => '*IBM_RmtAIXOS',                                       # R3
   KMSS => '*MS_SQL_SERVER',                                     # OQ
   KORA => '*ALL_ORACLE',                                        # OR
   KKA4 => '*OS400_OM',                                          # A4
   KTO => '*IBM_ITCAMfT_KTO',                                    # TO
   KIns => '*SAP_R3',                                            # SA
   KNT => '*NT_SYSTEM',                                          # NT
   KKT3A => '*EM_APPLICATION_DB',                                # T3
   KESX => '*VMWARE_VI',                                         # ES
   KTEPS => '*TEPS',                                             # CQ
   KKSDSDE => '*SDMSESS',                                        # SD
   KMQQSG => '*MQ_QSG',                                          # MQ
   KKHTA => '*ITCAM_WEB_SERVER_AGENT',                           # HT
   KR4 => '*IBM_RLinuxOS',                                       # R4
   KTU => '*IBM_KTU',                                            # TU
   KBN => '*IBM_KBN' ,                                           # BN
   KOS => '*CS_K0S',                                             # OS
     # 0S:custommq:M05 *CS_K0SM05
   KCPIRA => '*CPIRA_MGR',                                       # CP
   KKYNT => '*CAM_WAS_PROCESS_SERVER',                           # KY
   KKYJT => '*CAM_J2EE_TOMCAT_SERVER',                           # KJ
   KKHTP => '*CAM_APACHE_WEB_SERVER',                            # KH
   KD4 => '*SERVICES_MANAGEMENT_AGENT',                          # D4
     # D4:06c17c5e:nzxpap159-Prod-NCAL  M        *SERVICES_MANAGEMENT_AGENT_ENVIR
   KLO => '*IBM_KLO',                                            # LO
     # LO:nzapps5_OMPlus =>  *IBM_KLOpro
   K07 => '*GSMA_K07',                                           # 07
   KCONFIG => '*GENERIC_CONFIG',                                 # CF
   KDB2 => '*MVS_DB2',                                           # D5
   KGB => '*LOTUS_DOMINO',                                       # GB
   KWarehouse => '*WAREHOUSE_PROXY',                             # HD
   KIGASCUSTOM_UA00 => '*CUSTOM_IGASCUSTOM_UA00',                # IG
   KLZ => '*LINUX_SYSTEM',                                       # LZ
   KMVSSYS => '*MVS_SYSTEM',                                     # M5
   KRCACFG => '*MQ_AGENT',                                       # MC
   KMQ => '*MVS_MQM',                                            # MQ
   KMQIRA => '*MQIRA_MGR',                                       # MQ
   KMQESA => '*MVS_MQM',                                         # MQ
   KKQIA => '*MQSI_AGENT',                                       # QI
   KPH => '*HMC_BASE',                                           # PH
   KPK => '*CEC_BASE',                                           # PK
   KPV => '*VIOS_BASE',                                          # PV
   KPX => '*AIX_PREMIUM',                                        # PX
   KKQIB => '*MQSI_BROKER,*MQSI_BROKER_V7',                      # QI ???
   KSTORAGE => '*OMEGAMONXE_SMS,*OM_SMS',                        # S3
                                                                #    OMIICT:7VSG:STORAGE         managing agent?
                                                                #    IRAM:OMIICMS:NADH:STORAGE   [subnode??]
   KmySAP => '*SAP_AGENT',                                       # SA
   KSK => '*IBM_TSM_Agent',                                      # SK
   KSY => '*AGGREGATION_AND_PRUNING',                            # SY
   KUAGENT00 => '*CUSTOM_UAGENT00',                              # UA
   KKUL => '*UNIX_LOG_ALERT',                                    # UL
   KUA  => '*UNIVERSAL',                                         # UM
   KKUX => '*ALL_UNIX',                                          # UX
   KVA => '*VIOS_PREMIUM',                                       # VA
   KVL => '*OMXE_VM',                                            # VL
   KKYJA => '*ITCAM_J2EE_AGENT',                                 # YJ
   KKYJN => '*CAM_J2EE_NETWEAVER_SERVER',                        # YJ
   KKYNA => '*ITCAM_WEBSPHERE_AGENT',                            # YN
   KKYNR => '*CAM_WAS_PORTAL_SERVER',                            # YN
   KKYNP => '*CAM_WAS_PROCESS_SERVER',                           # YN
   KKYNS => '*CAM_WAS_SERVER',                                   # YN
   KDSGROUP => '*MVS_DB2',                                       # D5
   KPlexview => '*MVS_DB2',                                      # D5
   KSYSPLEX => '*MVS_SYSPLEX',                                   # M5
);
$hnodelist{'KSNMP-MANAGER00'} ='*CUSTOM_SNMP-MANAGER00';

# Following is a hard calculated collection  of how many TEMA apars are at each maintenance level.
#
# The goal is to identify how far behind a particular customer site is compare with latest maintenance levels.

# date: Date maintenance level published
# days: Number of days since 1 Jan 1900
# apars: array of TEMA APAR fixes included

my %mhash= (
            '06.30.07.07' => {date=>'10/15/2019',days=>43751,apars=>['IJ02614','IJ16462','IJ16759','IV77394',],},
            '06.30.07.06' => {date=>'05/23/2019',days=>43606,apars=>['IJ00337','IJ01062','IJ02662','IJ04231','IJ07905','IJ08972','IJ11029','IJ12656','IV84599','IV93367','IV95269','IV97602'],},
            '06.30.07' => {date=>'01/07/2017',days=>42742,apars=>['IV78703','IV81217'],},
            '06.30.06' => {date=>'12/10/2016',days=>42346,apars=>['IV66841','IV69144','IV70115','IV73766','IV76109','IV79364'],},
            '06.30.05' => {date=>'06/30/2015',days=>42183,apars=>['IV64897','IV65775','IV67576','IV69027'],},
            '06.30.04' => {date=>'12/12/2014',days=>41983,apars=>['IV44811','IV53859','IV54581','IV56194','IV56578','IV62139','IV62138','IV60851'],},
            '06.30.03' => {date=>'08/07/2014',days=>41856,apars=>['IV62667'],},
            '06.30.02' => {date=>'09/13/2013',days=>41528,apars=>['IV39406','IV47538','IV47540','IV47585','IV47590','IV47591','IV47592'],},
            '06.30.01' => {date=>'05/16/2013',days=>41408,apars=>['IV39778','IV39779'],},
            '06.30.00' => {date=>'03/08/2013',days=>41339,apars=>[],},
            '06.23.05' => {date=>'04/30/2014',days=>41757,apars=>['IV43114','IV46993','IV47201','IV47775','IV31825','IV52643'],},
            '06.23.04' => {date=>'10/21/2013',days=>41566,apars=>['IV43489','IV43787','IV44858','IV40015'],},
            '06.23.03' => {date=>'04/26/2013',days=>41388,apars=>['IV21954','IV24409','IV27955','IV32358'],},
            '06.23.02' => {date=>'10/11/2012',days=>41191,apars=>['IV16083','IV22060','IV23043','IV23784'],},
            '06.23.01' => {date=>'03/09/2012',days=>40975,apars=>['IV16476','IV16531','IV16532','IV10402','IV08621'],},
            '06.23.00' => {date=>'08/18/2011',days=>40771,apars=>[],},
            '06.22.09' => {date=>'06/29/2012',days=>41087,apars=>['IV10164','IV12849','IV00362'],},
            '06.22.08' => {date=>'03/30/2012',days=>40996,apars=>['IV07041','IV08621','IV09296','IV10402','IV18016'],},
            '06.22.07' => {date=>'12/15/2011',days=>40890,apars=>['IV03676','IV03943','IV04585','IV04683','IV06261','IZ96898'],},
            '06.22.06' => {date=>'09/30/2011',days=>40844,apars=>['IV00146','IV00655','IV00722','IV01532','IV03216','IZ98187','IV06896'],},
            '06.22.05' => {date=>'07/08/2011',days=>40730,apars=>['IZ84879','IZ89970','IZ95923','IZ96148','IZ97197','IV01708','IZ87796'],},
            '06.22.04' => {date=>'04/07/2011',days=>40638,apars=>['IZ81476','IZ85796','IZ89282','IZ93258','IZ84397'],},
            '06.22.03' => {date=>'09/28/2010',days=>40447,apars=>['IZ76410'],},
            '06.22.02' => {date=>'05/21/2010',days=>40317,apars=>['IZ45531','IZ75244'],},
            '06.22.01' => {date=>'11/20/2009',days=>40135,apars=>[],},
            '06.22.00' => {date=>'09/10/2009',days=>40062,apars=>[],},
            '06.21.04' => {date=>'12/17/2010',days=>40547,apars=>['IZ77554','IZ77981','IZ80179'],},
            '06.21.03' => {date=>'07/21/2010',days=>40378,apars=>['IZ70928','IZ73109','IZ73633','IZ76984'],},
            '06.21.02' => {date=>'04/16/2010',days=>40282,apars=>['IZ54269','IZ54895','IZ56686','IZ63949','IZ65337'],},
            '06.21.01' => {date=>'12/10/2009',days=>40155,apars=>['IZ60115'],},
            '06.21.00' => {date=>'11/10/2008',days=>39768,apars=>[],},
            '06.20.03' => {date=>'05/15/2009',days=>39946,apars=>['IZ41189','IZ42154','IZ42185'],},
            '06.20.02' => {date=>'10/30/2008',days=>39749,apars=>['IZ24933'],},
            '06.20.01' => {date=>'05/16/2008',days=>39582,apars=>['IZ60115'],},
            '06.20.00' => {date=>'12/14/2007',days=>39428,apars=>[],},
            '06.10.07' => {date=>'05/20/2008',days=>39586,apars=>['IY93399','IZ00591','IZ02165','IZ16659'],},
            '06.10.06' => {date=>'11/02/2007',days=>39386,apars=>['IZ02246','IY87701','IY96423','IY95964','IY98649','IY99106','IZ07221','IZ07224'],},
            '06.10.05' => {date=>'05/11/2007',days=>39211,apars=>['IY88519','IY92830','IY95114','IY95363','IY97983','IY97984','IY97993'],},
            '06.10.04' => {date=>'12/14/2006',days=>39063,apars=>['IY89899','IY90352'],},
            '06.10.03' => {date=>'08/18/2006',days=>38945,apars=>['IY90352','IY91296'],},
            '06.10.02' => {date=>'06/30/2006',days=>38896,apars=>['IY81984','IY84853','IY85392'],},
            '06.10.01' => {date=>'03/31/2006',days=>38805,apars=>['IY82424','IY82431','IY82785'],},
            '06.10.00' => {date=>'10/25/2005',days=>38648,apars=>[],},
        );

my %levelx = ();
my %klevelx = ( '06.30' => 1,
                '06.23' => 1,
                '06.22' => 1,
                '06.21' => 1,
                '06.20' => 1,
                '06.10' => 1,
              );

my %eoslevelx = ( '06.23' => {date=>'04/30/2019',count=>0,future=>0},
                  '06.22' => {date=>'04/28/2018',count=>0,future=>0},
                  '06.21' => {date=>'09/30/2015',count=>0,future=>0},
                  '06.20' => {date=>'09/30/2015',count=>0,future=>0},
                  '06.10' => {date=>'04/30/2012',count=>0,future=>0},
                );

my $tema_total_count = 0;
my $tema_total_good_count = 0;
my $tema_total_post_count = 0;
my $tema_total_deficit_count = 0;
my $tema_total_deficit_percent = 0;
my $tema_total_apars = 0;
my $tema_total_days = 0;
my $tema_total_max_days = 0;
my $tema_total_max_apars = 0;
my $tema_total_eos = 0;


my $tems_packages = 0;
my $tems_packages_nominal = 500;




# Situation Group related data
my %group = ();                            # situation group base data, hash of hashes
my %groupi = ();                           # situation group item data, hash of hashes
my %groupx = ();


# Situation related data

my $sit_bad_time = 4*24*60*60;             # dangerous sampling interval

my $siti = -1;                             # count of situations
my $curi;                                  # global index for subroutines
my @sit = ();                              # array of situations
my %sitx = ();                             # Index from situation name to index
my @sit_pdt = ();                          # array of predicates or situation formula
my @sit_pdtseq = ();                       # array of duplicate count for pdts
my @sit_ct = ();                           # count of situation references
my @sit_fullname = ();                     # array of fullname
my @sit_psit = ();                         # array of printable situaton names
my @sit_sitinfo = ();                      # array of SITINFO columns
my @sit_autostart = ();                    # array of AUTOSTART columns
my @sit_value = ();                        # count of *VALUE
my @sit_sit = ();                          # count of *SIT
my @sit_str = ();                          # count of *STR
my @sit_scan = ();                         # count of *SCAN
my @sit_scan_ne = ();                      # count of *SCAN with invalid *NE
my @sit_change = ();                       # count of *CHANGE
my @sit_pctchange = ();                    # count of *PCTCHANGE
my @sit_count = ();                        # count of *COUNT
my @sit_count_zero = ();                   # count of *COUNT w/value zero
my @sit_count_ltone = ();                  # count of *COUNT *LT/*LE 1
my @sit_count_lt = ();                     # count of *COUNT *LT/*LE more then 1
my @sit_min = ();                          # count of *MIN
my @sit_max = ();                          # count of *MAX
my @sit_avg = ();                          # count of *AVG
my @sit_sum = ();                          # count of *SUM
my @sit_time = ();                         # count of *TIME
my @sit_time_same = ();                    # count of *TIME with same attribute table [bad]
my @sit_until_ttl = ();                    # value of UNTIL/*TTL
my @sit_until_sit = ();                    # value of UNTIL/*SIT
my @sit_tables = ();                       # list of attribute groups
my @sit_alltables = ();                    # list of all attribute groups
my @sit_missing = ();                      # count of *MISSING
my @sit_ms_offline = ();                   # count of MS_Offline type tests
my @sit_ms_online = ();                    # count of MS_Online type tests
my @sit_reason_ne_fa = ();                 # count of reason ne FA cases
my @sit_syntax = ();                       # syntax error caught
my @sit_persist = ();                      # persist count
my @sit_cmd = ();                          # 1 if CMD is present
my @sit_cmdtext = ();                      # cmd text
my @sit_autosopt = ();                     # autosopt column
my @sit_atom = ();                         # 1 if DisplayItem
my @sit_ProcessFilter = ();                # 1 if process Filter present
my @sit_alwaystrue = ();                   # 1 if always true *value test
my @sit_reeval = ();                       # sampling interval in seconds
my @sit_filter = ();                       # Where filtered
my @sit_dist = ();                         # When 1, distributed
my @sit_dist_objaccl = ();                 # Situation Distributions in TOBJACCL and TGROUP/TGROUPI
my @sit_process = ();                      # Process type attribute group
my @sit_fileinfo = ();                     # File Information type attribute group
my @sit_history_collect  = ();             # If History collection file, where collected - IRA or CMS
my @sit_history_interval = ();             # If History collection file, how often collected in seconds
my @sit_history_export   = ();             # If History collection file, how many collections before export
my $sit_distribution = 0;                  # when 1, distributions are present
my @sit_lstdate = ();
my @sit_correlate = ();

my $sit_autostart_total = 0;
my $sit_tems_alert = 0;
my $sit_tems_alert_run = 0;
my $sit_tems_alert_dist = 0;

my $sit_correlated = 0;
my $sit_correlated_ct = 0;
my $sit_correlated_hour =0;
my $sit_purettl = 0;

my $nax;
my $nami = -1;                             # count of fullname indexes
my @nam = ();                              # array of index
my %namx = ();                             # Index from index name to index
my @nam_fullname = ();                     # array of fullnames
my @nam_ct = ();                           # count of tname references
my @nam_lstdate = ();                      # last update times

my $evti = -1;                             # event destination data
my @evt = ();
my @evt_lstdate = ();
my @evt_lstusrprf = ();

my $ccti = -1;
my @cct = ();
my @cct_lstdate = ();
my @cct_name = ();

my $evmapi = -1;
my @evmap = ();
my @evmap_lstdate = ();
my @evmap_map  = ();

my %pcyx = ();

my $cali = -1;
my @cal = ();
my %calx = ();
my @cal_count = ();
my @cal_lstdate = ();
my @cal_name = ();

my $tcai = -1;
my @tca = ();
my %tcax = ();
my @tca_count = ();
my @tca_lstdate = ();
my @tca_sitname = ();

my $tcii = -1;
my @tci = ();
my %tcix = ();
my @tci_count = ();
my @tci_lstdate = ();
my @tci_id = ();
my @tci_calid = ();

my %eibnodex = ();

my $hdonline = 0;
my $uadhist = 0;
my $obj_oplog = 0;

my %eventx = ();
my $eventx_start = -1;
my $eventx_last = -1;
my $eventx_dur;

my %epochx;

while (<main::DATA>)
{
  $advline = $_;
  $advline =~ s/\x0d//g if $gWin == 0;
  if ($advkey eq "") {
     chomp $advline;
     $advkey = $advline;
     next;
  }
  if (length($advline) >= 14) {
     if ((substr($advline,0,10) eq "DATAHEALTH") or (substr($advline,0,10) eq "DATAREPORT")){
        $advtextx{$advkey} = $advtext;
        chomp $advline;
        $advkey = $advline;
        $advtext = "";
        next;
     }
  }
  $advtext .= $advline;
}
$advtextx{$advkey} = $advtext;

my $rptkey;



# option and ini file variables variables

my $opt_txt;                    # input from .txt files
my $opt_txt_tnodelst;           # TNODELST txt file
my $opt_txt_tnodesav;           # TNODESAV txt file
my $opt_txt_tsitdesc;           # TSITDESC txt file
my $opt_txt_tname;              # TNAME txt file
my $opt_txt_tobjaccl;           # TOBJACCL txt file
my $opt_txt_tgroup;             # TGROUP txt file
my $opt_txt_tgroupi;            # TGROUPI txt file
my $opt_txt_evntserver;         # EVNTSERVER txt file
my $opt_txt_package;            # PACKAGE txt file
my $opt_txt_cct;                # CCT txt file
my $opt_txt_evntmap;            # EVNTMAP txt file
my $opt_txt_tpcydesc;           # TPCYDESC txt file
my $opt_txt_tactypcy;           # TACTYPCY txt file
my $opt_txt_tcalendar;          # TCALENDAR txt file
my $opt_txt_toverride;          # TOVERRIDE txt file
my $opt_txt_toveritem;          # TOVERITEM txt file
my $opt_txt_teiblogt;           # TEIBLOGT txt file
my $opt_txt_tsitstsh;           # TSITSTSH txt file
my $opt_txt_tcheckpt;           # TCHECKPT txt file
my $opt_lst;                    # input from .lst files
my $opt_lst_tnodesav;           # TNODESAV lst file
my $opt_lst_tnodelst;           # TNODELST lst file
my $opt_lst_tsitdesc;           # TSITDESC lst file
my $opt_lst_tname;              # TNAME lst file
my $opt_lst_tobjaccl;           # TOBJACCL lst file
my $opt_lst_tgroup;             # TGROUP lst file
my $opt_lst_tgroupi;            # TGROUPI lst file
my $opt_lst_evntserver;         # EVNTSERVER lst file
my $opt_lst_cct;                # CCT lst file
my $opt_lst_evntmap;            # EVNTMAP lst file
my $opt_lst_tpcydesc;           # TPCYDESC lst file
my $opt_lst_tactypcy;           # TACTYPCY lst file
my $opt_lst_tcalendar;          # TCALENDAR lst file
my $opt_lst_toverride;          # TOVERRIDE lst file
my $opt_lst_toveritem;          # TOVERITEM lst file
my $opt_lst_teiblogt;           # TEIBLOGT lst file
my $opt_lst_tsitstsh;           # TSITSTSH lst file
my $opt_lst_tcheckpt;           # TCHECKPT txt file
my $opt_log;                    # name of log file
my $opt_ini;                    # name of ini file
my $opt_hub;                    # externally supplied nodeid of hub TEMS
my $opt_debuglevel;             # Debug level
my $opt_debug;                  # Debug level
my $opt_h;                      # help file
my $opt_v;                      # verbose flag
my $opt_vt;                     # verbose traffic flag
my $opt_dpr;                    # dump data structure flag
my $opt_o;                      # output file
my $opt_event;                  # When 1, create event reports
my $opt_asysname;                # When 1, create sysname.csv report
my $opt_asysname_csv;
my $opt_s;                      # write summary line if max impact > 0
my $opt_workpath;               # Directory to store output files
my $opt_nohdr = 0;              # skip header to make regression testing easier
my $opt_subpc_warn;             # advise when subnode length > 90 of limit on pre ITM 623 FP2
my $opt_peak_rate;              # Advise when virtual hub update peak is higher
my $opt_vndx;                   # when 1 create a index for missing TNODELST NODETYPE=V records
my $opt_vndx_fn;                # when opt_vndx - this is filename
my $opt_mndx;                   # when 1 create a index for missing TNODELST NODETYPE=M records
my $opt_mndx_fn;                # when opt_mndx - this is filename
my $opt_miss;                   # when 1 create a missing.sql file
my $opt_miss_fn;                # missing file SQL name
my $opt_delu;                   # when 1 create a delete unused file
my $opt_delu_cmd;               # delete unused file SQL name - Windows style
my $opt_delu_sh;                # delete unused file SQL name - Unix/Linux style
my $opt_delu_csv;               # delete unused file SQL name - Unix/Linux style
my $opt_nodist;                 # TGROUP names which are planned as non-distributed
my $opt_fto = "";               # HUB or MIRROR
my $opt_crit = "";
my $critical_fn = "datahealth.crit";
my @crits;

# do basic initialization from parameters, ini file and standard input

$rc = init($args_start);

$opt_log = $opt_workpath . $opt_log;
$opt_o = $opt_workpath . $opt_o;
$opt_s = $opt_workpath . $opt_s;
$opt_log =~ s/\\\\/\//g;
$opt_log =~ s/\/\//\//g;
$opt_o =~ s/\\\\/\//g;
$opt_o =~ s/\/\//\//g;
$opt_s =~ s/\\\\/\//g;
$opt_s =~ s/\/\//\//g;

my $tema_maxlevel = "";
foreach my $f (sort { $b cmp $a } keys %mhash) {
   $tema_maxlevel = $f;
   last;
}

open FH, ">>$opt_log" or die "can't open $opt_log: $!";

logit(0,"SITAUDIT000I - ITM_Situation_Audit $gVersion $args_start");

my $cinfopath;
my $cinfofn;
my $gotcin = 0;
$cinfopath = $opt_workpath;
if ( -e $cinfopath . "cinfo.info") {
   $gotcin = 1;
   $cinfopath = $opt_workpath;
} elsif ( -e $cinfopath . "../cinfo.info") {
   $gotcin = 1;
   $cinfopath = $opt_workpath . "../";
} elsif ( -e $cinfopath . "../../cinfo.info") {
   $gotcin = 1;
   $cinfopath = $opt_workpath . "../../";
}
$cinfopath = '"' . $cinfopath . '"';

my $pwd = "";
my $splevel = "";
my $cinfo_host = "";
my $cinfo_level = "";
my %sphash = ('063007060' => 'SP1',
              '063007070' => 'SP2',
              '06.30.07.06' => 'SP1',
              '06.30.07.07' => 'SP2',
             );

if ($gotcin == 1) {
   if ($gWin == 1) {
      $pwd = `cd`;
      chomp($pwd);
      $cinfopath = `cd $cinfopath & cd`;
   } else {
      $pwd = `pwd`;
      chomp($pwd);
      $cinfopath = `(cd $cinfopath && pwd)`;
   }

   chomp $cinfopath;

   $cinfofn = $cinfopath . "/cinfo.info";
   $cinfofn =~ s/\\/\//g;    # switch to forward slashes, less confusing when programming both environments

   chomp($cinfofn);
   chdir $pwd;

   my $active_line = "";

   #   open( FILE, "< $opt_ini" ) or die "Cannot open ini file $opt_ini : $!";
   if (defined $cinfofn) {
      open CINFO,"< $cinfofn" or warn " open cinfo.info file $cinfofn -  $!";
      my @nts = <CINFO>;
      close CINFO;

      # sample cinfo.info outputs
      # SP1 signal in cinfo.info
      # Windows: Host Name  : USMDCEDAP6024         Installer : Ver: 063007060
      # AIX: Host name : catrhom011itdxa-nim Installer Lvl:06.30.07.06
      # Linux: Host name : hlxd00tm03_bak   Installer Lvl:06.30.07.06

      # SP2 signam in cinfo.info
      # Windows: Host Name  : ITM1101                                   Installer : Ver: 063007070
      # sample netstat outputs

      my $l = 0;
      foreach my $oneline (@nts) {
         $l++;
         chomp($oneline);
         if ($gWin == 1) {
            $oneline =~ /Host Name  : (\S+)/;
            $cinfo_host = $1;
            $oneline =~ /Ver: (\d+)/;
            $cinfo_level = $1;
            next if !defined $cinfo_level;
         } else {
            $oneline =~ /Host name  : (\S+)/;
            $cinfo_host = $1;
            $oneline =~ /Lvl: (\d+)/;
            $cinfo_level = $1;
            next if !defined $cinfo_level;
         }
         if (defined $cinfo_level) {
            $splevel = $sphash{$cinfo_level} if defined $sphash{$cinfo_level};
         }
         last;
      }
   }
}



# process two different sources of TEMS database tables

if ($opt_txt == 1) {                    # text files
   $rc = init_txt();
} elsif ($opt_lst == 1) {               # KfwSQLClient LST files
   $rc = init_lst();
}


open OH, ">$opt_o" or die "can't open $opt_o: $!";

if ($opt_vndx == 1) {
   open NDX, ">$opt_vndx_fn" or die "can't open $opt_vndx_fn: $!";
}

if ($opt_mndx == 1) {
   open MDX, ">$opt_mndx_fn" or die "can't open $opt_mndx_fn: $!";
}

if ($opt_miss == 1) {
   open MIS, ">$opt_miss_fn" or die "can't open $opt_miss_fn: $!";
}

if ($opt_delu == 1) {
   open DELSH, ">$opt_delu_sh" or die "can't open $opt_delu_sh: $!";
   binmode(DELSH);
   open DELCMD, ">$opt_delu_cmd" or die "can't open $opt_delu_cmd: $!";
   open DELCSV, ">$opt_delu_csv" or die "can't open $opt_delu_csv: $!";
}


if ($hub_tems_no_tnodesav == 1) {
   $advi++;$advonline[$advi] = "HUB TEMS $hub_tems is present in TNODELST but missing from TNODESAV";
   $advcode[$advi] = "DATAHEALTH1011E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $hub_tems;
}

if ($nlistvi == -1) {
   $advi++;$advonline[$advi] = "No TNODELST NODETYPE=V records";
   $advcode[$advi] = "DATAHEALTH1012E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $hub_tems;
   $hub_tems_no_tnodesav = 1;
}

# following produces a report of how many agents connect to a TEMS.

$hub_tems = $opt_hub if $hub_tems eq "";
if ($hub_tems_no_tnodesav == 0) {
   # following is a rare case where the TNODELST *HUB entry is missing.
   # for analysis work, that can be supplied by a -hub <nodeid> parameter
   if ($hub_tems eq "") {
      $advi++;$advonline[$advi] = "*HUB node missing from TNODELST Type M records";
      $advcode[$advi] = "DATAHEALTH1038E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "*HUB";
   } else {
      $hubi = $temsx{$hub_tems};
      for ($i=0; $i<=$nlistvi; $i++) {
         my $node1 = $nlistv[$i];
         next if $nlistv_tems[$i] eq "";
         my $tems1 = $nlistv_tems[$i];
         my $tx = $temsx{$tems1};
         next if !defined $tx;
         $hub_tems_ct += 1;
         $tems_ct[$tx] += 1;
         my $nx = $nsavex{$node1};
         next if !defined $nx;
         if (($nsave_product[$nx] ne "CQ") and ($nsave_product[$nx] ne "HD") and ($nsave_product[$nx] ne "SY")) {
            $tems_ctnok[$tx] += 1;
         }
         my $phostaddr = lc $nsave_hostaddr[$nx];
         $tems_spipe[$tx] += 1 if index($phostaddr,"spipe") != 01;

         # Calculate TEMA APAR Deficit numbers
         my $agtlevel = substr($nsave_temaver[$nx],0,8);
         next if $agtlevel eq "";
         my $temslevel = $tems_version[$tx];

         if (($agtlevel ne "") and ($temslevel ne "")) {
            $tema_total_count += 1;
            if (substr($temslevel,0,5) lt substr($agtlevel,0,5)) {
               $advi++;$advonline[$advi] = "Agent with TEMA at [$agtlevel] later than TEMS $tems1 at [$temslevel]";
               $advcode[$advi] = "DATAHEALTH1043E";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $node1;
            }
            my $aref = $mhash{$agtlevel};
            if (!defined $aref) {
               if ($nsave_product[$nx] eq "A4") {
                  next if $agtlevel eq "06.20.20";
               }
               $advi++;$advonline[$advi] = "Agent with unknown TEMA level [$agtlevel]";
               $advcode[$advi] = "DATAHEALTH1044E";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $node1;
               next;
            }
            my $tref = $mhash{$temslevel};
            if (!defined $tref) {
               $advi++;$advonline[$advi] = "TEMS with unknown version [$temslevel]";
               $advcode[$advi] = "DATAHEALTH1045E";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $tems1;
               next;
            }
            if ($temslevel eq $agtlevel) {
               $tema_total_good_count += 1;
            } elsif ($temslevel gt $agtlevel) {
               $tema_total_deficit_count += 1;
            } else {
               $tema_total_post_count += 1;
            }
            my $tlevelref = $eoslevelx{substr($agtlevel,0,5)};
            if (defined $tlevelref) {
               $tlevelref->{count} += 1;
               $tema_total_eos += 1;
            }
            my $key = $temslevel . "|" . $agtlevel;
            my $level_ref = $levelx{$key};
            if (!defined $level_ref) {
               my %aparref = ();
               my %levelref = (
                                 days => 0,
                                 apars => 0,
                                 aparh => \%aparref,
                              );
               $levelx{$key} = \%levelref;
               $level_ref    = \%levelref;
               foreach my $f (sort { $a cmp $b } keys %mhash) {
                  next if $f le $agtlevel;
                  last if $f gt $temslevel;
                  foreach my $h ( @{$mhash{$f}->{apars}}) {
                       next if defined $level_ref->{aparh}{$h};
                       $level_ref->{aparh}{$h} = 1;
                       $level_ref->{apars} += 1;
                       $level_ref->{days}  += $mhash{$temslevel}->{days} - $mhash{$agtlevel}->{days};
                  }
               }
            }
            $tema_total_days += $level_ref->{days};
            $tema_total_apars += $level_ref->{apars};
         }
#        print "working on $node1 $agtlevel\n";
         $temslevel = $tema_maxlevel;
         $key = $temslevel . "|" . $agtlevel;
         my $level_ref = $levelx{$key};
         if (!defined $level_ref) {
            my %aparref = ();
            my %levelref = (
                              days => 0,
                              apars => 0,
                              aparh => \%aparref,
                           );
            $levelx{$key} = \%levelref;
            $level_ref    = \%levelref;
            foreach my $f (sort { $a cmp $b } keys %mhash) {
               next if $f le $agtlevel;
               last if $f gt $temslevel;
               foreach my $h ( @{$mhash{$f}->{apars}}) {
                    next if defined $level_ref->{aparh}{$h};
                    $level_ref->{aparh}{$h} = 1;
                    $level_ref->{apars} += 1;
                    $level_ref->{days}  += $mhash{$temslevel}->{days} - $mhash{$agtlevel}->{days};
               }
            }
         }
         $tema_total_max_days +=  $level_ref->{days};
         $tema_total_max_apars += $level_ref->{apars};
#        print "adding $level_ref->{apars} for $node1 $agtlevel\n";
      }
      if ($tems_version[$hubi] eq "06.30.07"){
         for (my $i=0;$i<=$temsi;$i++) {
            next if $i == $hubi;
            next if $tems_version[$i] ne "06.30.06";
            next if $tems_spipe[$i] == 0;
            $advi++;$advonline[$advi] = "Remote TEMS $tems[$i] with ip.spipe connections may be unstable";
            $advcode[$advi] = "DATAHEALTH1115W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = "TEMS";
         }
      }
   }
}

# calculate Agent Summary Report Section
my $npc_ct = 0;
for ($i=0; $i<=$nsavei; $i++) {
   my $node1 = $nsave[$i];
   my $npc = $nsave_product[$i];
   next if $npc eq "";
   my $nversion = $nsave_version[$i];
   $nversion .= "." . $nsave_subversion[$i] if $nsave_subversion[$i] ne "";
   my $ntema = $nsave_temaver[$i];
   my $ninfo = $nsave_hostinfo[$i];
   $npc_ct += 1;
   my $pc_ref = $pcx{$npc};
   if (!defined $pc_ref) {
      my %pcref = (
                      count => 0,
                      versions => {},
                      temas => {},
                      info => {},
                  );
      $pc_ref = \%pcref;
      $pcx{$npc} = \%pcref;
   }
   $pc_ref->{count} += 1;

   # Calculate Agent versions
   if ($nversion ne "") {
      my $version_ref = $pc_ref->{versions}{$nversion};
      if (!defined $version_ref) {
         my %versionref = (
                             count => 0,
                          );
        $version_ref = \%versionref;
        $pc_ref->{versions}{$nversion} = \%versionref;
      }
      $pc_ref->{versions}{$nversion}->{count} += 1;
   }

   # Calculate Agent TEMA versions
   if ($ntema ne "") {
      my $tema_ref = $pc_ref->{temas}{$ntema};
      if (!defined $tema_ref) {
         my %temaref = (
                          count => 0,
                       );
        $tema_ref = \%temaref;
        $pc_ref->{temas}{$ntema} = \%temaref;
      }
      $pc_ref->{temas}{$ntema}->{count} += 1;
   }

   # Calculate Agent HOSTINFO versions
   if ($ninfo ne "") {
      my $info_ref = $pc_ref->{info}{$ninfo};
      if (!defined $info_ref) {
         my %inforef = (
                          count => 0,
                       );
        $info_ref = \%inforef;
        $pc_ref->{info}{$ninfo} = \%inforef;
      }
      $pc_ref->{info}{$ninfo}->{count} += 1;
   }
}

for (my $i=0;$i<=$temsi;$i++) {
   if ($tems_o4online[$i] eq "Y") {
      if ($tems_thrunode[$i] eq $tems[$i]) {
         # The following test is how a hub TEMS is distinguished from a remote TEMS
         # This checks an affinity capability flag which indicates the policy microscope
         # is available. I tried many ways and failed before finding this.
         my $testc = substr($tems_affinities[$i],40,1);
         my $testi = index($affchars,$testc);
         my $test1 = $testi & 0x10;         # affinity bit for FTO
         if ($test1 != 0) {
            $isFTO += 1;
            $FTOver{$tems[$i]} = $tems_version[$i];
         }
      }
   }
}

my $FTO_diff = 0;
if ($isFTO >= 2) {
   my %reverse;
   my $pftover = "";
   while (my ($key, $value) = each %FTOver) {
      push @{$reverse{$value}}, $key;
      $pftover .= $key . "=" . $value . ";";
   }
   if (scalar (keys %reverse) > 1) {
      $advi++;$advonline[$advi] = "FTO hub TEMS have different version levels [$pftover]";
      $advcode[$advi] = "DATAHEALTH1069E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "FTO";
   }
   my $pFTO_ct = scalar (keys %FTOver);
   if ($pFTO_ct > 2) {
      $advi++;$advonline[$advi] = "There are $pFTO_ct hub TEMS [$pftover]";
      $advcode[$advi] = "DATAHEALTH1070W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "FTO";
   }
}


if ($tems_packages > $tems_packages_nominal) {
   $advi++;$advonline[$advi] = "Total TEMS Packages [.cat files] count [$tems_packages] exceeds nominal [$tems_packages_nominal]";
   $advcode[$advi] = "DATAHEALTH1046W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "Package.cat";
}

if ($tems_packages > 510) {
   $advi++;$advonline[$advi] = "Total TEMS Packages [.cat files] count [$tems_packages] close to TEMS failure point of 513";
   $advcode[$advi] = "DATAHEALTH1048E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "Package.cat";
}

my %agenthubx;
my %agenthubnx;
for ($i=0; $i<=$nsavei; $i++) {
   my $node1 = $nsave[$i];
   next if $nsave_product[$i] eq "EM";
   if (index($node1,"::CONFIG") !=  -1) {
      $nsx = $nlistvx{$node1};
      if (defined $nsx) {
         my $thrunode1 = $nlistv_thrunode[$nsx];
         if (defined $thrunode1) {
            my $tx = $temsx{$thrunode1};
            if (defined $tx) {
               if ($thrunode1 ne $hub_tems) {
                  $advi++;$advonline[$advi] = "CF Agent connected to $thrunode1 which is not the hub TEMS";
                  $advcode[$advi] = "DATAHEALTH1076W";
                  $advimpact[$advi] = $advcx{$advcode[$advi]};
                  $advsit[$advi] = $node1;
               } else {
                  if ($isFTO >= 2) {
                     $advi++;$advonline[$advi] = "CF Agent not supported in FTO mode";
                     $advcode[$advi] = "DATAHEALTH1077E";
                     $advimpact[$advi] = $advcx{$advcode[$advi]};
                     $advsit[$advi] = $node1;
                 }
               }
            }
         }
      }
   }

   next if $nsave_product[$i] eq "CF";      # TEMS Configuration Managed System does not have TEMA - skip most tests
   if ($nsave_product[$i] eq "HD") {        # WPA should only connect to hub TEMS
      $hdonline += 1;
      $nsx = $nlistvx{$node1};
      if (defined $nsx) {
         my $thrunode1 = $nlistv_thrunode[$nsx];
         if (defined $thrunode1) {
            my $tx = $temsx{$thrunode1};
            if (defined $tx) {
               if ($thrunode1 ne $hub_tems) {
                  $advi++;$advonline[$advi] = "WPA connected to $thrunode1 which is not the hub TEMS";
                  $advcode[$advi] = "DATAHEALTH1078W";
                  $advimpact[$advi] = $advcx{$advcode[$advi]};
                  $advsit[$advi] = $node1;
               }
            }
         }
      }
   }
   my $rtemsi = 0;
   if ($isFTO > 0) {
      $rtemsi = $temsi - $isFTO;
   } elsif ($temsi > 0) {
      $rtemsi = $temsi - 1;
   }

   if ($nsave_product[$i] ne "EM") {  # record agents configured to hub TEMS
      $nsx = $nlistvx{$node1};
      if ($rtemsi > 0) {
         if (defined $nsx) {
            my $thru1 = $nlistv_thrunode[$nsx];
            my $prod1 = $nsave_product[$i];
            if ($thru1 eq $hub_tems) {
               if ($prod1 ne "CQ") {
                  $agenthubnx{$node1} = $nsave_product[$i] if index("HD SY",$prod1) != -1;
                  $agenthubx{$node1} = $nsave_product[$i] if index("HD SY",$prod1) == -1;
               }
            }
         }
      }
   }


   if (index($node1,"::MQ") !=  -1) {
      $advi++;$advonline[$advi] = "MQ Agent name has missing hostname qualifier";
      $advcode[$advi] = "DATAHEALTH1073W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $node1;
   }
   $nsx = $nlistvx{$node1};
   next if defined $nsx;
   if (index($node1,":") !=  -1) {
      $advi++;$advonline[$advi] = "Node present in node status but missing in TNODELST Type V records";
      $advcode[$advi] = "DATAHEALTH1001E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $node1;
      next if $opt_vndx == 0;
      print NDX "$node1\n";
   }
}

for ($i=0; $i<=$nsavei; $i++) {
   my $node1 = $nsave[$i];
   next if $nsave_product[$i] eq "EM";
   my $product1 = $nsave_product[$i];
   $nsx = $nlistvx{$node1};
   if (defined $nsx) {
      my $subn = 0;
      my $thru1 = $nlistv_thrunode[$nsx];
      if ($thru1 eq "") {
        $subn = 1;
      } else {
        my $tx = $temsx{$thru1};
        $subn = 1 if !defined $tx;
      }
      if ($subn == 0) {
         next if length($node1) < 32;
         my $known_ext = 0;
         @words = split(":",$node1);
         if ($#words > 0) {
            my $lastseg = $words[$#words];
            my $keyseg = "K" . $lastseg;
           $known_ext = 1 if defined $hnodelist{$keyseg};
         }
         next if $known_ext == 1;
         $advi++;$advonline[$advi] = "Node Name at 32 characters and might be truncated - product[$product1]";
         $advcode[$advi] = "DATAHEALTH1013W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $node1;
      } else {
         next if length($node1) < 31;
         $advi++;$advonline[$advi] = "Subnode Name at 31/32 characters and might be truncated - product[$product1]";
         $advcode[$advi] = "DATAHEALTH1014W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $node1;
      }
   }
}

for ($i=0; $i<=$magenti;$i++) {
   my $onemagent = $magent[$i];
   next if $magent_tems_version[$i] ge "06.23.02";
   if ($magent_sublen[$i]*100 > $opt_subpc_warn*32768){
      $advi++;$advonline[$advi] = "Managing agent subnodelist is $magent_sublen[$i]: more then $opt_subpc_warn% of 32768 bytes";
      $advcode[$advi] = "DATAHEALTH1015W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $onemagent;
   }
}

for ($i=0; $i<=$evti;$i++) {
   valid_lstdate("EVNSERVER",$evt_lstdate[$i],$evt[$i],"ID=$evt[$i]");
   my $oneid = $evt[$i];
}

for ($i=0; $i<=$evmapi;$i++) {
   valid_lstdate("EVNTMAP",$evmap_lstdate[$i],$evmap[$i],"ID=$evmap[$i]");
   my $onemap = $evmap_map[$i];
   #<situation name="kph_actvmem_xuxc_epf" mapAllAttributes="Y" ><class name="ITM_Unix_Memory" /></situation>
   $onemap =~ /\"(\S+)\"/;
   my $onesit = $1;
   if (!defined $onemap){
      $advi++;$advonline[$advi] = "EVNTMAP Situation reference missing";
      $advcode[$advi] = "DATAHEALTH1053E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $evmap[$i];
   } else {
      $onesit =~ s/\s+$//;   #trim trailing whitespace
      if (!defined $sitx{$onesit}){
         $advi++;$advonline[$advi] = "EVNTMAP ID[$evmap[$i]] Unknown Situation in mapping - $onesit";
         $advcode[$advi] = "DATAHEALTH1047E";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $evmap[$i];
      }
   }

}

for ($i=0; $i<=$ccti;$i++) {
   valid_lstdate("CCT",$cct_lstdate[$i],$cct[$i],"ID=$cct[$i]");
}

# Following logic cross checks the LSTDATE field. There is a big distinction between FTO mode and not.
# In FTO mode condition cause actual problems while otherwise they are potential problems. That is why
# there are 4 advisories.
#
# LSTDATE blank - causes a failure to FTO synchronize. If not FTO - a potential problem for the future.
# LSTDATE in future - cause breakage to FTO synchronize process. If not FTO - a potential problem for the future.
# LSTDATE in future and ITM 630 FP3 or later, no problem because of TEMS logic change
# LSTDATE in future and before ITM 630 FP3, causes invalid "high water mark" at backup hub TEMS and thus update to be ignored.

sub valid_lstdate {
   my ($itable,$ilstdate,$iname,$icomment) = @_;
   if ($isFTO >= 2){
      if ($ilstdate eq "") {
         $advi++;$advonline[$advi] = "$itable LSTDATE is blank and will not synchronize in FTO configuration";
         $advcode[$advi] = "DATAHEALTH1039E";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $iname;
      } elsif ($ilstdate gt $tlstdate) {
         if (defined $hubi) {
            if ($tems_version[$hubi]  lt "06.30.03") {
               $advi++;$advonline[$advi] = "LSTDATE for [$icomment] value in the future $ilstdate";
               $advcode[$advi] = "DATAHEALTH1040E";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = "$itable";
            }
         }
      }
   } else {
      if ($ilstdate eq "") {
         $advi++;$advonline[$advi] = "$itable LSTDATE is blank and will not synchronize in FTO configuration";
         $advcode[$advi] = "DATAHEALTH1063W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $iname;
      } elsif ($ilstdate gt $tlstdate) {
         if (defined $hubi) {
            if ($tems_version[$hubi]  lt "06.30.03") {
               $advi++;$advonline[$advi] = "LSTDATE for [$icomment] value in the future $ilstdate";
               $advcode[$advi] = "DATAHEALTH1041W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
     $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = "$itable";
            }
         }
      }
   }
}


for ($i=0; $i<=$cali; $i++) {
   valid_lstdate("TCALENDAR",$cal_lstdate[$i],$cal_name[$i],"NAME=$cal_name[$i]");
   if ($cal_count[$i] > 1) {
      $advi++;$advonline[$advi] = "TCALENDAR duplicate key ID";
      $advcode[$advi] = "DATAHEALTH1058E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $cal[$i];
      $dupndx{"TCALENDAR"} = 1;
   }
}

for ($i=0; $i<=$tcai; $i++) {
   valid_lstdate("TOVERRIDE",$tca_lstdate[$i],$tca[$i],"ID=$tca[$i]");
   if ($tca_count[$i] > 1) {
      $advi++;$advonline[$advi] = "TOVERRIDE duplicate key ID";
      $advcode[$advi] = "DATAHEALTH1059E";
      $advsit[$advi] = $tca[$i];
      $dupndx{"TOVERRIDE"} = 1;
   }
   my $onesit = $tca_sitname[$i];
   if (!defined $sitx{$onesit}){
      $advi++;$advonline[$advi] = "TOVERRIDE Unknown Situation [$onesit] in override";
      $advcode[$advi] = "DATAHEALTH1060E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $tca[$i];
   }
}

for ($i=0; $i<=$tcii; $i++) {
   if ($tci_calid[$i] ne "") {
      my $onecal = $tci_calid[$i];
      if (!defined $calx{$onecal}){
         $advi++;$advonline[$advi] = "TOVERITEM Unknown Calendar ID $onecal";
         $advcode[$advi] = "DATAHEALTH1061E";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $tci[$i];
      }
      my $oneid = $tci_id[$i];
      if (!defined $tcax{$oneid}){
         $advi++;$advonline[$advi] = "TOVERITEM Unknown TOVERRIDE ID $oneid";
         $advcode[$advi] = "DATAHEALTH1062E";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $tci[$i];
      }
   }
}

for ($i=0; $i<=$nsavei; $i++) {
   next if $nsave_sysmsl[$i] > 0;
   next if $nsave_product[$i] eq "EM";
   next if $nsave_product[$i] eq "CF";      # TEMS Configuration Managed System does not have TEMA - skip most tests
   my $node1 = $nsave[$i];
   $vlx = $nlistvx{$node1};
   if (defined $vlx) {
      next if $nlistv_thrunode[$vlx] ne $nlistv_tems[$vlx];
   }
   if (index($node1,":") !=  -1) {
      $advi++;$advonline[$advi] = "Node without a system generated MSL in TNODELST Type M records";
      $advcode[$advi] = "DATAHEALTH1002E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $node1;
      next if $opt_mndx == 0;
      print MDX "$node1\n";
   }
}
for ($i=0; $i<=$nlistmi; $i++) {
   my $node1 = $nlistm[$i];
   my $nnx = $nsavex{$node1};
   next if !defined $nnx;
   next if $nsave_product[$nnx] eq "CF";      # TEMS Configuration Managed System does not have TEMA - skip most tests
   if ($nlistm_miss[$i] != 0) {
      $advi++;$advonline[$advi] = "Node present in TNODELST Type M records but missing in Node Status";
      $advcode[$advi] = "DATAHEALTH1003I";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $node1;
     if ($opt_miss == 1) {
         my $key = "DATAHEALTH1003I" . " " . $node1;
         $miss{$key} = 1;
      }
   }
   if ($nlistm_nov[$i] != 0) {
      $advi++;$advonline[$advi] = "Node present in TNODELST Type M records but missing TNODELST Type V records";
      $advcode[$advi] = "DATAHEALTH1004I";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $node1;
  }
}

foreach my $f (keys %group) {
   my $group_detail_ref = $group{$f};
   valid_lstdate("TGROUP",$group_detail_ref->{lstdate},$f,"KEY=$f");
   if ($group_detail_ref->{indirect} == 0) {
      my $nodist = 0;
      if ($opt_nodist ne "") {
         if (substr($group_detail_ref->{grpname},0,length($opt_nodist)) eq $opt_nodist){
            $nodist = 1;
         }
      }
      if ($nodist == 0) {
         my $gkey = substr($f,5);
         my $ox = $tobjaccl{$gkey};
         if (!defined $ox) {
            $advi++;$advonline[$advi] = "TGROUP ID $f NAME $group_detail_ref->{grpname} not distributed in TOBJACCL";
            $advcode[$advi] = "DATAHEALTH1034W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $group_detail_ref->{grpname};
         }
      }
   }
}

foreach my $f (sort { $a cmp $b } keys %pcyx) {
   my $pcy_ref = $pcyx{$f};
   valid_lstdate("TPCYDESCR",$pcy_ref->{lstdate},$f,"PCYNAME=$f");
   if ($pcy_ref->{count} > 1) {
      $advi++;$advonline[$advi] = "TPCYDESC duplicate key PCYNAME";
      $advcode[$advi] = "DATAHEALTH1054E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $f;
      $dupndx{"TPCYDESC"} = 1;
   }
   foreach my $g (sort { $a cmp $b } keys %{$pcy_ref->{sit}}) {
      my $onesit = $g;
      if (!defined $sitx{$onesit}) {
         if ($pcy_ref->{autostart} eq "*YES") {
            $advi++;$advonline[$advi] = "TPCYDESC Wait on SIT or Sit reset - unknown situation $g";
            $advcode[$advi] = "DATAHEALTH1056E";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $f;
         } else {
            $advi++;$advonline[$advi] = "TPCYDESC Wait on SIT or Sit reset - unknown situation $g but policy not autostarted";
            $advcode[$advi] = "DATAHEALTH1065W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $f;
         }
      }
   }
   foreach my $g (sort { $a cmp $b } keys %{$pcy_ref->{eval}}) {
      my $onesit = $g;
      if (!defined $sitx{$onesit}) {
         if ($pcy_ref->{autostart} eq "*YES") {
            $advi++;$advonline[$advi] = "TPCYDESC Evaluate Sit Now - unknown situation $g";
            $advcode[$advi] = "DATAHEALTH1057E";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $f;
         } else {
            $advi++;$advonline[$advi] = "TPCYDESC Evaluate Sit Now - unknown situation $g but policy not autostarted";
            $advcode[$advi] = "DATAHEALTH1066W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $f;
         }
      }
   }
}



my $t3_count = 0;
for ($i=0;$i<=$nsavei;$i++) {
   $t3_count += 1 if substr($nsave[$i],-3,3) eq ":T3";
   $invalid_node = 0;
   if (index("\.\ \*\#",substr($nsave[$i],0,1)) != -1) {
      $invalid_node = 1;
   } else {
      $test_node = $nsave[$i];
      $test_node =~ s/[A-Za-z0-9\*\ \_\-\:\@\$\#\.]//g;
      $invalid_node = 1 if $test_node ne "";
   }
   if ($invalid_node == 1) {
      $advi++;$advonline[$advi] = "TNODESAV invalid node name";
      $advcode[$advi] = "DATAHEALTH1016E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nsave[$i];
   }

   if (index($nsave[$i]," ") != -1) {
      $advi++;$advonline[$advi] = "TNODESAV node name with embedded blank";
      $advcode[$advi] = "DATAHEALTH1049W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nsave[$i];
   }
   $invalid_affinities = 0;
   # first check on dynamic affinities
   # dynamicAffinityRule = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_. "
   if ((substr($nsave_affinities[$i],0,1) eq "%") or (substr($nsave_affinities[$i],0,1) eq "%")) {
      if (substr($nsave_affinities[$i],1) =~ tr/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_\. //c) {
         $invalid_affinities = 1;
      }
   # second check on static affinities
   # affinityRule = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#*"
   } else {
      if ($nsave_affinities[$i] =~ tr/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#\*//c) {
         $invalid_affinities = 1;
      }
   }
   if ($invalid_affinities == 1) {
      $advi++;$advonline[$advi] = "TNODESAV invalid affinities [$nsave_affinities[$i]] for node";
      $advcode[$advi] = "DATAHEALTH1079E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nsave[$i];
   }
   next if $nsave_ct[$i] == 1;
   $advi++;$advonline[$advi] = "TNODESAV duplicate nodes";
   $advcode[$advi] = "DATAHEALTH1007E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $nsave[$i];
   $dupndx{"TNODESAV"} = 1;
}

# Advisory on more than one T3 agent
if ($t3_count > 1) {
   $advi++;$advonline[$advi] = "This ITM has $t3_count AMC [:T3] agents and only one is allowed";
   $advcode[$advi] = "DATAHEALTH1104E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "TEMS";
}


for ($i=0;$i<=$siti;$i++) {
   if (substr($sit[$i],0,8) eq "UADVISOR") {
      if ($sit_autostart[$i] ne "*NO") {              ##check maybe ne "*NO" versus *SYN ????
         my $hx = $hSP2OS{$sit[$i]};
         if (defined $hx) {
            $vtx = $vtnodex{$hx};
            if (defined $vtx) {
               $vtnode_tab[$vtx] += 1;
            }
         }
      }
      if ($sit_autostart[$i] eq "*SYN") {            # count Uadvisor historical sits
         $uadhist += 1 if index($sit_pdt[$i],"TRIGGER") != -1;
         if ($sit[$i] eq "UADVISOR_O4SRV_OPLOG") {
            if ($obj_oplog > 0) {
               $advi++;$advonline[$advi] = "Agent Operation Log Historical Data Collection can cause communications instability";
               $advcode[$advi] = "DATAHEALTH1107W";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $sit[$i];
               my $crit_line = "1,Agent Operation Log Historical Data Collection can cause communications instability";
               push @crits,$crit_line;
            }
         }
         # UADVISOR_OMUNX-527E13E4D_UNIXOS
         # UADVISOR_OMUNX_UNIXOS
         $sit_pdt[$i] =~ / FROM (\S+) /;
         my $atrtab = $1;
         if (defined $atrtab) {
            my $uadv_ref = $uadvx{$atrtab};
            if (!defined $uadv_ref) {
               my %advref = (
                               sits => {},
                               all => 0,
                            );
               $uadv_ref = \%advref;
               $uadvx{$atrtab} = \%advref;
            }
            $uadv_ref->{sits}{$sit[$i]} = 1;
            $uadv_ref->{all} = 1 if index($sit_pdt[$i],'SYSTEM.PARMA("NODELIST","*ALL",4)') != -1;
         }
      }
   }
   # record data about MS_Offline type situations
   $ms_offlinex{$sit[$i]} = $i if index($sit_pdt[$i],"ManagedSystem.Status") != -1;
   next if $sit_ct[$i] == 1;
   $advi++;$advonline[$advi] = "TSITDESC duplicate nodes";
   $advcode[$advi] = "DATAHEALTH1021E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $sit[$i];
   $dupndx{"TSITDESC"} = 1;
}

for ($i=0;$i<=$nami;$i++) {
   next if $nam_ct[$i] == 1;
   $advi++;$advonline[$advi] = "TNAME duplicate nodes";
   $advcode[$advi] = "DATAHEALTH1022E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $nam[$i];
   $dupndx{"TNAME"} = 1;
}

for ($i=0;$i<=$nami;$i++) {
   valid_lstdate("TNAME",$nam_lstdate[$i],$nam[$i],"ID=$nam[$i]");
   next if defined $sitx{$nam[$i]};
   next if substr($nam[$i],0,8) eq "UADVISOR";
   $advi++;$advonline[$advi] = "TNAME ID index missing in TSITDESC";
   $advcode[$advi] = "DATAHEALTH1023W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $nam[$i];
}

my  $ms_offline_kds_hour = 0;
my  $ms_offline_sitmon_hour = 0;
my  $kds_per_sec = 0;
my  $sitmon_per_sec = 0;
my  $ms_offline_count = 0;

for ($i=0;$i<=$siti;$i++) {
   valid_lstdate("TSITDESC",$sit_lstdate[$i],$sit[$i],"SITNAME=$sit[$i]");
   my $pdtone = $sit_pdt[$i];
   my $mysit;
   while($pdtone =~ m/.*?\*SIT (\S+) /g) {
      $mysit = $1;
      next if defined $sitx{$mysit};
      $advi++;$advonline[$advi] = "Situation Formula *SIT [$mysit] Missing from TSITDESC table";
      $advcode[$advi] = "DATAHEALTH1024E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $sit[$i];
   }
   if ($sit_reeval[$i] - $sit_bad_time gt 0) {
      $advi++;$advonline[$advi] = "Situation Sampling Interval $sit_reeval[$i] seconds - higher then danger level $sit_bad_time";
      $advcode[$advi] = "DATAHEALTH1064W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $sit[$i];
   }
   if (index($sit_pdt[$i],"ManagedSystem.Status") != -1) {
      if($sit[$i] ne "TEMS_Busy") {
         if ($sit_autostart[$i] eq "*YES") {
            if ($sit_reeval[$i] > 0 ) {
               $ms_offline_count += 1;
               $ms_offline_kds_hour += 3600/$sit_reeval[$i];
               $ms_offline_sitmon_hour += 3600/$sit_reeval[$i] if $sit_persist[$i] > 1;
            } else {
               $advi++;$advonline[$advi] = "MS_Offline type situation with 0 sampling rate - cannot work correctly";
               $advcode[$advi] = "DATAHEALTH1103W";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $sit[$i];
            }
         }
      }
   }
   $sit_autostart_total += 1 if $sit_autostart[$i] eq "*YES";
   # *IF *VALUE *HSITNAME *EQ OSR_ITMRTEMS_PROCESS_AIX_INFO *AND *VALUE *HNODE *EQ itmrtems01:PX *AND *VALUE *HDELTASTAT *EQ Y *AND *VALUE *HSITNAME *EQ OSR_ITMRTEMS_PROCESS_AIX_INFO *AND *VALUE *HNODE *EQ itmrtems02:PX *AND *VALUE *HDELTASTAT *EQ Y
   if (index($sit_pdt[$i],"*HSITNAME") != -1) {
      my $tcount = () = $sit_pdt[$i] =~ /\bHSITNAME\b/gi; # count number of works with HSITNAME [* is word boundary]
      $sit_correlated += 1;
      $sit_correlated_ct += $tcount;
      $sit_correlated_hour += (3600/$sit_reeval[$i])*$tcount;
      $sit_correlate[$i] = 1;
   }
}
if ($nsave_online > 0){
   my $sit_ratio_percent = int(($sit_autostart_total*100)/$nsave_online);
   if ($sit_ratio_percent > 100) {
      $advi++;$advonline[$advi] = "Autostarted Situation to Online Agent ratio[$sit_ratio_percent%] - dangerously high";
      $advcode[$advi] = "DATAHEALTH1091W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "Situations_High";
   }
}
if ($ms_offline_kds_hour > 0) {
   my $nsave_total = $nsave_online + $nsave_offline;
   $kds_per_sec = ($ms_offline_kds_hour * $nsave_total)/3600;
   $sitmon_per_sec = ($ms_offline_sitmon_hour * $nsave_offline)/3600;
}

if ($ms_offline_sitmon_hour > 0) {
   my $nsave_total = $nsave_online + $nsave_offline;
   $sitmon_per_sec = ($ms_offline_sitmon_hour * $nsave_total)/3600;
}

if ($kds_per_sec > 30) {
    my $prate = sprintf("%.2f",$kds_per_sec);
   if ($kds_per_sec > 200) {
      $advi++;$advonline[$advi] = "MS_Offline[$ms_offline_count] dataserver evaluation rate $prate agents/sec dangerously high";
      $advcode[$advi] = "DATAHEALTH1087E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "MS_Offline";
      my $crit_line = "7,MS_Offline[$ms_offline_count] dataserver evaluation rate $prate agents/sec dangerously high. See DATAREPORT017  ";
      push @crits,$crit_line;
   } else {
      $advi++;$advonline[$advi] = "MS_Offline[$ms_offline_count] dataserver evaluation rate $prate agents/sec somewhat high";
      $advcode[$advi] = "DATAHEALTH1086W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "MS_Offline";
   }
}

if ($sitmon_per_sec > 30) {
    my $prate = sprintf("%.2f",$sitmon_per_sec);
   if ($sitmon_per_sec > 100) {
      $advi++;$advonline[$advi] = "MS_Offline[$ms_offline_count] SITMON evaluation rate $prate agents/sec dangerously high";
      $advcode[$advi] = "DATAHEALTH1089E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "MS_Offline";
      my $crit_line = "7,MS_Offline[$ms_offline_count] SITMON evaluation rate $prate agents/sec dangerously high. See DATAREPORT017  ";
      push @crits,$crit_line;
   } else {
      $advi++;$advonline[$advi] = "MS_Offline[$ms_offline_count] SITMON evaluation rate $prate agents/sec somewhat high";
      $advcode[$advi] = "DATAHEALTH1088W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "MS_Offline";
   }
}



for ($i=0;$i<=$hsavei;$i++) {
   next if $hsave_ct[$i] == 1;
   next if !defined $hsave[$i];

   my $pi;
   my @hagents = split(" ",$hsave_ndx[$i]);
   my $pagents = "";
   my @tagents = split(" ",$hsave_thrundx[$i]);
   for (my $j=0;$j<=$#hagents;$j++) {
      $pi = $hagents[$j];
      my $oneagent = $nsave[$pi];
      my $onethru = $tagents[$j];
      my $nx = $nsavex{$oneagent};
      next if $onethru eq ".";
      if (defined $nx) {
         $pagents .= $nsave[$pi]. "[$onethru][Y] " if $nsave_o4online[$nx] eq "Y";
      } else {
         $pagents .= $nsave[$pi]. "[][Y] " if $nsave_o4online[$nx] eq "Y";
      }
   }
   my @ragents = split(" ",$pagents);
   next if $#ragents < 1;
   $advi++;$advonline[$advi] = "TNODESAV duplicate hostaddr in [$pagents]";
   $advcode[$advi] = "DATAHEALTH1010W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $hsave[$i];
}

my $ssl = 0;
foreach my $f (sort { $b cmp $a } keys %sysnamex) {
   $ssl += 1;
   my $sysname_ref = $sysnamex{$f};
   next if ref($sysname_ref) ne "HASH";
   next if $sysname_ref->{ipcount} == 1;
   my $pagents = "";
   foreach my $g (sort {$a cmp $b} keys %{$sysname_ref->{sysipx}}) {
      my $sysip_ref = $sysname_ref->{sysipx}{$g};
      foreach my $h (sort {$a cmp $b} keys %{$sysip_ref->{instance}}) {
         my $sysname_node_ref = $sysip_ref->{instance}{$h};
         $pagents .= $h . "|";
         $pagents .= $sysname_node_ref->{thrunode} . "|";
         $pagents .= $sysname_node_ref->{hostaddr} . ",";
      }
   }
   $advi++;$advonline[$advi] = "TNODESAV duplicate $sysname_ref->{ipcount} SYSTEM_NAMEs in [$pagents]";
   $advcode[$advi] = "DATAHEALTH1075W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $f;
}

my $tema_multi = 0;
foreach my $f (keys %ipx) {
   my $ip_ref =$ipx{$f};
   next if $ip_ref->{count} < 2;
   $tema_multi += 1;
}

if ($tema_multi > 0) {
   $advi++;$advonline[$advi] = "Systems [$tema_multi] running agents with multiple TEMA levels - see DATAREPORT014";
   $advcode[$advi] = "DATAHEALTH1096W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "TEMA";
}

for ($i=0;$i<=$nlistvi;$i++) {
   valid_lstdate("TNODELST",$nlistv_lstdate[$i],$nlistv[$i],"V NODE=$nlistv[$i] THRUNODE=$nlistv_thrunode[$i]");
   if ($nlistv_ct[$i] > 1) {
      $advi++;$advonline[$advi] = "TNODELST Type V duplicate nodes";
      $advcode[$advi] = "DATAHEALTH1008E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlistv[$i];
      $dupndx{"TNODELST"} = 1;
   }
   my $thru1 = $nlistv_thrunode[$i];
   $nsx = $nsavex{$thru1};
   if (!defined $nsx) {
      $advi++;$advonline[$advi] = "TNODELST Type V Thrunode $thru1 missing in Node Status";
      $advcode[$advi] = "DATAHEALTH1025E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlistv[$i];
      if ($opt_miss == 1) {
         my $key = "DATAHEALTH1025E" . " " . $thru1;
         $miss{$key} = 1;
      }
   }
   if ($nlistv[$i] eq $thru1) {
      if (defined $nsx) {
         if ($nsave_product[$nsx] ne "EM") {
            $advi++;$advonline[$advi] = "TNODELST Type V Node is same as Thrunode - illegal";
            $advcode[$advi] = "DATAHEALTH1105E";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $nlistv[$i];
         }
      }
   }
   $invalid_node = 0;
   if (index("\.\ \*\#",substr($nlistv[$i],0,1)) != -1) {
      $invalid_node = 1;
   } else {
      $test_node = $nlistv[$i];
      $test_node =~ s/[A-Za-z0-9\*\ \_\-\:\@\$\#\.]//g;
      $invalid_node = 1 if $test_node ne "";
   }
   if ($invalid_node == 1) {
      $advi++;$advonline[$advi] = "TNODELST Type V node invalid name";
      $advcode[$advi] = "DATAHEALTH1026E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlistv[$i];
   }
   if (index($nlistv[$i]," ") != -1) {
      $advi++;$advonline[$advi] = "TNODELST TYPE V node name with embedded blank";
      $advcode[$advi] = "DATAHEALTH1050W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlistv[$i];
   }
   $invalid_node = 0;
   if (index("\.\ \*\#",substr($thru1,0,1)) != -1) {
      $invalid_node = 1;
   } else {
      $test_node = $thru1;
      $test_node =~ s/[A-Za-z0-9\*\ \_\-\:\@\$\#\.]//g;
      $invalid_node = 1 if $test_node ne "";
   }
   if ($invalid_node == 1) {
      $advi++;$advonline[$advi] = "TNODELST Type V Thrunode $thru1 invalid name";
      $advcode[$advi] = "DATAHEALTH1027E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlistv[$i];
   }
   if (index($thru1," ") != -1) {
      $advi++;$advonline[$advi] = "TNODELST TYPE V Thrunode [$thru1] with embedded blank";
      $advcode[$advi] = "DATAHEALTH1051W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlistv[$i];
   }
}

##check nodelist validity
for ($i=0;$i<=$nlisti;$i++) {
   $invalid_node = 0;
   if (index("\.\ \#",substr($nlist[$i],0,1)) != -1) {
      $invalid_node = 1;
   } else {
      $test_node = $nlist[$i];
      $test_node =~ s/[A-Za-z0-9\* _\-:@\$\#\.]//g;
      $invalid_node = 1 if $test_node ne "";
   }
   if ($invalid_node == 1) {
      $advi++;$advonline[$advi] = "TNODELST NODETYPE=M invalid nodelist name";
      $advcode[$advi] = "DATAHEALTH1017E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlist[$i];
   }
   if (index($nlist[$i]," ") != -1) {
      $advi++;$advonline[$advi] = "TNODELST NODETYPE=M nodelist with embedded blank";
      $advcode[$advi] = "DATAHEALTH1052W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nlist[$i];
   }
}

# check TOBJACCL validity
for ($i=0;$i<=$obji;$i++){
   valid_lstdate("TOBJACCL",$obj_lstdate[$i],$obj_objname[$i],"NODEL=$obj_nodel[$i] OBJCLASS=$obj_objclass[$i] OBJNAME=$obj_objname[$i]");
   if ($obj_ct[$i] > 1) {
      $advi++;$advonline[$advi] = "TOBJACCL duplicate nodes";
      $advcode[$advi] = "DATAHEALTH1028E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $obj[$i];
      $dupndx{"TOBJACCL"} = 1;
   }
   my $objname1 = $obj_objname[$i];
   my $nodel1 = $obj_nodel[$i];
   my $class1 = $obj_objclass[$i];
   $sx = $sitx{$objname1};
   if (defined $sx) {
      next if $sit_autostart[$sx] eq "*NO";
   }
   $mx = $nlistx{$nodel1};
   $nsx = $nsavex{$nodel1};
   if ($class1 == 5140) {
      if (defined $mx) {                        # MSL defined
         if (!defined $sx) {                    # Sit not defined
            if (substr($objname1,0,3) ne "_Z_"){
               $advi++;$advonline[$advi] = "TOBJACCL Unknown Situation with a known MSL $nodel1 distribution";
               $advcode[$advi] = "DATAHEALTH1099W";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $objname1;
            }
         }
      } elsif (defined $nsx) {                  # MSN defined
         if (!defined $sx) {                    # Sit not defined
            if (substr($objname1,0,3) ne "_Z_"){
                  $advi++;$advonline[$advi] = "TOBJACCL Unknown Situation with a known MSN $nodel1 distribution";
                  $advcode[$advi] = "DATAHEALTH1100W";
                  $advimpact[$advi] = $advcx{$advcode[$advi]};
                  $advsit[$advi] = $objname1;
            }
         }
      } else {                                  # Neither MSL nor MSN defined
         if (defined $sx) {                     # Sit is defined
            if (substr($nodel1,0,1) ne "*") {
               $advi++;$advonline[$advi] = "TOBJACCL known Situation with a unknown MSN/MSL $nodel1 distribution";
               $advcode[$advi] = "DATAHEALTH1101E";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $objname1;
            } else {
               $advi++;$advonline[$advi] = "TOBJACCL known Situation with a unknown system generated MSL $nodel1";
               $advcode[$advi] = "DATAHEALTH1102W";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $objname1;
            }
         } else {                               # Sit not defined
            if (substr($objname1,0,3) ne "_Z_"){
               $advi++;$advonline[$advi] = "TOBJACCL unknown Situation with a unknown MSN/MSL $nodel1 distribution";
               $advcode[$advi] = "DATAHEALTH1030W";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $objname1;
            }
         }
      }
      next if defined $mx;         # if known as a MSL, no check for node status
      my $nodist = 0;
      if ($opt_nodist ne "") {
         if (substr($nodel1,0,length($opt_nodist)) eq $opt_nodist){
            $nodist = 1;
         }
         if (substr($objname1,0,length($opt_nodist)) eq $opt_nodist){
            $nodist = 1;
         }
      }
      next if $nodist == 1;
      if (substr($nodel1,0,1) eq "*") {
         $advi++;$advonline[$advi] = "TOBJACCL Nodel $nodel1 System Generated MSL but missing from TNODELST";
         $advcode[$advi] = "DATAHEALTH1029W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $obj[$i];
         if ($opt_miss == 1) {
            my $pick = $obj[$i];
            $pick =~ /.*\|.*\|(.*)/;
            my $key = "DATAHEALTH1029W" . " " . $1;
            $miss{$key} = 1;
         }
         next;
      }
      if ($opt_miss == 1) {
         my $pick = $obj[$i];
         $pick =~ /.*\|.*\|(.*)/;
         my $key = "DATAHEALTH1030W" . " " . $1;
         $miss{$key} = 1;
      }
   } elsif ($class1 == 2010) {
      next if defined $groupx{$objname1};       # if item being distributed is known as a situation group, good
      $advi++;$advonline[$advi] = "TOBJACCL Group name missing in Situation Group";
      $advcode[$advi] = "DATAHEALTH1035W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $nodel1;
      if ($opt_miss == 1) {
         my $pick = $nodel1;
         $pick =~ /.*\|.*\|(.*)/;
         my $key = "DATAHEALTH1035W" . " " . $1;
         $miss{$key} = 1;
      }
   }
}



##check for TEMA level 6.1
for ($i=0;$i<=$nsavei;$i++) {
   next if $nsave_temaver[$i] eq "";
   next if substr($nsave_temaver[$i],0,5) gt "06.10";
   $advi++;$advonline[$advi] = "Agent using TEMA at $nsave_temaver[$i] level";
   $advcode[$advi] = "DATAHEALTH1019W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $nsave[$i];
}
## Check for TEMA level below Agent version
for ($i=0;$i<=$nsavei;$i++) {
   next if $nsave_temaver[$i] eq "";
   next if !defined $klevelx{substr($nsave_version[$i],0,5)};
   next if substr($nsave_temaver[$i],0,2) ne substr($nsave_version[$i],0,2);
   next if substr($nsave_version[$i],0,5) gt substr($tema_maxlevel,0,5);
   next if substr($nsave_temaver[$i],0,5) ge substr($nsave_version[$i],0,5);
   $advi++;$advonline[$advi] = "Agent at version [$nsave_version[$i]] using TEMA at lower release version [$nsave_temaver[$i]]";
   $advcode[$advi] = "DATAHEALTH1037W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $nsave[$i];
}

## Check for TEMA level in danger zones
my $danger_IZ76410 = 0;
my $danger_IV18016 = 0;
my $danger_IV30473 = 0;
for ($i=0;$i<=$nsavei;$i++) {
   next if $nsave_temaver[$i] eq "";
   if ( (substr($nsave_temaver[$i],0,8) ge "06.21.00") and (substr($nsave_temaver[$i],0,8) lt "06.21.03") or
        (substr($nsave_temaver[$i],0,8) ge "06.22.00") and (substr($nsave_temaver[$i],0,8) lt "06.22.03")) {
      $danger_IZ76410 += 1 if $nsave_product[$i] ne "VA";
   }
   if ( (substr($nsave_temaver[$i],0,8) eq "06.22.07") or (substr($nsave_temaver[$i],0,8) eq "06.23.01")) {
      $danger_IV18016 += 1;
   }
   if ( ((substr($nsave_temaver[$i],0,8) ge "06.22.07") and (substr($nsave_temaver[$i],0,8) le "06.22.09")) or
        ((substr($nsave_temaver[$i],0,8) ge "06.23.00") and (substr($nsave_temaver[$i],0,8) le "06.23.02"))) {
      $danger_IV30473 += 1;
   }

}

if ($danger_IZ76410 > 0) {
   $advi++;$advonline[$advi] = "Agents[$danger_IZ76410] using TEMA in IZ76410 danger zone - see DATAREPORT011";
   $advcode[$advi] = "DATAHEALTH1042E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "APAR";
}

if ($danger_IV18016 > 0) {
   $advi++;$advonline[$advi] = "Agents[$danger_IV18016] using TEMA in IV18016 danger zone - see DATAREPORT012";
   $advcode[$advi] = "DATAHEALTH1090W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "APAR";
}

if ($danger_IV30473 > 0) {
   $advi++;$advonline[$advi] = "Agents[$danger_IV30473] using TEMA in IV30473 danger zone - see DATAREPORT013";
   $advcode[$advi] = "DATAHEALTH1093W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "APAR";
}

## Check for virtual hub table update impact
my $peak_rate = 0;
for ($i=0;$i<=$vti;$i++) {
   next if $vtnode_tab[$i] == 0;
   my $node_hr = (60/$vtnode_rate[$i])*$vtnode_tab[$i];
   $vtnode_hr[$i] = $node_hr*$vtnode_ct[$i];
   $vtnode_tot_hr += $vtnode_hr[$i];
   $peak_rate +=  $vtnode_ct[$i] * $vtnode_tab[$i];
}

if ($peak_rate > $opt_peak_rate) {
   for ($i=0;$i<=$vti;$i++) {
      next if $vtnode_hr[$i] == 0;
      $advi++;$advonline[$advi] = "Virtual Hub Table updates $vtnode_hr[$i] per hour $vtnode_ct[$i] agents";
      $advcode[$advi] = "DATAHEALTH1018W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $vtnode[$i];
   }
   $advi++;$advonline[$advi] = "Virtual Hub Table updates peak $peak_rate per second more then nominal $opt_peak_rate -  per hour [$vtnode_tot_hr] - total agents $vtnode_tot_ct - See DATAREPORT020";
   $advcode[$advi] = "DATAHEALTH1018W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "total";
   my $crit_line = "5,Virtual Hub Table updates peak $peak_rate per second more then nominal $opt_peak_rate -  per hour [$vtnode_tot_hr] - total agents $vtnode_tot_ct - See DATAREPORT020";
   push @crits,$crit_line;
}

for ($i=0;$i<=$mlisti;$i++) {
   valid_lstdate("TNODELST",$mlist_lstdate[$i],$mlist_node[$i],"M NODE=$mlist_node[$i] NODELST=$mlist_nodelist[$i]");
   next if $mlist_ct[$i] == 1;
   $advi++;$advonline[$advi] = "TNODELST Type M duplicate NODE/NODELIST";
   $advcode[$advi] = "DATAHEALTH1009E";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $mlist[$i];
   $dupndx{"TNODELST"} = 1;
}

# Following logic estimates the dataserver load per TEMS based on number of situations.
# Load Step 1: calculate the situation distribution
# Load Step 2: Calculate the dataserver load
# Load Step 3: Produce advisory messages
# A post advisory report is created based on this calculated data.

# look through each TOBJACCL row
for ($i=0;$i<=$obji;$i++) {
   next if ($obj_objclass[$i] ne "5140") and ($obj_objclass[$i] ne "2010");         # ignore if not situation or sitgroup distribution
   my $sitone = $obj_objname[$i];               # situation being looked at or Sitgroup

   next if substr($sitone,0,8) eq "UADVISOR";
   next if substr($sitone,0,3) eq "_Z_";
   my $node1 = $obj_nodel[$i];                  # distribution
   $sx = $sitx{$sitone};
   $gx = $grpx{$sitone};
   $nlx = $nlistx{$node1};
   $vlx = $nlistvx{$node1};
   # For each agent in found, determine thrunode/TEMS. Add to thrunode count, sampled count, pure count, sampled impact
   # handle subnode agents via the managing agent
   my $thru = "";
   if (defined $sx) {             # Situation name
      if (defined $nlx) {         # a MSL distribution
         # read out the agents associated with this MSL
         foreach my $f (keys %{$nlist_agents[$nlx]}) {
            $mx = $magentx{$f};    # is this a subnode agent
            if (defined $mx) {
               $thru = $magent_tems[$mx];
            } else {
               if (defined $vlx) {
                  $thru = $nlistv_tems[$vlx];
               }
            }
            if ($thru ne "") {
               $tx = $temsx{$thru};
               if (defined $tx) {
                  if (!defined $tems_sits[$tx]{$sitone}) {
                     $tems_sits[$tx]{$sitone} = 1;
                     if ($sit_reeval[$sx] == 0) {
                        $tems_puresit[$tx] += 1;
                        $tems_puresit_dedup[$tx] += 1 if $sit_pdtseq[$sx] == 1;
                     } else {
                        $tems_sampsit[$tx] += 1;
                        $tems_sampsit_dedup[$tx] += 1  if $sit_pdtseq[$sx] == 1;
                        $tems_sampload[$tx] += (3600)/$sit_reeval[$sx];
                        $tems_sampload_dedup[$tx] += (3600)/$sit_reeval[$sx] if $sit_pdtseq[$sx] == 1;
                     }
                  }
               }
            }
            if (defined $vlx) {
               if (defined $sx) {
                  $nlistv_sitx[$vlx]{$sit[$sx]} = 1;
               }
            }
         }
      } else {                    # a MSN distribution
         $mx = $magentx{$node1};    # is this a subnode agent
         if (defined $mx) {
            $thru = $magent_tems[$mx];
         } else {
            $vlx = $nlistvx{$node1};
            if (defined $vlx) {
               $thru = $nlistv_tems[$vlx];
            }
         }
         if ($thru ne "") {
            $tx = $temsx{$thru};
            if (defined $tx) {
               if (!defined $tems_sits[$tx]{$sitone}) {
                  $tems_sits[$tx]{$sitone} = 1;
                  if (defined $tx) {
                     if ($sit_reeval[$sx] == 0) {
                        $tems_puresit[$tx] += 1;
                        $tems_puresit_dedup[$tx] += 1 if $sit_pdtseq[$sx] == 1;
                     } else {
                        $tems_sampsit[$tx] += 1;
                        $tems_sampsit_dedup[$tx] += 1  if $sit_pdtseq[$sx] == 1;
                        $tems_sampload[$tx] += (3600)/$sit_reeval[$sx];
                        $tems_sampload_dedup[$tx] += (3600)/$sit_reeval[$sx] if $sit_pdtseq[$sx] == 1;
                     }
                  }
               }
            }
         }
      }
   } elsif (defined $gx) {        # Sitgroup Identification
      # determine the associated situations
      %sum_sits = ();
      sitgroup_get_sits($gx);
      if (defined $nlx) {         # a MSL distribution
         # read out the agents associated with this MSL
         foreach my $f (keys %{$nlist_agents[$nlx]}) {
            $mx = $magentx{$f};    # is this a subnode agent
            if (defined $mx) {
               $thru = $magent_tems[$mx];
            } else {
               $vlx = $nlistvx{$f};
               if (defined $vlx) {
                  $thru = $nlistv_tems[$vlx];
               }
            }
            if ($thru ne "") {
               $tx = $temsx{$thru};
               if (defined $tx) {
                  foreach my $s (keys %sum_sits) {
                     $sx =  $sitx{$s};
                     next if !defined $sx;
                     if (!defined $tems_sits[$tx]{$s}) {
                        $tems_sits[$tx]{$s} = 1;
                        if ($sit_reeval[$sx] == 0) {
                           $tems_puresit[$tx] += 1;
                           $tems_puresit_dedup[$tx] += 1 if $sit_pdtseq[$sx] == 1;
                        } else {
                           $tems_sampsit[$tx] += 1;
                           $tems_sampsit_dedup[$tx] += 1  if $sit_pdtseq[$sx] == 1;
                           $tems_sampload[$tx] += (3600)/$sit_reeval[$sx];
                           $tems_sampload_dedup[$tx] += (3600)/$sit_reeval[$sx] if $sit_pdtseq[$sx] == 1;
                        }
                     }
                  }
               }
            }
         }
      } else {                    # a MSN distribution
         $mx = $magentx{$node1};    # is this a subnode agent
         if (defined $mx) {
            $thru = $magent_tems[$mx];
         } else {
            $vlx = $nlistvx{$node1};
            if (defined $vlx) {
               $thru = $nlistv_tems[$vlx];
            }
         }
         if ($thru ne "") {
            $tx = $temsx{$thru};
            if (defined $tx) {
               foreach my $s (keys %sum_sits) {
                  $sx =  $sitx{$s};
                  next if !defined $sx;
                  if (!defined $tems_sits[$tx]{$s}) {
                     $tems_sits[$tx]{$s} = 1;
                     if ($sit_reeval[$sx] == 0) {
                        $tems_puresit[$tx] += 1;
                        $tems_puresit_dedup[$tx] += 1 if $sit_pdtseq[$sx] == 1;
                     } else {
                        $tems_sampsit[$tx] += 1;
                        $tems_sampsit_dedup[$tx] += 1  if $sit_pdtseq[$sx] == 1;
                        $tems_sampload[$tx] += (3600)/$sit_reeval[$sx];
                        $tems_sampload_dedup[$tx] += (3600)/$sit_reeval[$sx] if $sit_pdtseq[$sx] == 1;
                     }
                  }
               }
            }
         }
      }
   }
}


# second trip for UADVISORs looking for Virtual Hub Table cases distributed by TEMS [original scheme]
# look through each Situation
for (my $s=0;$s<=$siti;$s++) {
   my $sitone = $sit[$s];                    # situation being looked at
   next if $sit_autostart[$s] eq "*NO";
   next if !defined $hSP2OS{$sitone};
   my $iproduct = $hSP2OS{$sitone};
   for ($i=0;$i<=$nlistvi;$i++) {
      next if $nlistv_tems[$i] eq "";
      $tx = $temsx{$nlistv_tems[$i]};
      my $inode = $nlistv[$i];
      my $nx = $nsavex{$inode};
      if (defined $nx) {
         if ($nsave_product[$nx] eq $iproduct) {
            $tems_vtbl[$tx]{$iproduct} += 1;
         }
      }
   }
}

# Third trip seeing if situations are distributed
for (my $s=0;$s<=$siti;$s++) {
   my $sitone = $sit[$s];                    # situation being looked at
   next if defined $tobjaccl{$sitone};
   next if defined $tgroupi{$sitone};
   next if substr($sitone,0,8) eq "UADVISOR";
   $advi++;$advonline[$advi] = "Situation not distributed by MSN/MSL/SitGroup";
   $advcode[$advi] = "DATAHEALTH1112W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $sitone;
   if ($opt_delu == 1) {
      my $outsh  = "./tacmd deleteSit -s " . $sitone;
      my $outcmd = "tacmd deleteSit -s " . $sitone;
      my $outcsv = $sitone . "," . $sit_autostart[$s] . ",";
      print DELSH  "$outsh\n";
      print DELCMD "$outcmd\n";
      print DELCSV "$outcsv\n";
   }
}

if ($sit_correlated > 0) {
   $rptkey = "DATAREPORT023";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Correlated Situation Report\n";
   $cnt++;$oline[$cnt]="Situation,\n";
   for (my $s=0;$s<=$siti;$s++) {
      next if $sit_correlate[$s] == 0;
      $outline = $sit_psit[$s] . ",";
      $cnt++;$oline[$cnt]="$outline\n";
   }
   if ($sit_correlated_hour > 12) {
      $advi++;$advonline[$advi] = "Correlated Situations [$sit_correlated] at $sit_correlated_hour per hour - see $rptkey";
      $advcode[$advi] = "DATAHEALTH1114E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "TEMS";
      my $crit_line = "1,Correlated Situations [$sit_correlated] at $sit_correlated_hour per hour - see $rptkey'";
      push @crits,$crit_line;
   } else {
      $advi++;$advonline[$advi] = "Correlated Situations [$sit_correlated] at $sit_correlated_hour per hour - see $rptkey";
      $advcode[$advi] = "DATAHEALTH1113W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "TEMS";
   }
}

if ($sit_purettl > 0) {
   $rptkey = "DATAREPORT024";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Pure Situations with TTL More than 15 minutes\n";
   $cnt++;$oline[$cnt]="Situation,secs,ttl,\n";
   my $dcount = 0;
   for (my $s=0;$s<=$siti;$s++) {
      next if $sit_until_ttl[$s] eq "";
      my @itimes = split(":",$sit_until_ttl[$s]);
      my $dtime = $itimes[0]*86400+$itimes[1]*3600+$itimes[2]*60+$itimes[3];
      if ($dtime > 900) {
         $outline = $sit_psit[$s] . ",";
         $outline .= $dtime . ",";
         $outline .= $sit_until_ttl[$s] . ",";
         $cnt++;$oline[$cnt]="$outline\n";
         $dcount += 1;
      }
   }
   if ($dcount > 0) {
      $advi++;$advonline[$advi] = "Pure situations with TTL > 15 minutes [$dcount] - see $rptkey";
      $advcode[$advi] = "DATAHEALTH1116W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "TEMS";
   }
}


if ($opt_delu == 1) {
   close(DELSH);
   close(DELCMD);
   close(DELCSV);
}


   my $remote_limit = 1500;
if ($hub_tems_no_tnodesav == 0) {
   if (defined $hubi) {
      my $hub_limit = 10000;
      $hub_limit = 20000 if substr($tems_version[$hubi],0,5) gt "06.23";

      if ($hub_tems_ct > $hub_limit){
         $advi++;$advonline[$advi] = "Hub TEMS has $hub_tems_ct managed systems which exceeds limits $hub_limit";
         $advcode[$advi] = "DATAHEALTH1005W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $hub_tems;
      }
      if ($tems_version[$hubi]  eq "06.30.02") {
         $advi++;$advonline[$advi] = "Danger of TEMS crash sending events to receiver APAR IV50167";
         $advcode[$advi] = "DATAHEALTH1067E";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $hub_tems;
      }
   }




   $rptkey = "DATAREPORT001";$advrptx{$rptkey} = 1;         # record report key
   $scnt++;$sline[$scnt]="$rptkey: Hub,$hub_tems,$hub_tems_ct,$splevel,\n";
   for (my $i=0;$i<=$temsi;$i++) {
      if ($tems_ct[$i] > $remote_limit){
         $advi++;$advonline[$advi] = "TEMS has $tems_ct[$i] managed systems which exceeds limits $remote_limit";
         $advcode[$advi] = "DATAHEALTH1006W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $tems[$i];
      }
      my $tlevel = substr($tems_version[$i],0,5);
      my $tlevel_ref = $eoslevelx{$tlevel};
      if (defined $tlevel_ref) {
         if ($tlevel_ref->{future} == 0) {
            $advi++;$advonline[$advi] = "End of Service TEMS $tems[$i] maint[$tems_version[$i]] date[$tlevel_ref->{date}]";
            $advcode[$advi] = "DATAHEALTH1083W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = "eos";
         } else {
            $advi++;$advonline[$advi] = "Future End of Service TEMS $tems[$i] maint[$tems_version[$i]] date[$tlevel_ref->{date}]";
            $advcode[$advi] = "DATAHEALTH1084W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = "eos";
         }
      }
      if ($tems[$i] ne $hub_tems) {
         if (substr($tems_version[$i],0,5) gt substr($hub_tems_version,0,5)) {
            $advi++;$advonline[$advi] = "Remote TEMS $tems[$i] maint[$tems_version[$i]] is later level than Hub TEMS $hub_tems maint[$hub_tems_version]";
            $advcode[$advi] = "DATAHEALTH1097W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = "TEMS";
         }
      }
      my $poffline = "Offline";
      my $node1 = $tems[$i];
      my $nx = $nsavex{$node1};
      if (defined $nx) {
         $poffline = "Online" if $nsave_o4online[$nx] eq "Y";
      }
      my $sit_rate = $tems_sampload[$i]/3600;
      my $psit_rate = sprintf("%.2f",$sit_rate);
      if ($sit_rate > 4) {
         $advi++;$advonline[$advi] = "TEMS Dataserver SQL Situation Load $psit_rate per second more than 4.00/second";
         $advcode[$advi] = "DATAHEALTH1092W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = "$tems[$i]";
      }
      my $sit_total = $tems_sampsit[$i] + $tems_puresit[$i];
      if ($sit_total > 2000) {
         if ($tems[$i] eq $hub_tems) {
            $advi++;$advonline[$advi] = "HUB TEMS Dataserver SQL Situation Startup total $sit_total more than 2000";
            $advcode[$advi] = "DATAHEALTH1095W";
         } else {
            $advi++;$advonline[$advi] = "TEMS Dataserver SQL Situation Startup total $sit_total more than 2000";
            $advcode[$advi] = "DATAHEALTH1094W";
        }
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = "$tems[$i]";
      }
      $scnt++;$sline[$scnt]="TEMS,$tems[$i],$tems_ct[$i],$poffline,$tems_version[$i],$tems_arch[$i],$tems_hostaddr[$i]\n";
   }
   for (my $i=0;$i<=$tepsi;$i++) {
      my $poffline = "Offline";
      my $node1 = $teps[$i];
      my $nx = $nsavex{$node1};
      if (defined $nx) {
         $poffline = "Online" if $nsave_o4online[$nx] eq "Y";
      }
      $scnt++;$sline[$scnt]="TEPS,$teps[$i],,$poffline,$teps_version[$i],$teps_arch[$i],\n";
   }
   $scnt++;$sline[$scnt]="\n";

   $scnt++;$sline[$scnt]="i/5 Agent Level report\n";
   foreach my $f (sort { $a cmp $b } keys %ka4x) {
      my $i = $ka4x{$f};
      my $ka4_ct = $ka4_version_count[$ka4x{$f}];
      $scnt++;$sline[$scnt]=$ka4_product[$i] . "," . $ka4_version[$i] . "," . $ka4_version_count[$i] . ",\n";
   }
   $scnt++;$sline[$scnt]="\n";


   # One case had 3 TEMS in FTO mode - so check for 2 or more
   if ($isFTO >= 2){
      $cnt++;$oline[$cnt]="Fault Tolerant Option FTO enabled Status[$opt_fto]\n\n";
      if (defined $hubi) {
         if ($tems_ctnok[$hubi] > 0) {
            $advi++;$advonline[$advi] = "FTO hub TEMS has $tems_ctnok[$hubi] agents configured which is against FTO best practice";
            $advcode[$advi] = "DATAHEALTH1020W";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $hub_tems;
         }
      }
   }
}

my $fraction;
my $pfraction;

if ($tema_total_eos > 0) {
   foreach my $f (sort { $a cmp $b } keys %eoslevelx) {
      my $tlevel_ref = $eoslevelx{$f};
      next if $tlevel_ref->{count} == 0;
      if ($tlevel_ref->{future} == 0) {
         $advi++;$advonline[$advi] = "End of Service agents maint[$f] count[$tlevel_ref->{count}] date[$tlevel_ref->{date}]";
         $advcode[$advi] = "DATAHEALTH1081W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = "eos";
      } else {
         $advi++;$advonline[$advi] = "Future End of Service agents maint[$f] count[$tlevel_ref->{count}] date[$tlevel_ref->{date}]";
         $advcode[$advi] = "DATAHEALTH1082W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = "eos";
      }
   }
}


# check on case with historical data collection but no WPAs running
if ($uadhist > 0) {
   if ($hdonline == 0) {
      $advi++;$advonline[$advi] = "UADVISOR Historical Situations enabled [$uadhist] but no online WPAs seen";
      $advcode[$advi] = "DATAHEALTH1098E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "TEMS";
   }
}

# Calculate for same agent inserted into TNODELST multiple times the mode [most common frequency]
my %online_count = ();
my $online_mode = 0;
foreach my $f (keys %eibnodex) {
   $online_count{$eibnodex{$f}->{count}} += 1;
}

for my $k (sort {$online_count{$b} <=> $online_count{$a}} keys %online_count) {
   $online_mode = $k;
   last;
}

# Calculate advisories for same agent inserted into TNODELST multiple times more then most common
# This is an important signal about identically named agents on different systems.
$top20 = 0;
foreach my $f (sort { $eibnodex{$b}->{count} <=> $eibnodex{$a}->{count} ||
                      $a cmp $b
                    } keys %eibnodex) {
   last if $eibnodex{$f}->{count} <= $online_mode;
   $top20 += 1;
   if ($eibnodex{$f}->{count} > 2) {
      $advi++;$advonline[$advi] = "Agent registering $eibnodex{$f}->{count} times: possible duplicate agent names";
      $advcode[$advi] = "DATAHEALTH1068E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $f;
   }
   last if $top20 > 19;
}

my $event_ct = keys %eventx;

$top20 = 0;
$eventx_dur = 0;
if ($event_ct > 0) {
   foreach my $f (sort { $eventx{$b}->{count} <=> $eventx{$a}->{count} ||
                         $a cmp $b
                       } keys %eventx) {
      $top20 += 1;
      last if $top20 > 20;
      my $ncount = keys %{$eventx{$f}->{origin}};
      my $sit_start = $eventx{$f}->{start};
      my $sit_last = $eventx{$f}->{last};
      my $sit_dur = get_epoch($sit_last) - get_epoch($sit_start) + 1;
      my $sit_rate = ($eventx{$f}->{count}*60)/$sit_dur;
      my $psit_rate = sprintf("%.2f",$sit_rate);
      if ($sit_rate > 3) {
         my $pnodes;
         for my $g (keys %{$eventx{$f}->{nodes}}) {
            $pnodes .= $g . " ";
         }
         $advi++;$advonline[$advi] = "Situation Event arriving $psit_rate per minute in $sit_dur second(s) from nodes[$pnodes] Atomize[$eventx{$f}->{atomize}]";
         $advcode[$advi] = "DATAHEALTH1074W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $eventx{$f}->{sitname};
      }
   }
}
$eventx_dur = 1;
if ($eventx_last != -1) {
   $eventx_dur = get_epoch($eventx_last) - get_epoch($eventx_start);
}
if ($top20 != 0) {
   $scnt++;$sline[$scnt]="Event Duration,$eventx_dur seconds,\n";
}

# check for ghost situation event status
foreach my $f (sort { $eventx{$b}->{count} <=> $eventx{$a}->{count} ||
                      $a cmp $b
                    } keys %eventx) {
   next if defined $sitx{$eventx{$f}->{sitname}};
   my $pnodes;
   for my $g (keys %{$eventx{$f}->{nodes}}) {
      $pnodes .= $g . " ";
   }

   $advi++;$advonline[$advi] = "Situation undefined but Events arriving from nodes[$pnodes]";
   $advcode[$advi] = "DATAHEALTH1085W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = $f;
}

my $tadvi = 0;
my $eventx_ct = 0;
foreach my $f (sort { $eventx{$b}->{count} <=> $eventx{$a}->{count} ||
                      $a cmp $b
                    } keys %eventx) {
   $eventx_ct += $eventx{$f}->{count};
}
if ($eventx_ct > 0) {
   if ($eventx_dur >1) {
      my $sit_rate = ($eventx_ct*60)/$eventx_dur;
      my $psit_rate = sprintf("%.2f",$sit_rate);
      if ($sit_rate > 60) {
         $advi++;$advonline[$advi] = "Situation Status Events arriving $psit_rate per minute";
         $advcode[$advi] = "DATAHEALTH1080W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = "sitrate";
      }
   }
}
my $ipr_ct = 0;
my $iprerr_ct = 0;
foreach my $f (keys %ipx) {
   my $ip_ref = $ipx{$f};
   my $hcount = scalar keys %{$ip_ref->{hostname}};
   if ($hcount > 1) {
      my %hostx;
      foreach my $g (keys %{$ip_ref->{hostname}}) {
         $hostx{$g} = 1;
      }
      $hcount = scalar keys %hostx;
      if ($hcount > 1) {
         $iprerr_ct += 1;
      }
   }
}
if ($iprerr_ct > 0) {
   $advi++;$advonline[$advi] = "Systems [$iprerr_ct] with agents that disagree on hostname - see DATAREPORT015";
   $advcode[$advi] = "DATAHEALTH1106W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "TEMS";
}
my $agenthubi = scalar keys %agenthubx;
my $agenthubni = scalar keys %agenthubnx;

if ($agenthubi > 0) {
   $advi++;$advonline[$advi] = "Agents [$agenthubi] connected via hub TEMS when Remote TEMS are available";
   $advcode[$advi] = "DATAHEALTH1109W";
   $advimpact[$advi] = $advcx{$advcode[$advi]};
   $advsit[$advi] = "TEMS";
}



$rptkey = "DATAREPORT002";$advrptx{$rptkey} = 1;         # record report key
$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="$rptkey: Top 20 most recently added or changed Situations\n";
$cnt++;$oline[$cnt]="LSTDATE,Situation,Formula\n";
$top20 = 0;
foreach my $f ( sort { $sit_lstdate[$sitx{$b}] cmp $sit_lstdate[$sitx{$a}]} keys %sitx) {
   $top20 += 1;
   my $j = $sitx{$f};
   $cnt++;$oline[$cnt]="=\"$sit_lstdate[$j]\",$sit_psit[$j],$sit_pdt[$j],\n";
   last if $top20 >= 20;
}

if ($tema_total_count > 0 ){
   $rptkey = "DATAREPORT003";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: TEMA Deficit Report Summary - 132 TEMA APARs to latest maintenance ITM 630 FP6\n";
   $oneline = $tema_total_count . ",Agents with TEMA,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = $tema_total_good_count . ",Agents with TEMA version same as TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = $tema_total_deficit_count . ",Agents with TEMA version lower than TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = $tema_total_post_count . ",Agents with TEMA version higher than TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $fraction = ($tema_total_deficit_count*100) / $tema_total_count;
   $pfraction = sprintf( "%.2f", $fraction);
   $oneline = $pfraction . "%,Per cent TEMAs less than TEMS version,";
   $tema_total_deficit_percent = $pfraction;
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = $tema_total_days . ",Total Days TEMA version less than TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $fraction = 0;
   $fraction = ($tema_total_days) / $tema_total_apars if $tema_total_apars > 0;
   $oneline = sprintf( "%.0f", $fraction) . ",Average days/APAR TEMA version less than TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = $tema_total_apars . ",Total APARS TEMA version less than TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $fraction = ($tema_total_apars) / $tema_total_count;
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = sprintf( "%.0f", $fraction) . ",Average APARS TEMA version less than TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = $tema_total_max_days . ",Total Days TEMA version less than latest TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $fraction = 0;
   $fraction = ($tema_total_max_days) / $tema_total_max_apars if $tema_total_max_apars > 0;
   $oneline = sprintf( "%.0f", $fraction) . ",Average days/APAR TEMA version less than latest TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $oneline = $tema_total_max_apars . ",Total APARS TEMA version less than latest TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
   $fraction = ($tema_total_max_apars) / $tema_total_count;
   $oneline = sprintf( "%.0f", $fraction) . ",Average APARS TEMA version less than latest TEMS version,";
   $cnt++;$oline[$cnt]="$oneline\n";
}

if ($npc_ct > 0 ) {
   $rptkey = "DATAREPORT004";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Product Summary Report\n";
   $cnt++;$oline[$cnt]="Product[Agent],Count,Versions,TEMAs,Name,\n";
   foreach my $f (sort { $a cmp $b } keys %pcx) {
      my $pc_ref = $pcx{$f};
      $oneline = $f . "," . $pc_ref->{count} . ",";

      my $pversions = "";
      foreach my $g  (sort { $a cmp $b } keys %{$pc_ref->{versions}}) {
         my $version_ref = $pc_ref->{versions}{$g};
         $pversions .= $g . "(" . $version_ref->{count} . ") ";
      }
      $pversions = substr($pversions,0,-1) if $pversions ne "";
      $oneline .= "Versions[" . $pversions . "],";

      my $ptemas = "";
      foreach my $g  (sort { $a cmp $b } keys %{$pc_ref->{temas}}) {
         my $tema_ref = $pc_ref->{temas}{$g};
         $ptemas .= $g . "(" . $tema_ref->{count} . ") ";
      }
      $ptemas = substr($ptemas,0,-1) if $ptemas ne "";
      $oneline .= "TEMAs[" . $ptemas . "],";

      my $pinfo = "";
      foreach my $g  (sort { $a cmp $b } keys %{$pc_ref->{info}}) {
         my $info_ref = $pc_ref->{info}{$g};
         $pinfo .= $g . "(" . $info_ref->{count} . ") ";
      }
      $pinfo = substr($pinfo,0,-1) if $pinfo ne "";
      $oneline .= "INFOs[" . $pinfo . "],";
      my $pcname = "";
      $pcname = $knownpc{$f} if defined $knownpc{$f};
      if ($pcname eq "")  {
         $f =~ /(\d+)/;
         my $agent_digits = $1;
         if (defined $agent_digits) {
            $pcname = "Agent-Builder-" . $f if $f eq $agent_digits;
         }
      }
      $oneline .= $pcname . ",";

      $cnt++;$oline[$cnt]="$oneline\n";
   }

}


if ($opt_event == 1){
   $rptkey = "DATAREPORT005";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Flapper Situation Report\n";
   $cnt++;$oline[$cnt]="Situation,Atomize,Count,Open,Close,Node,Thrunode,Interval\n";
   foreach my $f (sort { $eventx{$b}->{count} <=> $eventx{$a}->{count} ||
                         $a cmp $b
                        } keys %eventx) {
      foreach my $g (sort {$a cmp $b} keys  %{$eventx{$f}->{origin}}) {
         next if $eventx{$f}->{reeval} == 0;                                    # ignore pure events for this report
         next if $eventx{$f}->{origin}{$g}->{count} == 1;             # ignore single cases
         my $diff = abs($eventx{$f}->{origin}{$g}->{open}-$eventx{$f}->{origin}{$g}->{close});
         next if $diff < 2;
         $oneline = $eventx{$f}->{sitname} . ",";
         $oneline .= $eventx{$f}->{atomize} . ",";
         $oneline .=  $eventx{$f}->{origin}{$g}->{count} . ",";
         $oneline .=  $eventx{$f}->{origin}{$g}->{open} . ",";
         $oneline .=  $eventx{$f}->{origin}{$g}->{close} . ",";
         $oneline .=  $eventx{$f}->{origin}{$g}->{node} . ",";
         $oneline .=  $eventx{$f}->{origin}{$g}->{thrunode} . ",";
         $oneline .=  $eventx{$f}->{reeval} . ",";
         $cnt++;$oline[$cnt]="$oneline\n";
      }
   }
   $rptkey = "DATAREPORT006";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Pure Situations with DisplayItems Report\n";
   $cnt++;$oline[$cnt]="Situation,Atomize,Count,Open,Close,Thrunode,Interval\n";
   foreach my $f (sort { $eventx{$b}->{count} <=> $eventx{$a}->{count} ||
                         $a cmp $b
                       } keys %eventx) {
      next if $eventx{$f}->{reeval} > 0;
      foreach my $g (sort {$a cmp $b} keys  %{$eventx{$f}->{origin}}) {
         $oneline = $eventx{$f}->{sitname} . ",";
         $oneline .= $eventx{$f}->{atomize} . ",";
         $oneline .=  $eventx{$f}->{origin}{$g}->{open} . ",";
         $oneline .=  $eventx{$f}->{origin}{$g}->{open} . ",";
         $oneline .=  "0,";
         $oneline .=  $eventx{$f}->{origin}{$g}->{thrunode} . ",";
#      my $ncount = keys %{$eventx{$f}->{origin}};
#      $oneline .=  $ncount . ",";
         $oneline .=  $eventx{$f}->{reeval} . ",";
         $cnt++;$oline[$cnt]="$oneline\n";
      }
   }
}

if ($tema_total_eos > 0 ) {
   $rptkey = "DATAREPORT007";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: End of Service TEMAs\n";
   $cnt++;$oline[$cnt]="Node,Maint,Type,Date\n";
   for ($i=0; $i<=$nsavei; $i++) {
      my $node1 = $nsave[$i];
      my $tlevel = substr($nsave_temaver[$i],0,5);
      next if $tlevel eq "";
      my $tlevel_ref = $eoslevelx{$tlevel};
      next if !defined $tlevel_ref;
      next if $tlevel_ref->{future} == 1;
      $oneline = $node1 . ",";
      $oneline .= $nsave_temaver[$i] . ",";
      $oneline .= "EOS" . ",";
      $oneline .= $tlevel_ref->{date} . ",";
      $oneline .= $nsave_hostaddr[$i] . ",";
      $cnt++;$oline[$cnt]="$oneline\n";
   }
   for ($i=0; $i<=$nsavei; $i++) {
      my $node1 = $nsave[$i];
      my $tlevel = substr($nsave_temaver[$i],0,5);
      next if $tlevel eq "";
      my $tlevel_ref = $eoslevelx{$tlevel};
      next if !defined $tlevel_ref;
      next if $tlevel_ref->{future} == 0;
      $oneline = $node1 . ",";
      $oneline .= $nsave_temaver[$i] . ",";
      $oneline .= "FutureEOS" . ",";
      $oneline .= $tlevel_ref->{date} . ",";
      $oneline .= $nsave_hostaddr[$i] . ",";
      $cnt++;$oline[$cnt]="$oneline\n";
   }
}

# Calculate for same agent inserted into TNODELST multiple times more then most common
# This is an important signal about identically named agents on different systems.
$top20 = 0;
foreach my $f (sort { $eibnodex{$b}->{count} <=> $eibnodex{$a}->{count} ||
                      $a cmp $b
                    } keys %eibnodex) {
   last if $eibnodex{$f}->{count} <= $online_mode;
   if ($top20 == 0) {
      $rptkey = "DATAREPORT008";$advrptx{$rptkey} = 1;         # record report key
      $cnt++;$oline[$cnt]="\n";
      $cnt++;$oline[$cnt]="$rptkey: Maximum Top 20 agents showing online status more than $online_mode times - the most common number\n";
      $cnt++;$oline[$cnt]="OnlineCount,Node,ThrunodeCount,Thrunodes\n";
   }
   $top20 += 1;
   $oneline = $eibnodex{$f}->{count} . ",";
   $oneline .= $f . ",";
   my $pthrunode = "";
   my $pthruct = 0;
   foreach my $g (sort {$a cmp $b} keys  %{$eibnodex{$f}->{thrunode}}) {
      $pthruct += 1;
      $pthrunode .= ":" if $pthrunode ne "";
      $pthrunode .= $g;
   }
   $oneline .= $pthruct . "," . $pthrunode . ",";
   $cnt++;$oline[$cnt]="$oneline\n";
   last if $top20 > 19;
}
if ($top20 > 0) {
   $cnt++;$oline[$cnt]="\n";
}


$top20 = 0;
$eventx_dur = 0;
$rptkey = "DATAREPORT009";$advrptx{$rptkey} = 1;         # record report key
$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="$rptkey: Top 20 Situation Event Report\n";
$cnt++;$oline[$cnt]="Situation,Count,Open,Close,NodeCount,Interval,Atomize,Rate,Nodes\n";
if ($event_ct > 0) {
   foreach my $f (sort { $eventx{$b}->{count} <=> $eventx{$a}->{count} ||
                         $a cmp $b
                       } keys %eventx) {
      $top20 += 1;
      last if $top20 > 20;
      $oneline = $eventx{$f}->{sitname} . ",";
      $oneline .=  $eventx{$f}->{count} . ",";
      $oneline .=  $eventx{$f}->{open} . ",";
      $oneline .=  $eventx{$f}->{close} . ",";
      my $ncount = keys %{$eventx{$f}->{origin}};
      $oneline .=  $ncount . ",";
      $oneline .=  $eventx{$f}->{reeval} . ",";
      $oneline .=  $eventx{$f}->{atomize} . ",";
      my $sit_start = $eventx{$f}->{start};
      my $sit_last = $eventx{$f}->{last};
      my $sit_dur = get_epoch($sit_last) - get_epoch($sit_start) + 1;
      my $sit_rate = ($eventx{$f}->{count}*60)/$sit_dur;
      my $psit_rate = sprintf("%.2f",$sit_rate);
      $oneline .=  $psit_rate . ",";
      my $pnodes = "";
      my $cnodes = 0;
      foreach my $g (sort {$a cmp $b} keys %{$eventx{$f}->{origin}}) {
         $cnodes += 1;
         last if $cnodes > 3;
         my $onenode = $g;
         $onenode =~ s/\s+//g;
         $pnodes .= $onenode . ";";
      }
      $oneline .=  $pnodes . ",";
      $cnt++;$oline[$cnt]="$oneline\n";
   }
}
$eventx_dur = 1;
if ($eventx_last != -1) {
   $eventx_dur = get_epoch($eventx_last) - get_epoch($eventx_start);
}
if ($top20 != 0) {
   $cnt++;$oline[$cnt]="$oneline\n";
}

$rptkey = "DATAREPORT010";$advrptx{$rptkey} = 1;         # record report key
$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="$rptkey: TEMS Situation Load Impact Report\n";
$cnt++;$oline[$cnt]="Hub,$hub_tems,$hub_tems_ct\n";
$cnt++;$oline[$cnt]=",SampLoad/min,TEMSnodeid,Count,Status,Version,Arch,SampSit,PureSit,DDSampSit,DDSampLoad/min,DDPureSit,Max1,Max1_ct,Max5,Max5_ct,DDMax1,DDMax1_ct,DDMax5,DDMax5_ct,\n";
for (my $i=0;$i<=$temsi;$i++) {
   my $poffline = "Offline";
   my $node1 = $tems[$i];
   my $nx = $nsavex{$node1};
   if (defined $nx) {
      $poffline = "Online" if $nsave_o4online[$nx] eq "Y";
   }
   my $sit_rate = $tems_sampload[$i]/60;
   my $psit_rate = sprintf("%.2f",$sit_rate);
   my $sit_rate_dedup = $tems_sampload_dedup[$i]/60;
   my $psit_rate_dedup = sprintf("%.2f",$sit_rate_dedup);
   # calculate peak 1 minute and 5 minute rates for sampled situations.
   my @peak1;
   my @peak5;
   my $cmax1 = 0;
   my $cmax5 = 0;
   my $cmax1_ct = 0;
   my $cmax5_ct = 0;
   my $cmax1_sec = 0;
   my $cmax5_sec = 0;
   my @peak1dd;
   my @peak5dd;
   my $cmax1dd = 0;
   my $cmax5dd = 0;
   my $cmax1dd_ct = 0;
   my $cmax5dd_ct = 0;
   my $cmax1dd_sec = 0;
   my $cmax5dd_sec = 0;
   foreach my $f (keys %{$tems_sits[$i]}) {
      my $sitone = $f;
      $sx = $sitx{$sitone};
      next if !defined $sx;
      next if $sit_reeval[$sx] == 0;
      my $ssec = 0;
      my $csec = 0;
      my $cmin1;
      my $cmin5;
      $csec = 0;
      for (;;) {
         $csec += $sit_reeval[$sx];
         last if $csec > 86400;
         $cmin1 = int($csec/60);
         $cmin5 = int($csec/300);
         $peak1[$cmin1] += 1;
         $peak5[$cmin5] += 1;
         if ($cmax1 < $peak1[$cmin1]) {
            $cmax1 = $peak1[$cmin1];
            $cmax1_sec = $csec;
         }
         if ($cmax5 < $peak5[$cmin5]) {
            $cmax5 = $peak5[$cmin5];
            $cmax5_sec = $csec;
         }
      }
      next if $sit_pdtseq[$sx] > 1;
      my $cmin1dd;
      my $cmin5dd;
      $csec = 0;
      for (;;) {
         $csec += $sit_reeval[$sx];
         last if $csec > 86400;
         $cmin1dd = int($csec/60);
         $cmin5dd = int($csec/300);
         $peak1dd[$cmin1dd] += 1;
         $peak5dd[$cmin5dd] += 1;
         if ($cmax1dd < $peak1dd[$cmin1dd]) {
            $cmax1dd = $peak1dd[$cmin1dd];
            $cmax1dd_sec = $csec;
         }
         if ($cmax5dd < $peak5dd[$cmin5dd]) {
            $cmax5dd = $peak5dd[$cmin5dd];
            $cmax5dd_sec = $csec;
         }
      }
   }
   for (my $j=0;$j<1440;$j++) {
      next if !defined $peak1[$j];
      $cmax1_ct += 1 if $peak1[$j] == $cmax1;
   }
   for (my $j=0;$j<288;$j++) {
      next if !defined $peak5[$j];
      $cmax5_ct += 1 if $peak5[$j] == $cmax5;
   }
   for (my $j=0;$j<1440;$j++) {
      next if !defined $peak1dd[$j];
      $cmax1dd_ct += 1 if $peak1dd[$j] == $cmax1dd;
   }
   for (my $j=0;$j<288;$j++) {
      next if !defined $peak5dd[$j];
      $cmax5dd_ct += 1 if $peak5dd[$j] == $cmax5dd;
   }

   $oneline = "TEMS,$psit_rate,$tems[$i],$tems_ct[$i],$poffline,$tems_version[$i],$tems_arch[$i],$tems_sampsit[$i],$psit_rate,$tems_puresit[$i],$tems_sampsit_dedup[$i],$psit_rate_dedup,$tems_puresit_dedup[$i],$cmax1,$cmax1_ct,$cmax5,$cmax5_ct,$cmax1dd,$cmax1dd_ct,$cmax5dd,$cmax5dd_ct,";
   $cnt++;$oline[$cnt]="$oneline\n";

}

if ($danger_IZ76410 > 0) {
   $rptkey = "DATAREPORT011";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: TEMA Agent(s) at APAR IZ76410 risk [could be connected to two TEMS at same time]\n";
   $cnt++;$oline[$cnt]="Agent,Hostaddr,TEMAver,\n";

   for ($i=0;$i<=$nsavei;$i++) {
      next if $nsave_temaver[$i] eq "";
      if ( (substr($nsave_temaver[$i],0,8) ge "06.21.00") and (substr($nsave_temaver[$i],0,8) lt "06.21.03") or
           (substr($nsave_temaver[$i],0,8) ge "06.22.00") and (substr($nsave_temaver[$i],0,8) lt "06.22.03")) {
         if ($nsave_product[$i] ne "VA") {
            $cnt++;$oline[$cnt]="$nsave[$i],$nsave_hostaddr[$i],$nsave_temaver[$i],\n";
         }
      }
   }
}

if ($danger_IV18016 > 0) {
   $rptkey = "DATAREPORT012";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: TEMA Agent(s) in APAR IV18016 danger [Agent high CPU with embedded situations]\n";
   $cnt++;$oline[$cnt]="Agent,Hostaddr,TEMAver,\n";
   for ($i=0;$i<=$nsavei;$i++) {
      next if $nsave_temaver[$i] eq "";
      if ( (substr($nsave_temaver[$i],0,8) eq "06.22.07") or (substr($nsave_temaver[$i],0,8) eq "06.23.01")) {
         $cnt++;$oline[$cnt]="$nsave[$i],$nsave_hostaddr[$i],$nsave_temaver[$i],\n";
      }
   }
}

if ($danger_IV30473 > 0) {
   $rptkey = "DATAREPORT013";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: TEMA Agent(s) in APAR IV30473 danger [KDEB_INTERFACELIST conflicts]\n";
   $cnt++;$oline[$cnt]="Agent,Hostaddr,TEMAver,\n";
   for ($i=0;$i<=$nsavei;$i++) {
      next if $nsave_temaver[$i] eq "";
      if ( ((substr($nsave_temaver[$i],0,8) ge "06.22.07") and (substr($nsave_temaver[$i],0,8) le "06.22.09")) or
           ((substr($nsave_temaver[$i],0,8) ge "06.23.00") and (substr($nsave_temaver[$i],0,8) le "06.23.02"))) {
         $cnt++;$oline[$cnt]="$nsave[$i],$nsave_hostaddr[$i],$nsave_temaver[$i],\n";
      }
   }
}

if ($tema_multi > 0) {
   $rptkey = "DATAREPORT014";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Systems with Multiple TEMA levels\n";
   $cnt++;$oline[$cnt]="IP_Address,Agent,TEMAver,TEMAarch,\n";
   foreach my $f (sort {$a cmp $b} keys %ipx) {
      my $ip_ref = $ipx{$f};
      next if $ip_ref->{count} < 2;
      foreach my $g (sort {$a cmp $b} keys %{$ip_ref->{agents}}) {
         next if !defined $ip_ref->{agents}{$g};
         my $iarch = "";
         $iarch = $ip_ref->{arch}{$g} if defined $ip_ref->{arch}{$g};
         next if !defined $ip_ref->{agents}{$g};
         next if $ip_ref->{agents}{$g} eq "";
         $oneline = $f . ",";
         $oneline .= $g . ",";
         $oneline .= $ip_ref->{agents}{$g} . ",";
         $oneline .= $iarch . ",";
         $cnt++;$oline[$cnt]="$oneline\n";
      }
   }
}

foreach my $f (sort {$a cmp $b} keys %ipx) {
   my $ip_ref = $ipx{$f};
   my $hcount = scalar keys %{$ip_ref->{hostname}};
   if ($hcount > 1) {
      my %hostx;
      foreach my $g (keys %{$ip_ref->{hostname}}) {
         $hostx{$g} = 1;
      }
      $hcount = scalar keys %hostx;
      if ($hcount > 1) {
         $iprerr_ct += 1;
         if ($ipr_ct == 0) {
            $ipr_ct = 1;
            $rptkey = "DATAREPORT015";$advrptx{$rptkey} = 1;         # record report key
            $cnt++;$oline[$cnt]="\n";
            $cnt++;$oline[$cnt]="$rptkey: Multiple hostname report\n";
            $cnt++;$oline[$cnt]="IP_Address,Hostnames,Agents,\n";
         }
         my $pagents = "";
         foreach my $g (keys %{$ip_ref->{agents}}) {
            $pagents .= $g . " ";
         }
         my $phostname = "";
         foreach my $g (keys %hostx) {
            $phostname .= $g . " ";
         }
         $oneline = $f . ",";
         $oneline .= "(" . $phostname . ")";
         $oneline .= "(" . $pagents . ")";
         $cnt++;$oline[$cnt]="$oneline\n";
      }
   }
}

my %rdpx;
foreach my $f (sort {$a cmp $b} keys %ipx) {
   my $ip_ref = $ipx{$f};
   my $hcount = scalar keys %{$ip_ref->{hostname}};
   if ($hcount > 1) {
      my $osagent = "";
      my $ihostname = "";
      foreach my $g (keys %{$ip_ref->{agents}}) {
         $nsx = $nsavex{$g};
         next if !defined $nsx;
         my $iproduct = $nsave_product[$nsx];
         next if !defined $agtosx{$iproduct};
         $osagent = $g;
         last;
      }
      if ($osagent ne "") {
         my $tnode = $osagent;
         $tnode =~ s/[^:]//g;
         my $ncolons = length($tnode);
         my @wnodes = split(":",$osagent);
         if ($ncolons == 0) {
            $ihostname = $osagent;
         } elsif ($ncolons == 1) {
            $ihostname = $wnodes[0];
         } elsif ($ncolons == 2) {
            $ihostname = $wnodes[1];
         } elsif ($ncolons >= 3) {
            $ihostname = $wnodes[2];
         }
      }
      foreach my $g (keys %{$ip_ref->{agents}}) {
         $nsx = $nsavex{$g};
         next if !defined $nsx;
         next if $g eq $osagent;
         next if $nsave_product[$nsx] eq "EM";
         my $nhostname;
         my $tnode = $g;
         $tnode =~ s/[^:]//g;
         my $ncolons = length($tnode);
         my @wnodes = split(":",$g);
         if ($ncolons == 0) {
            $nhostname = $g;
         } elsif ($ncolons == 1) {
            $nhostname = $wnodes[0];
         } elsif ($ncolons == 2) {
            $nhostname = $wnodes[1];
         } elsif ($ncolons >= 3) {
            $nhostname = $wnodes[2];
         }
         next if $nhostname eq $ihostname;
         {
            my %rdpdef = ( osagent => $osagent,
                           oshostname => $ihostname,
                           agthostname => $nhostname,
                           ip => $f,
                         );
            $rdpx{$g} = \%rdpdef;
         }
      }
   }
}
my $rdp_ct = scalar keys %rdpx;
if ($rdp_ct > 0 ) {
   $rptkey = "DATAREPORT021";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Agents unable to use Remote Deploy because of OS Agent hostname conflict\n";
   $cnt++;$oline[$cnt]="Agent,Agent_Hostname,OS_Hostname,IP_Addr,OS_Agent,\n";
   my $rdp_ct = 0;
   foreach my $g (keys %rdpx) {
      my $rdp_ref = $rdpx{$g};
      next if $rdp_ref->{oshostname} eq "";
      $rdp_ct += 1;
      $oneline = $g . ",";
      $oneline .= $rdp_ref->{agthostname} . ",",
      $oneline .= $rdp_ref->{oshostname} . ",",
      $oneline .= $rdp_ref->{ip} . ",",
      $oneline .= $rdp_ref->{osagent} . ",",
      $cnt++;$oline[$cnt]="$oneline\n";
   }
   if ($rdp_ct > 0) {
      $advi++;$advonline[$advi] = "Agents [$rdp_ct] unable to use Remote Deploy because of OS Agent hostname conflict - See $rptkey";
      $advcode[$advi] = "DATAHEALTH1110W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "TEMS";
   }
}


$rptkey = "DATAREPORT016";$advrptx{$rptkey} = 1;         # record report key
$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="$rptkey: TEMS Offline Reports\n";
$cnt++;$oline[$cnt]="Offline by Thrunode\n";
$cnt++;$oline[$cnt]="Thrunode,Count,\n";
foreach my $f (sort { $a cmp $b } keys %offline_thrunodex) {
   my $offline_thrunode_ref = $offline_thrunodex{$f};
   $cnt++;$oline[$cnt]="$f," . $offline_thrunode_ref->{count} . ",\n";
}

$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="Offline by Product\n";
$cnt++;$oline[$cnt]="Product,Count,\n";
foreach my $f (sort { $a cmp $b } keys %offline_productx) {
   my $offline_product_ref = $offline_productx{$f};
   $cnt++;$oline[$cnt]="$f," . $offline_product_ref->{count} . ",\n";
}

$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="Offline by Product-Version\n";
$cnt++;$oline[$cnt]="Product,Version,Count,\n";
foreach my $f (sort { $a cmp $b } keys %offline_productversionx) {
   my $offline_productversion_ref = $offline_productversionx{$f};
   $outline = $offline_productversion_ref->{product} . ",";
   $outline .= $offline_productversion_ref->{version} . ",";
   $outline .= $offline_productversion_ref->{count} . ",";
   $cnt++;$oline[$cnt]="$outline\n";
}

$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="Offline by TEMA\n";
$cnt++;$oline[$cnt]="TEMA,Count,\n";
foreach my $f (sort { $a cmp $b } keys %offline_temax) {
   my $offline_tema_ref = $offline_temax{$f};
   $cnt++;$oline[$cnt]="$f," . $offline_tema_ref->{count} . ",\n";
}

$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="Offline by Agents\n";
$cnt++;$oline[$cnt]="Agent,Count,Version,Reserved,Thrunode,Hostaddr,Hostinfo,\n";
foreach my $f (sort { $a cmp $b } keys %offline_agentx) {
   my $offline_agent_ref = $offline_agentx{$f};
   $outline = $f . ",";
   $outline .= $offline_agent_ref->{count}  . ",";
   $outline .= $offline_agent_ref->{version}  . ",";
   $outline .= $offline_agent_ref->{reserved}  . ",";
   $outline .= $offline_agent_ref->{thrunode}  . ",";
   $outline .= $offline_agent_ref->{hostaddr}  . ",";
   $outline .= $offline_agent_ref->{hostinfo}  . ",";
   $cnt++;$oline[$cnt]="$outline\n";
}

# calculate totals
my $msoff_ct = 0;
my $msoff_eval_hour = 0;
my $msoff_kds_agents_sec = 0;
my $msoff_sitmon_agents_sec = 0;
my $nsave_total = $nsave_online + $nsave_offline;
foreach my $f (sort { $a cmp $b } keys %ms_offlinex) {
   $sx = $sitx{$f};
   next if $sit[$sx] eq "TEMS_BUSY";
   next if $sit_autostart[$sx] ne "*YES";
   next if $sit_reeval[$sx] == 0;
   $msoff_ct += 1;
   my $ms_rate = 3600/$sit_reeval[$sx];
   $msoff_eval_hour += $ms_rate;
   $msoff_kds_agents_sec += ($ms_rate * $nsave_total)/3600;
   if ($sit_persist[$sx] == 1) {
      $msoff_sitmon_agents_sec += ($ms_rate * $nsave_offline)/3600;
   } else {
      $msoff_sitmon_agents_sec += ($ms_rate * $nsave_total)/3600;
   }
}


# now produce report
my $prate;
my $ppc;
my $ms_rate;
my $res_pc;
my $agents_sec;
my $miss_reason = 0;
$rptkey = "DATAREPORT017";$advrptx{$rptkey} = 1;         # record report key
$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="$rptkey: MS_Offline-type Situation Report\n";
$cnt++;$oline[$cnt]="Sitname,Eval/hour,Eval%,kds/sec,kds%,SITMON/sec,SITMON%,Notes,\n";
foreach my $f (sort { $a cmp $b } keys %ms_offlinex) {
   $sx = $sitx{$f};
   next if $sit[$sx] eq "TEMS_BUSY";
   next if $sit_autostart[$sx] ne "*YES";
   next if $sit_reeval[$sx] == 0;
   $outline = $sit[$sx] . ",";
   $ms_rate = 3600/$sit_reeval[$sx];
   $prate = sprintf("%.2f",$ms_rate);
   $outline .= $prate . ",";
   $res_pc = ($ms_rate*100)/$msoff_eval_hour;
   $ppc = sprintf '%.2f%%', $res_pc;
   $outline .= $ppc . ",";

   $agents_sec = ($ms_rate * $nsave_total)/3600;
   $prate = sprintf("%.2f",$agents_sec);
   $outline .= $prate . ",";
   $res_pc = ($agents_sec*100)/$msoff_kds_agents_sec if $msoff_kds_agents_sec > 0;
   $ppc = sprintf '%.2f%%', $res_pc;
   $outline .= $ppc . ",";

   if ($sit_persist[$sx] == 1) {
      $agents_sec = ($ms_rate * $nsave_offline)/3600;
   } else {
      $agents_sec = ($ms_rate * $nsave_total)/3600;
   }
   $prate = sprintf("%.2f",$agents_sec);
   $outline .= $prate . ",";
   $res_pc = ($agents_sec*100)/$msoff_sitmon_agents_sec if $msoff_sitmon_agents_sec > 0;
   $ppc = sprintf '%.2f%%', $res_pc;
   $outline .= $ppc . ",";
   my $inotes = "";
   $inotes .= "REASON test missing;" if index($sit_pdt[$sx],"Reason") == -1;
   $miss_reason += 1 if  index($sit_pdt[$sx],"Reason") == -1;
   $inotes .= "Persist=" . $sit_persist[$sx] . " >1;" if $sit_persist[$sx] > 1;
   $outline .= $inotes . ",";

   $cnt++;$oline[$cnt]="$outline\n";
}
$outline = "Total[" . $msoff_ct . "],";
$prate = sprintf("%.2f",$msoff_eval_hour);
$outline .= $prate . ",100%,";
$prate = sprintf("%.2f",$msoff_kds_agents_sec);
$outline .= $prate . ",100%,";
$prate = sprintf("%.2f",$msoff_sitmon_agents_sec);
$outline .= $prate . ",100%,";
$cnt++;$oline[$cnt]="$outline\n";
if ($miss_reason > 0) {
   my $crit_line = "7,MS_Offline type situations - $miss_reason are missing the Reason *NE FA test. See DATAREPORT017";
   push @crits,$crit_line;
}

if ($agenthubi > 0) {
   $rptkey = "DATAREPORT018";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Agents online to hub TEMS\n";
   $cnt++;$oline[$cnt]="Node,Product,\n";
   foreach my $f (sort { $a cmp $b } keys %agenthubx) {
      $outline = $f . ",";
      $outline .= $agenthubx{$f} . ",";
      $cnt++;$oline[$cnt]="$outline\n";
   }
}

if ( $agenthubni > 0) {
   $rptkey = "DATAREPORT019";$advrptx{$rptkey} = 1;         # record report key
   $cnt++;$oline[$cnt]="\n";
   $cnt++;$oline[$cnt]="$rptkey: Normal Agents online to hub TEMS\n";
   $cnt++;$oline[$cnt]="Node,Product,\n";
   foreach my $f (sort { $a cmp $b } keys %agenthubnx) {
      $outline = $f . ",";
      $outline .= $agenthubnx{$f} . ",";
      $cnt++;$oline[$cnt]="$outline\n";
   }
}

$rptkey = "DATAREPORT020";$advrptx{$rptkey} = 1;         # record report key
$cnt++;$oline[$cnt]="\n";
$cnt++;$oline[$cnt]="$rptkey: Virtual Hub Table impact by TEMS\n";
$cnt++;$oline[$cnt]="TEMS,Nodes,Hour,Peak_Second,Details,\n";
for (my $t=0;$t<=$temsi;$t++) {
   $outline = $tems[$t] . ",";
   my $tems_peak = 0;
   my $tems_hour = 0;
   my $tems_agents = 0;
   my $pvtbl = "";
   foreach my $f ( sort {$a cmp $b} keys %{$tems_vtbl[$t]}) {
      my $iagents = $tems_vtbl[$t]{$f};
      my $vx = $vtnodex{$f};
      my $node_hr = (60/$vtnode_rate[$vx])*$vtnode_tab[$vx];
      my $per_hour = $node_hr*$iagents;
      my $per_peak = $iagents * $vtnode_tab[$vx];
      $tems_hour += $per_hour;
      $tems_peak += $per_peak;
      $tems_agents += $iagents;
      $pvtbl .= "[" . $f . "/" . $iagents . "/" . $per_hour . "/" . $per_peak . "] ";
   }
   chop($pvtbl) if $pvtbl ne "";
   $outline .=  $tems_agents . ",";
   $outline .=  $tems_hour . ",";
   $outline .=  $tems_peak . ",";
   $outline .=  $pvtbl . ",";
   $cnt++;$oline[$cnt]="$outline\n";
}

my $uadv_ct = 0;
my %tnodex;
my $tarkey;
foreach my $f (keys %uadvx) {
   my $uadv_ref = $uadvx{$f};
   my $tab_ct = scalar keys %{$uadv_ref->{sits}};
   next if $tab_ct == 1;
   %tnodex = ();
   $uadv_ct = 0;
   foreach my $g (keys %{$uadv_ref->{sits}}) {     # $g is the situation
      my $sit_tar_ref = $sit_tarx{$g};
      my $ipsit = $g;
      my $ii = $sitx{$g};
      $ipsit = $sit_psit[$ii] if defined $ipsit;
      next if !defined $sit_tar_ref;
      foreach my $h ( keys %{$sit_tar_ref->{targets}}) {     # $h is the target - node or nodelist or TEMS node
         my $tar_node_ref = $tar_nodex{$h};
         my $tarkey;
         my $tx = $temsx{$h};
         if (!defined $tar_node_ref) {  # no target so $h is a node or a TEMS
            if (defined $tx) {
               for (my $k=0; $k<=$nlistvi; $k++) {
                  next if $nlistv_tems[$k] ne $h;
                  my $node1 = $nlistv[$k];
                  $tarkey = "TEMS" . "|". $h . "|" . $ipsit . "|" . $f;
                  my $tnode_ref = $tnodex{$node1};
                  if (!defined $tnode_ref){
                     my %tnoderef = (
                                       count => 0,
                                       msl_ct => 0,
                                       tems_ct => 0,
                                       node_ct => 0,
                                       types => {},
                                    );
                     $tnode_ref = \%tnoderef;
                     $tnodex{$node1} = \%tnoderef;
                  }
                  $tnode_ref->{count} += 1;
                  $tnode_ref->{tems_ct} += 1;
                  $tnode_ref->{types}{$tarkey} = 1;
               }
            } else { # $h is a node
               $tarkey = "NODE" . "|". $h . "|" . $ipsit . "|" . $f;
               my $tnode_ref = $tnodex{$h};
               if (!defined $tnode_ref){
                  my %tnoderef = (
                                    count => 0,
                                    msl_ct => 0,
                                    tems_ct => 0,
                                    node_ct => 0,
                                    types => {},
                                 );
                  $tnode_ref = \%tnoderef;
                  $tnodex{$h} = \%tnoderef;
               }
               $tnode_ref->{count} += 1;
               $tnode_ref->{node_ct} += 1;
               $tnode_ref->{types}{$tarkey} = 1;
            }
         } else { # $h is a msl
            foreach my $i (keys %{$tar_node_ref->{nodes}}) {  # $i are the end nodes
               my $tnode_ref = $tnodex{$i};
               $tarkey = "MSL" . "|". $i . "|" . $ipsit . "|" . $f . "|" . $h;
               if (!defined $tnode_ref){
                  my %tnoderef = (
                                    count => 0,
                                    msl_ct => 0,
                                    tems_ct => 0,
                                    node_ct => 0,
                                    types => {},
                                 );
                  $tnode_ref = \%tnoderef;
                  $tnodex{$i} = \%tnoderef;
               }
               $tnode_ref->{count} += 1;
               $tnode_ref->{msl_ct} += 1;
               $tnode_ref->{types}{$tarkey} = 1;
            }
         }
      }
   }
   foreach my $t ( keys %tnodex) {
      my $tnode_ref = $tnodex{$t};
      next if $tnode_ref->{count} < 2;
      $uadv_ct += 1;
   }
   if ($uadv_ct > 0) {
      $rptkey = "DATAREPORT022";$advrptx{$rptkey} = 1;         # record report key
      $advi++;$advonline[$advi] = "Historical UADVISORs [$uadv_ct] duplicate collections on table $f - see $rptkey";
      $advcode[$advi] = "DATAHEALTH1111W";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = "UADVISOR";
      $cnt++;$oline[$cnt]="\n";
      $cnt++;$oline[$cnt]="$rptkey: Agents [$uadv_ct] experiencing duplicate historical data collection on table $f\n";
      $cnt++;$oline[$cnt]="Node,Type/Target/Situation/Table/MSL,\n";
      foreach my $t (sort {$a cmp $b} keys %tnodex) {
         my $tnode_ref = $tnodex{$t};
         next if $tnode_ref->{count} < 2;
         foreach my $s (sort {$a cmp $b} keys %{$tnode_ref->{types}}) {
            $outline = $t . ",";
            $outline .= $s . ",";
            $cnt++;$oline[$cnt]="$outline\n";
         }
      }
   }
}
if ($opt_asysname == 1) {
   my $asysname_ct = scalar keys %asysnamex;
   if ($asysname_ct > 0) {
      open SYSNAMECSV, ">$opt_asysname_csv" or die "can't open $opt_asysname_csv: $!";
      foreach my $f (keys %asysnamex) {
         my $asysname_ref = $asysnamex{$f};
         my $outcsv = $f . ",";
         $outcsv .= $asysname_ref->{node} . ",";
         $outcsv .= $asysname_ref->{product} . ",";
         $outcsv .= $asysname_ref->{hostaddr} . ",";
         print SYSNAMECSV "$outcsv\n";
      }
      close(SYSNAMECSV);
   }
}

my $dupndx_ct = scalar keys %dupndx;

if ($dupndx_ct > 0) {
   my $ptable = "";
   foreach my $r (sort {$a cmp $b} keys %dupndx) {
      $ptable .= $r . " ";
   }
   chomp($ptable) if $ptable ne "";
   my $crit_line = "1,Database Tables[$ptable] with duplicate indexes - See Database Health Checker report";
   push @crits,$crit_line;
}

if ($opt_nohdr == 0) {
   print OH "ITM Database Health Report $gVersion\n";
   print OH "\n";
}

for (my $i = 0; $i<=$scnt; $i++) {
   print OH $sline[$i];
}

$tadvi = $advi + 1;
print OH "\n";
print OH "Advisory messages,$tadvi\n";

if ($advi != -1) {
   print OH "\n";
   print OH "Impact,Advisory Code,Object,Advisory\n";
   for (my $a=0; $a<=$advi; $a++) {
       my $mysit = $advsit[$a];
       my $myimpact = $advimpact[$a];
       my $mykey = $mysit . "|" . $a;
       $advx{$mykey} = $a;
   }
   foreach my $f ( sort { $advimpact[$advx{$b}] <=> $advimpact[$advx{$a}] ||
                          $advcode[$advx{$a}] cmp $advcode[$advx{$b}] ||
                          $advsit[$advx{$a}] cmp $advsit[$advx{$b}] ||
                          $advonline[$advx{$a}] cmp $advonline[$advx{$b}]
                        } keys %advx ) {
      my $j = $advx{$f};

      print OH "$advimpact[$j],$advcode[$j],$advsit[$j],$advonline[$j]\n";
      $max_impact = $advimpact[$j] if $advimpact[$j] > $max_impact;
      $advgotx{$advcode[$j]} = $advimpact[$j];
   }
}

print OH "\n";

for (my $i = 0; $i<=$cnt; $i++) {
   print OH $oline[$i];
}

if ($advi != -1) {
   print OH "\n";
   print OH "Advisory Trace, Meaning and Recovery suggestions follow\n\n";
   foreach $f ( sort { $a cmp $b } keys %advgotx ) {
      next if substr($f,0,10) ne "DATAHEALTH";
         print OH "Advisory code: " . $f  . "\n";
         print OH "Impact:" . $advgotx{$f}  . "\n";
         print STDERR "$f missing\n" if !defined $advtextx{$f};
         print OH $advtextx{$f};
      }
   }

   my $rpti = scalar keys %advrptx;
   if ($rpti != -1) {
      print OH "\n";
      print OH "Database Checker Reports - Meaning and Recovery suggestions follow\n\n";
      foreach $f ( sort { $a cmp $b } keys %advrptx ) {
         next if !defined $advrptx{$f};
         print STDERR "$f missing\n" if !defined $advtextx{$f};
         print OH "$f\n";
         print OH $advtextx{$f};
      }
   }


close OH;







# Some cases get run which appear to be hub
# TEMSes but are not really. This identifies
# such cases and causes them to be ignored by the
# AOA controller task itm_ref_checker.pl
if ($max_impact == 105) {
   $max_impact = 0 if $hub_tems_ct == 0;
}

if ($opt_s ne "") {
   if ($max_impact > 0 ) {
        open SH, ">$opt_s";
        if (tell(SH) != -1) {
           $oneline = "REFIC ";
           $oneline .= $max_impact . " ";
           $oneline .= $tadvi . " ";
           $oneline .= $tema_total_deficit_percent . "% ";
           $oneline .= $hub_tems_version . " ";
           $oneline .= $hub_tems . " ";
           $oneline .= $hub_tems_ct . " ";
           $oneline .= "FTO[$opt_fto]" . " ";
           $oneline .= "https://ibm.biz/BdFrJL" . " ";
           print SH $oneline . "\n";
           close SH;
        }
   }
}

if ($max_impact > 0 ) {
   if ($opt_crit ne "") {
      if ($#crits != -1) {
         my $critfn = $opt_crit . $critical_fn;
         open(CRIT,">$critfn");
         for my $cline (@crits) {
            my $crit_line = $cline . "\n";
            print CRIT $crit_line;
         }
         close(CRIT);
      }
   } else {
      if ($#crits != -1) {
         for my $cline (@crits) {
            print STDERR $cline . "\n";
         }
      }
   }
}

if ($opt_vndx == 1) {
   close(NDX);
}
if ($opt_mndx == 1) {
   close(MDX);
}
if ($opt_miss == 1) {
   foreach my $f (keys %miss) {
     $f =~ /(.*) (.*)/;
     my $code = $1;
     my $obj = $2;
     die "key $f in wrong format" if !defined $1;
     die "key $f in wrong format" if !defined $2;
     if ($code eq "DATAHEALTH1003I") {
        $oneline = "DELETE FROM O4SRV.TNODELST WHERE NODETYPE='V' AND NODELIST='";
        $oneline .= $obj;
        $oneline .= "' AND SYSTEM.PARMA('QIBUSER','_CLEANUP',8) AND SYSTEM.PARMA('QIBCLASSID','5529',4);";
        print MIS "$oneline\n";
     } elsif  ($code eq "DATAHEALTH1025E") {
        $oneline = "DELETE FROM O4SRV.TOBJACCL WHERE OBJCLASS='5140' AND NODEL='";
        $oneline .= $obj;
        $oneline .= "' AND SYSTEM.PARMA('QIBUSER','_CLEANUP',8) AND SYSTEM.PARMA('QIBCLASSID','5535',4);";
        print MIS "$oneline\n";
     } elsif  ($code eq "DATAHEALTH1029W") {
        $oneline = "DELETE FROM O4SRV.TOBJACCL WHERE OBJCLASS='5140' AND NODEL='";
        $oneline .= $obj;
        $oneline .= "' AND SYSTEM.PARMA('QIBUSER','_CLEANUP',8) AND SYSTEM.PARMA('QIBCLASSID','5535',4);";
        print MIS "$oneline\n";
     } elsif  ($code eq "DATAHEALTH1030E") {
        $oneline = "DELETE FROM O4SRV.TNODELST WHERE NODETYPE='M' AND NODE='";
        $oneline .= $obj;
        $oneline .= "'  AND SYSTEM.PARMA('QIBUSER','_CLEANUP',8) AND SYSTEM.PARMA('QIBCLASSID','5529',4);";
        print MIS "$oneline\n";
     } else {
         print STDERR "Unknown advisory code $code\n";
     }
   }
   close(MIS);
}

my $exit_code = 0;
if ($advi != -1) {
   $exit_code = ($max_impact > 0);
}
exit $exit_code;

# sitgroup_get_sits calculates the sum of all situations which are in this group or
# further groups in the DAG [Directed Acyclic Graph] that composes the
# situation groups. Result is returned in the global hash sum_sits which the caller manages.

# $grp_grp is an array
# $grp_grp[$base_node] is one scalar instance
# The instance is actually a hash of values, so we reference that by forcing it
#   %{$grp_grp[$base_node]} and that way the hash can be worked on.

sub sitgroup_get_sits
{
   my $base_node = shift;     # input index

   while( my ($refsit, $refval) = each %{$grp_sit[$base_node]}) {    # capture the situations into global hash.
      $sum_sits{$refsit} = 1;
   }
   while( my ($refgrp, $refval) = each %{$grp_grp[$base_node]}) {    # for groups, call recursively
      my $refgx = $grpx{$refgrp};
      next if !defined $refgx;
      sitgroup_get_sits($refgx);
   }
}

# TOVERITEM - Specifics of Situation Override detals
# Capture 4 columns from the Situation Overide Item table and store for later analysis
#  The error cases are
#    1) CALID is not blank and does not reference a known TCALENDAR ID column
#    2) ID does not reference a known TOVERRIDE ID column
#  It is normal to have multiple ID fields, so that is not checked
#  The LSTDATE is essentially unused... TOVERITEM is treated with TOVERRIDE in FTO
#  so the TOVERRIDE LSTDATE is the field to check.

sub new_toveritem {
   my ($iid,$ilstdate,$iitemid,$icalid) = @_;
   my $tcx = $tcix{$iitemid};
   if (!defined $tcx) {
      $tcii += 1;
      $tcx = $tcii;
      $tci[$tcx] = $iitemid;
      $tcix{$iitemid} = $tcx;
      $tci_count[$tcx] = 0;
      $tci_lstdate[$tcx] = $ilstdate;
      $tci_id[$tcx] = $iid;
      $tci_calid[$tcx] = $icalid;
   }
   $tci_count[$tcx] += 1;
}
# TOVERRIDE - Situation Override definition
# Capture 3 columns from the Situation Overide table and store for later analysis
#  The error cases are
#    1) LSTDATE is blank and cannot be FTO synchronized
#    2) LSTDATE is in future and will sabotage FTO synchronization before ITM 630 FP3
#    3) SITNAME does not reference a known TSITDESC SITNAME column
#    4) ID field is present more then once - duplicate keys

sub new_toverride {
   my ($iid,$ilstdate,$isitname) = @_;
   my $tcx = $calx{$iid};
   if (!defined $tcx) {
      $tcai += 1;
      $tcx = $tcai;
      $tca[$tcx] = $iid;
      $tcax{$iid} = $tcx;
      $tca_count[$tcx] = 0;
      $tca_lstdate[$tcx] = $ilstdate;
      $tca_sitname[$tcx] = $isitname;
   }
   $tca_count[$tcx] += 1;
}

sub new_tcalendar {
   my ($iid,$ilstdate,$iname) = @_;
   my $tcx = $calx{$iid};
   if (!defined $tcx) {
      $cali += 1;
      $tcx = $cali;
      $cal[$tcx] = $iid;
      $calx{$iid} = $tcx;
      $cal_count[$tcx] = 0;
      $cal_lstdate[$tcx] = $ilstdate;
      $cal_name[$tcx] = $iname;
   }
   $cal_count[$tcx] += 1;
}

sub new_tactypcy {
   my ($iactname,$ipcyname,$ilstdate,$itypestr,$iactinfo) = @_;
   my $pcy_ref = $pcyx{$ipcyname};
   if (!defined $pcy_ref) {
      $advi++;$advonline[$advi] = "Policy Activity [ACTNAME=$iactname] Unknown policy name";
      $advcode[$advi] = "DATAHEALTH1055E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $ipcyname;
   } else {
      if ($itypestr eq "*WAIT_ON_SITUATION") {
         $pcyx{$ipcyname}->{sit}{$iactinfo} = 1;
      } elsif ($itypestr eq "Evaluate_Situation") {
         $pcyx{$ipcyname}->{eval}{$iactinfo} = 1;
      } elsif ($itypestr eq "Wait_For_Sit_Reset") {
         $pcyx{$ipcyname}->{sit}{$iactinfo} = 1;
      }
   }
}

sub new_tpcydesc {
   my ($ipcyname,$ilstdate,$iautostart) = @_;
   my $pcy_ref = $pcyx{$ipcyname};
   if (!defined $pcy_ref) {
      my %pcy_sit = ();
      my %pcy_eval = ();
      my %pcyref = (
                      count => 0,           # count of PCYNAMEs - looking for duplicates
                      lstdate => $ilstdate, # last update date
                      sit  => \%pcy_sit,    # hash of Wait on Sits
                      eval => \%pcy_eval,   # hash of Evaluation Sit
                      autostart => $iautostart, # is policy operational
                   );
      $pcyx{$ipcyname} = \%pcyref;
      $pcy_ref = \%pcyref;
   }
   $pcy_ref->{count} += 1;
}

sub new_evntmap {
   my ($iid,$ilstdate,$imap) = @_;
   $evmapi += 1;
   $evmap[$evmapi] = $iid;
   $evmap_lstdate[$evmapi] = $ilstdate;
   $evmap_map[$evmapi] = $imap;
}

sub new_cct {
   my ($ikey,$ilstdate,$iname) = @_;
   $ccti += 1;
   $cct[$ccti] = $ikey;
   $cct_lstdate[$ccti] = $ilstdate;
   $cct_name[$ccti] = $iname;
}

sub new_evntserver {
   my ($iid,$ilstdate,$ilstusrprf) = @_;
   $evti += 1;
   $evt[$evti] = $iid;
   $evt_lstdate[$evti] = $ilstdate;
   $evt_lstusrprf[$evti] = $ilstusrprf;
}

sub new_tgroup {
   my ($igrpclass,$iid,$ilstdate,$igrpname) = @_;
   my $key = $igrpclass . "|" . $iid;
   my $group_detail_ref = $group{$key};

   if (!defined $group_detail_ref) {
      my %igroup = (
                      grpclass => $igrpclass,      # GRPCLASS usually 2010
                      id => $iid,                   # ID is the internal group name
                      grpname => $igrpname,        # GRPNAME is external user name
                      indirect => 0,               # when 1, included in a TGROUPI and so no distribution expected
                      count => 0,
                      lstdate => $ilstdate,
                   );
      $group_detail_ref = \%igroup;
      $group{$key} = \%igroup;
   }
   $group_detail_ref->{count} += 1;
   $groupx{$iid} = 1;
   if ($igrpclass eq '2010') {
      $gx = $grpx{$iid};
      if (!defined $gx) {
         $grpi++;
         $gx = $grpi;
         $grp[$gx] = $iid;
         $grpx{$iid} = $gx;
         $grp_name[$gx] = $igrpname;
         $grp_sit[$gx] = {};
         $grp_grp[$gx] = {};
      }
   }
}

sub new_tgroupi {
   my ($igrpclass,$iid,$ilstdate,$iobjclass,$iobjname) = @_;
   my $key = $igrpclass . "|" . $iid . "|" . $iobjclass . "|" . $iobjname;
   my $groupi_detail_ref = $groupi{$key};
   if (!defined $groupi_detail_ref) {
      my %igroupi = (
                      grpclass => $igrpclass,      # GRPCLASS usually 2010
                      id => $iid,                   # ID is the internal group name
                      objclass => $iobjclass,
                      objname => $iobjname,
                      count => 0,
                      lstdate => $ilstdate,
                   );
      $groupi_detail_ref = \%igroupi;
      $groupi{$key} = \%igroupi;
   }
   $groupi_detail_ref->{count} += 1;
   my $gkey = $igrpclass . "|" . $iid;
   my $group_ref = $group{$gkey};
   if (!defined $group_ref) {
      $advi++;$advonline[$advi] = "TGROUPI $key unknown TGROUP ID";
      $advcode[$advi] = "DATAHEALTH1031E";
      $advimpact[$advi] = $advcx{$advcode[$advi]};
      $advsit[$advi] = $iid;
   }
   if ($groupi_detail_ref->{objclass} == 2010) {
      my $groupref = $groupi_detail_ref->{objclass};
      $gkey = "2010" . "|" . $iid;
      my $group_ref = $group{$gkey};
      if (!defined $group_ref) {
         $advi++;$advonline[$advi] = "TGROUPI $key unknown Group $iobjname";
         $advcode[$advi] = "DATAHEALTH1032E";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $iobjname;
      } else {
         $group_ref->{indirect} = 1;
      }
   } elsif ($groupi_detail_ref->{objclass} == 5140) {
      my $sit1 = $groupi_detail_ref->{objname};
      if (!defined $sitx{$sit1}) {
         $advi++;$advonline[$advi] = "TGROUPI $key unknown Situation $iobjname";
         $advcode[$advi] = "DATAHEALTH1033E";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $iobjname;
      } else {
         $tgroupi{$sit1} = 1;      # remember sit is indirectly distributed.
      }
   } else {
       die "Unknown TGROUPI objclass $groupi_detail_ref->{objclass} working on $igrpclass $iid $iobjclass $iobjname";
   }
   if ($igrpclass eq '2010') {
      if (($iobjclass eq '5140') or ($iobjclass eq '2010')) {
         $gx = $grpx{$iid};
         if (defined $gx) {
            $grp_sit[$gx]->{$iobjname} = 1 if $iobjclass eq '5140';
            $grp_grp[$gx]->{$iobjname} = 1 if $iobjclass eq '2010';
         }
      }
   }
}

sub new_tobjaccl {
   my ($iobjclass,$iobjname,$inodel,$ilstdate) = @_;
   my $key = $inodel . "|". $iobjclass . "|" . $iobjname;
   my $ox = $objx{$key};
   if (!defined $ox) {
      $obji += 1;

      $ox = $obji;
      $obj[$obji] = $key;
      $objx{$key} = $obji;
      $obj_objclass[$obji] = $iobjclass;
      $obj_objname[$obji] = $iobjname;
      $obj_nodel[$obji] = $inodel;
      $obj_ct[$obji] = 0;
      $obj_lstdate[$obji] = $ilstdate;
   }
  $obj_ct[$ox] += 1;
  $tobjaccl{$iobjname} = 1;
  if ($iobjclass == 5140) {
     if ($iobjname eq "UADVISOR_O4SRV_OPLOG") {
        $obj_oplog += 1;
     }
  }
  if (substr($iobjname,0,8) eq "UADVISOR") {
     my $sit_tar_ref = $sit_tarx{$iobjname};
     if (!defined $sit_tar_ref) {
        my %sit_tarref = (
                            targets => {},
                         );
        $sit_tar_ref = \%sit_tarref;
        $sit_tarx{$iobjname} = \%sit_tarref;
     }
     $sit_tar_ref->{targets}{$inodel} = 1;
  }
}

sub new_tsitdesc {
   my ($isitname,$iautostart,$ilstdate,$ireev_days,$ireev_time,$isitinfo,$ipdt) = @_;
   $sx = $sitx{$isitname};
   if (!defined $sx) {
      $siti += 1;
      $sx = $siti;
      $sit[$siti] = $isitname;
      $sitx{$isitname} = $siti;
      $sit_autostart[$siti] = $iautostart;
      $sit_persist[$siti] = 1;
      $sit_pdt[$siti] = $ipdt;
      $sit_pdtseq[$siti] = 0;
      $sit_ct[$siti] = 0;
      $sit_lstdate[$siti] = $ilstdate;
      $sit_reeval[$siti] = 1;
      $sit_fullname[$siti] = "";
      $sit_psit[$siti] = $isitname;
      if ((length($ireev_days) == 0) or (length($ireev_days) > 3)) {
         $advi++;$advonline[$advi] = "Situation with invalid sampling days [$ireev_days]";
         $advcode[$advi] = "DATAHEALTH1071W";
         $advimpact[$advi] = $advcx{$advcode[$advi]};
         $advsit[$advi] = $isitname;
      }
      if (length($ireev_time) != 6){
         if ($ireev_time ne "0") {
            if ($ireev_time ne " 0") {
               if ($ireev_time ne " 00") {
                  $advi++;$advonline[$advi] = "Situation with invalid sampling time [$ireev_time]";
                  $advcode[$advi] = "DATAHEALTH1072W";
                  $advimpact[$advi] = $advcx{$advcode[$advi]};
                  $advsit[$advi] = $isitname;
               }
            }
         }
      }
      if ((length($ireev_days) >= 1) and (length($ireev_days) <= 3) ) {
         if ((length($ireev_time) >= 1) and (length($ireev_time) <= 6)) {
            $ireev_days += 0;
            $ireev_time .= "000000";                 # found some old situations with sample time "0000" so auto-extend
            $ireev_time = substr($ireev_time,0,6);
            my $reev_time_hh = 0;
            my $reev_time_mm = 0;
            my $reev_time_ss = 0;
            if ($ireev_time ne "0") {
               $reev_time_hh = substr($ireev_time,0,2);
               $reev_time_mm = substr($ireev_time,2,2);
               $reev_time_ss = substr($ireev_time,4,2);
            }
            $sit_reeval[$siti] = $ireev_days*86400 + $reev_time_hh*3600 + $reev_time_mm*60 + $reev_time_ss;   # sampling interval in seconds
         }
      }
      $isitinfo =~ /COUNT=(\d+)/;
      $sit_persist[$siti] = $1 if defined $1;
      my $pdt_ref = $pdtx{$ipdt};
      if (!defined $pdt_ref) {
         my %pdtref = (
                         count => 0,
                         sits => {},
                      );
         $pdt_ref = \%pdtref;
         $pdtx{$ipdt} = \%pdtref;
      }
      $pdt_ref->{count} += 1;
      $pdt_ref->{sits}{$isitname} = 1;
      $sit_pdtseq[$siti] = $pdt_ref->{count};
      $sit_correlate[$siti] = 0;
      $sit_until_ttl[$siti] = "";
      if ($sit_reeval[$siti] == 0) {
         if ($ipdt =~ /\*TTL (\S+) \)/) {
            $sit_until_ttl[$siti] = $1;
         }
      }
      $sit_purettl += 1 if $sit_until_ttl[$siti] ne "";
   }
  $sit_ct[$sx] += 1;
}

sub new_tname {
   my ($iid,$ilstdate,$ifullname) = @_;
   $nax = $namx{$iid};
   if (!defined $nax) {
      $nami += 1;
      $nax = $nami;
      $nam[$nami] = $iid;
      $namx{$iid} = $nami;
      $nam_fullname[$nami] = $ifullname;
      $nam_ct[$nami] = 0;
      $nam_lstdate[$nami] = $ilstdate;
   }
   $nam_ct[$nax] += 1;
   $sx = $sitx{$iid};
   if (defined $sx) {
      $sit_fullname[$sx] = $ifullname;
      $sit_psit[$sx] = $ifullname;
   }
}

# Record data from the TNODESAV table. This is the disk version of [most of] the INODESTS or node status table.
# capture node name, product, version, online status


sub new_tnodesav {
   my ($inode,$iproduct,$iversion,$io4online,$ihostaddr,$ireserved,$ithrunode,$ihostinfo,$iaffinities) = @_;
   my $itema = "";
   my $isysname = "";
   $nsx = $nsavex{$inode};
   if (!defined $nsx) {
      $nsavei++;
      $nsx = $nsavei;
      $nsave[$nsx] = $inode;
      $nsavex{$inode} = $nsx;
      $nsave_sysmsl[$nsx] = 0;
      $nsave_product[$nsx] = $iproduct;
      $nsave_affinities[$nsx] = $iaffinities;
      if ($iversion ne "") {
         my $tversion = $iversion;
         $tversion =~ s/[0-9\.]+//g;
         if ($tversion ne "") {
            $advi++;$advonline[$advi] = "Invalid agent version [$iversion] in node $inode tnodesav";
            $advcode[$advi] = "DATAHEALTH1036E";
            $advimpact[$advi] = $advcx{$advcode[$advi]};
            $advsit[$advi] = $inode;
            $iversion = "00.00.00";
         }
      }
      $nsave_arch[$nsx] = "";
      if ($ireserved ne "") {
         $ireserved =~ /:(\S+?)\;/;
         $nsave_arch[$nsx] = $1 if defined $1;
      }
      $nsave_version[$nsx] = $iversion;
      $nsave_subversion[$nsx] = "";
      $nsave_hostaddr[$nsx] = $ihostaddr;
      if ($ihostaddr ne "") {
         if (index($ihostaddr,"<NM>") == -1){
            if ($iproduct ne "EM") {
               $advi++;$advonline[$advi] = "Agent with hostaddr [$ihostaddr] missing the <NM>..</NM> hostname setting";
               $advcode[$advi] = "DATAHEALTH1108W";
               $advimpact[$advi] = $advcx{$advcode[$advi]};
               $advsit[$advi] = $inode;
            }
         }  else {
            if (defined $agtosx{$iproduct}) {
               $ihostaddr =~ /\<NM\>(.*)\</;
               if (defined $1) {
                  my $iasysname = $1;
                  my %anoderef = (
                                    node => $inode,
                                    hostaddr => $ihostaddr,
                                    product => $iproduct,
                                 );
                  $asysnamex{$iasysname} = \%anoderef;
               }
            }
         }
      }
      $nsave_hostinfo[$nsx] = $ihostinfo;
      $nsave_ct[$nsx] = 0;
      $nsave_o4online[$nsx] = $io4online;
      $nsave_common[$nsx] = "";
      if (length($ireserved) == 0) {
         $nsave_temaver[$nsx] = "";
         $itema = "";
      } else {
         my @words;
         @words = split(";",$ireserved);
         $nsave_temaver[$nsx] = "";
         $nsave_common[$nsx] = "";
         # found one agent with RESERVED == A=00:ls3246;;;
         if ($#words > 0) {
            if ($words[0] ne "") {
               $nsave_subversion[$nsx] = substr($words[0],2,2);
            }
            if ($words[1] ne "") {
               $nsave_common[$nsx] = substr($words[1],2);
               @words = split(":",$words[1]);
               $nsave_temaver[$nsx] = substr($words[0],2,8);
               $itema = $nsave_temaver[$nsx];
            }
         }
      }
   }
   $vtx = $vtnodex{$iproduct};
   if (defined $vtx) {
      $vtnode_ct[$vtx] += 1;
      $vtnode_tot_ct += 1;
   }
   # count number of nodes. If more then one there is a primary key duplication error
   $nsave_ct[$nsx] += 1;
   # track the TEMS and the version
   if ($iproduct eq "EM") {
      $tx = $temsx{$inode};
      if (!defined $tx) {
         $temsi += 1;
         $tx = $temsi;
         my $arch = "";
         $ireserved =~ /:(.*?)\;/;
         $arch = $1 if defined $1;
         $tems[$tx] = $inode;
         $temsx{$inode} = $tx;
         $tems_hub[$tx] = 0;
         $tems_ct[$tx] = 0;
         $tems_ctnok[$tx] = 0;
         $tems_version[$tx] = $iversion;
         $tems_o4online[$tx] = $io4online;
         $tems_arch[$tx] = $arch;
         $tems_thrunode[$tx] = $ithrunode;
         $tems_hostaddr[$tx] = $ihostaddr;
         $tems_affinities[$tx] = $iaffinities;
         $tems_sampload[$tx] = 0;
         $tems_sampsit[$tx] = 0;
         $tems_puresit[$tx] = 0;
         $tems_sampload_dedup[$tx] = 0;
         $tems_sampsit_dedup[$tx] = 0;
         $tems_puresit_dedup[$tx] = 0;
         $tems_spipe[$tx] = 0;
      }
   }
   my $arch = "";
   $ireserved =~ /:(.*?)\;/;
   $arch = $1 if defined $1;
   # track the TEPS and the version
   if ($iproduct eq "CQ") {
      $tx = $tepsx{$inode};
      if (!defined $tx) {
         $tepsi += 1;
         $tx = $tepsi;
         $teps[$tx] = $inode;
         $tepsx{$inode} = $tx;
         $teps_version[$tx] = $iversion;
         $teps_arch[$tx] = $arch;
      }
   }
   # track the i/5 OS Agent and the version
   if ($arch eq "i5os") {
      my $sub_level = "00";
      $ireserved =~ /A=(\d+):/;
      $sub_level = $1 if defined $1;
      my $agt_version = $iversion . "." . $sub_level;
      my $key = $iproduct . $agt_version;
      $tx = $ka4x{$key};
      if (!defined $tx) {
         $ka4i += 1;
         $tx = $ka4i;
         $ka4[$tx] = $key;
         $ka4x{$key} = $tx;
         $ka4_product[$tx] = $iproduct;
         $ka4_version[$tx] = $agt_version;
         $ka4_version_count[$tx] = 0;
      }
      $ka4_version_count[$tx] += 1;
   }
   # track individual HOSTADDR
   # duplicates often reflect minor issues
   if (defined $ihostaddr) {
      if ($ihostaddr ne "") {
         $hsx = $hsavex{$ihostaddr};
         if (!defined $hsx) {
            $hsavei++;
            $hsx = $hsavei;
            $hsave[$hsx] = $ihostaddr;
            $hsavex{$ihostaddr} = $hsx;
            $hsave_ndx[$hsx] = "";
            $hsave_ct[$hsx] = 0;
            $hsave_thrundx[$hsx] = "";
         }

         # record the node indexes of each duplicate
         $hsave_ndx[$hsx] .= $nsx . " ";
         $hsave_ct[$hsx] += 1;

         # track uses of duplicate SYSTEM_NAME across different IP addresses
         # which can mess up Portal Client Navigator displays badly
         # ip.pipe:#172.17.117.34[10055]<NM>CNWDC4AHMAAA</NM>
         if (index($ihostaddr,"[") != -1) {
            $ihostaddr =~ /:(\S+?)\[(.*)/;
            $ihostaddr =~ /\((\S+?)\)\[(.*)/ if !defined $1;   # IPV6 style
            my $isysip = $1;
            my $hrest = $2;
            if (defined $isysip) {
               if (defined $hrest) {
                  if (index($hrest,"<NM") != -1) {
                     $hrest =~ /\<NM\>(\S+)\</;
                     my $isysname = $1;
                     if (defined $isysname) {
                        my $sysname_ref = $sysnamex{$isysname};
                        if (!defined $sysname_ref) {
                           my %sysnameref = (
                                               count => 0,
                                               ipcount => 0,
                                               sysipx => {},
                                            );
                           $sysnamex{$isysname} = \%sysnameref;
                           $sysname_ref = \%sysnameref;
                        }
                        $sysname_ref->{count} += 1;
                        my $sysip_ref = $sysname_ref->{sysipx}{$isysip};
                        if (!defined $sysip_ref) {
                           my %sysipref = (
                                             count => 0,
                                             instance => {},
                                          );
                           $sysname_ref->{sysipx}{$isysip} = \%sysipref;
                           $sysip_ref = \%sysipref;
                           $sysname_ref->{ipcount} += 1;
                        }
                        $sysip_ref->{count} += 1;
                        my %sysip_node_ref = (
                                                hostaddr => $ihostaddr,
                                                thrunode => $ithrunode,
                                                affinities => $iaffinities,
                                            );
                        $sysip_ref->{instance}{$inode} = \%sysip_node_ref;
                     }
                  }
               }
               my $ip_ref = $ipx{$isysip};
               if (!defined $ip_ref) {
                  my %ipref = (
                                 count => 0,
                                 level => {},
                                 agents => {},
                                 arch => {},
                                 hostname => {},
                              );
                  $ip_ref = \%ipref;
                  $ipx{$isysip}  = \%ipref;
               }
               $ip_ref->{agents}{$inode} = "";
               if ($nsave_common[$nsx] ne "") {
                  my $tema_level = $nsave_common[$nsx];
                  $tema_level =~ /(\S+):(\S+)/;
                  $tema_level = $1;
                  my $tema_arch = $2;
                  if (defined $tema_level) {
                     if (!defined $ip_ref->{level}{$tema_level}) {
                        $ip_ref->{level}{$tema_level} = 1;
                        $ip_ref->{arch}{$inode} = $tema_arch;
                        $ip_ref->{agents}{$inode} = $tema_level;
                        $ip_ref->{count} += 1;
                     }
                  }
               }
               # count the number of :'s in the agent name
               my $inode = $nsave[$nsx];
               my $tnode = $nsave[$nsx];
               $tnode =~ s/[^:]//g;
               my $ncolons = length($tnode);
               my $ihostname = "";
               my @wnodes = split(":",$inode);
               if ($ncolons == 0) {
                  $ihostname = $inode;
               } elsif ($ncolons == 1) {
                  $ihostname = $wnodes[0];
               } elsif ($ncolons == 2) {
                  $ihostname = $wnodes[1];
               }
               $ip_ref->{hostname}{$ihostname}{count} += 1 if $ihostname ne "";
            }
         }
      }
   }
   if ($io4online eq "N") {
      my $offline_agent_ref = $offline_agentx{$inode};
      if (!defined $offline_agent_ref) {
         my %offline_agentref = (
                                   count => 0,
                                   product => $iproduct,
                                   version => $iversion,
                                   hostaddr => $ihostaddr,
                                   reserved => $ireserved,
                                   thrunode => $ithrunode,
                                   hostinfo => $ihostinfo,
                                   hostaddr => $ihostaddr,
                                );
         $offline_agent_ref = \%offline_agentref;
         $offline_agentx{$inode} = \%offline_agentref;
      }
      $offline_agent_ref->{count} += 1;

      my $offline_thrunode_ref = $offline_thrunodex{$ithrunode};
      if (!defined $offline_thrunode_ref) {
         my %offline_thrunoderef = (
                                      count => 0,
                                   );
         $offline_thrunode_ref = \%offline_thrunoderef;
         $offline_thrunodex{$ithrunode} = \%offline_thrunoderef;
      }
      $offline_thrunode_ref->{count} += 1;

      my $offline_product_ref = $offline_productx{$iproduct};
      if (!defined $offline_product_ref) {
         my %offline_productref = (
                                      count => 0,
                                  );
         $offline_product_ref = \%offline_productref;
         $offline_productx{$iproduct} = \%offline_productref;
      }
      $offline_product_ref->{count} += 1;

      my $iproductversion = $iproduct . "|" . $iversion;
      my $offline_productversion_ref = $offline_productversionx{$iproductversion};
      if (!defined $offline_productversion_ref) {
         my %offline_productversionref = (
                                            count => 0,
                                            product => $iproduct,
                                            version => $iversion,
                                         );
         $offline_productversion_ref = \%offline_productversionref;
         $offline_productversionx{$iproductversion} = \%offline_productversionref;
      }
      $offline_productversion_ref->{count} += 1;

      if ($itema ne "") {
         my $offline_tema_ref = $offline_temax{$itema};
         if (!defined $offline_tema_ref) {
            my %offline_temaref = (
                                         count => 0,
                                     );
            $offline_tema_ref = \%offline_temaref;
            $offline_temax{$itema} = \%offline_temaref;
         }
         $offline_tema_ref->{count} += 1;
      }
   }
}


# Record data from the TNODELST NODETYPE=V table. This is the ALIVE data which captures the thrunode

sub new_tnodelstv {
   my ($inodetype,$inodelist,$inode,$ilstdate) = @_;
   # The $inodelist is the managed system name. Record that data
   $vlx = $nlistvx{$inodelist};
   if (!defined $vlx) {
      $nlistvi++;
      $vlx = $nlistvi;
      $nlistv[$vlx] = $inodelist;
      $nlistvx{$inodelist} = $vlx;
      $nlistv_thrunode[$vlx] = $inode;
      $nlistv_tems[$vlx] = "";
      $nlistv_ct[$vlx] = 0;
      $nlistv_lstdate[$vlx] = $ilstdate;
      $nlistv_sitx[$vlx] = {};
   }

   # The $inode is the thrunode, capture that data.
   $nlistv_ct[$vlx] += 1;
   $tx = $temsx{$inode};      # is thrunode a TEMS?
   # keep track of managing agent - which have subnodes
   # before ITM 623 FP2 this was limited in size and needs an advisory
   if (!defined $tx) {        # if not it is a managing agent
      $mx = $magentx{$inode};
      if (!defined $mx) {
         $magenti += 1;
         $mx = $magenti;
         $magent[$mx] = $inode;
         $magentx{$inode} = $mx;
         $magent_subct[$mx] = 0;
         $magent_sublen[$mx] = 0;
         $magent_tems_version[$mx] = "";
         $magent_tems[$mx] = "";
      }
      $magent_subct[$mx] += 1;
      # the actual limit is the names in a list with single blank delimiter
      # If the exceeds 32767 bytes, a TEMS crash or other malfunction can happen.
      $magent_sublen[$mx] += length($inodelist) + 1;
   } else {
     # if directly connected to a TEMS, record the TEMS
     $nlistv_tems[$vlx] = $tems[$tx];
   }
}

# After the TNODELST NODETYPE=V data is captured, correlate data

sub fill_tnodelstv {
   #Go back and fill in the nlistv_tems
   # If the node is a managing agent, determine what the TEMS it reports to
   for ($i=0; $i<=$nlistvi; $i++) {
       next if $nlistv_tems[$i] ne "";
       my $subnode = $nlistv_thrunode[$i];
       $vlx = $nlistvx{$subnode};
       if (defined $vlx) {
          $nlistv_tems[$i] = $nlistv_thrunode[$vlx];
       }
   }

   #Go back and fill in the $magent_tems_version
   #if the agent reports to a managing agent, count the instances and also
   #record the TEMS version the managing agent connects to.
   for ($i=0; $i<=$nlistvi; $i++) {
       my $node1 = $nlistv[$i];
       $mx = $magentx{$node1};
       next if !defined $mx;
       my $mnode = $magent[$mx];
       $vlx = $nlistvx{$mnode};
       next if !defined $vlx;
       my $mthrunode = $nlistv_thrunode[$vlx];
       $tx = $temsx{$mthrunode};
       next if !defined $tx;
       $magent_tems_version[$mx] = $tems_version[$tx];
       $magent_tems[$mx] = $mthrunode;
   }


   #Go back and fill in the $hsave_thrundx
   for ($i=0; $i<=$hsavei; $i++) {
      my $pi;
      next if $hsave_ndx[$i] eq "";
      my @hagents = split(" ",$hsave_ndx[$i]);
      my $pthrundx = "";
      for (my $j=0;$j<=$#hagents;$j++) {
         $pi = $hagents[$j];
         my $oneagent = $nsave[$pi];
         my $vx = $nlistvx{$oneagent};
         if (!defined $vx) {
            $pthrundx .= ". ";
            next;
         }
         my $onethru = $nlistv_thrunode[$vx];
         $tx = $temsx{$onethru};
         if (!defined $tx) {
            $pthrundx .= ". ";
            next;
         }
         if ($nlistv_thrunode[$vx] ne "") {
            $pthrundx .= $nlistv_thrunode[$vx] . " ";
         } else {
            $pthrundx .= ". ";
         }
      }
      $hsave_thrundx[$i] = $pthrundx;
   }
   for ($i=0; $i<=$nlistvi; $i++) {
       my $node1 = $nlistv[$i];
       $mx = $magentx{$node1};
       next if !defined $mx;
       my $mnode = $magent[$mx];
       $vlx = $nlistvx{$mnode};
       next if !defined $vlx;
       my $mthrunode = $nlistv_thrunode[$vlx];
       $tx = $temsx{$mthrunode};
       next if !defined $tx;
       $magent_tems_version[$mx] = $tems_version[$tx];
   }
}


# Record data from the TNODELST NODETYPE=M table. This is the MSL

sub new_tnodelstm {
my ($inodetype,$inodelist,$inode,$ilstdate) = @_;
   return if $inode eq "--EMPTYNODE--";         # ignore empty tables
   # primary key is node and nodelist. Track and count duplicates for the severe index error
   $mkey = $inode . "|" . $inodelist;
   $mlx = $mlistx{$mkey};
   if (!defined $mlx) {
      $mlisti += 1;
      $mlx = $mlisti;
      $mlist[$mlx] = $mkey;
      $mlistx{$mkey} = $mlx;
      $mlist_ct[$mlx] = 0;
      $mlist_lstdate[$mlx] = $ilstdate;
      $mlist_nodelist[$mlx] = $inodelist;
      $mlist_node[$mlx] = $inode;
   }
   $mlist_ct[$mlx] += 1;

   $nlx = $nlistx{$inodelist};
   if (!defined $nlx) {
      $nlisti += 1;
      $nlx = $nlisti;
      $nlist[$nlx] = $inodelist;
      $nlistx{$inodelist} = $nlx;
   }
   $nlist_agents[$nlx]{$inode} = 1;

   # record the agent oriented data. During processing we will record data about
   # various missing cases.
   $mlx = $nlistmx{$inode};
   if (!defined $mlx) {
      $nlistmi++;
      $mlx = $nlistmi;
      $nlistm[$mlx] = $inode;
      $nlistmx{$inode} = $mlx;
      $nlistm_miss[$mlx] = 0;
      $nlistm_nov[$mlx] = 0;
   }

   # record data about missing system generated MSLs
   $nsx = $nsavex{$inode};
   if (defined $nsx) {
      $vlx = $nlistvx{$inode};
      if (defined $vlx) {
        my $lthrunode = $nlistv_thrunode[$vlx];
        $tx = $temsx{$lthrunode};
        if (defined $tx) {
           $nsave_sysmsl[$nsx] += 1 if substr($inodelist,0,1) eq "*";
        }
      } else {
        $nlistm_nov[$mlx] = 1 if $nsave_product[$nsx] ne "EM";
      }
   } else {
      $nlistm_miss[$mlx] = 1;
   }
  my $tar_node_ref = $tar_nodex{$inodelist};
  if (!defined $tar_node_ref) {
     my %tar_noderef = (
                          nodes => {},
                       );
     $tar_node_ref = \%tar_noderef;
     $tar_nodex{$inodelist} = \%tar_noderef;
  }
  $tar_node_ref->{nodes}{$inode} = 1;
}


# Record data from the TEIBLOGT table.

sub new_teiblogt {
my ($igbltmstmp,$iobjname,$operation,$itable) = @_;
   my $inode = substr($iobjname,0,32);
   $inode =~ s/\s+$//;   #trim trailing whitespace
   my $ithrunode = substr($iobjname,32,32);
   $ithrunode =~ s/\s+$//;   #trim trailing whitespace

   # There are two cases we want to track
   #  $inode = managed system list, $ithrunode = system generated managed system TNODELST M type records
   #  $inode and $ithrunode = managed system    TNODELST V type records

   my $doit = 0;
   if (defined $nlistx{$inode}) {
      if ((substr($inode,0,1) eq "*") and (defined $nsavex{$ithrunode})) {
          ($inode,$ithrunode) = ($ithrunode,$inode);
          $doit = 1;
      }
   } elsif ((defined $nsavex{$inode}) and (defined $nsavex{$ithrunode})) {
       $doit = 1;
   }
   if ($doit == 1) {
      my $node_ref = $eibnodex{$inode};
      if (!defined $node_ref) {
         my %thrunoderef = ();
         my %noderef = ( count => 0,
                         thrunode => \%thrunoderef,
                       );
         $node_ref = \%noderef;
         $eibnodex{$inode} = \%noderef;
      }
      $eibnodex{$inode}->{count} += 1;
      my $thrunode_ref = $eibnodex{$inode}->{thrunode}{$ithrunode};
      if (!defined $thrunode_ref) {
         my %thrunoderef = ( count => 0,
                             gbltmstmp => [],
                           );
         $thrunode_ref = \%thrunoderef;
         $eibnodex{$inode}->{thrunode}{$ithrunode} = \%thrunoderef;
      }
      $eibnodex{$inode}->{thrunode}{$ithrunode}->{count} += 1;
      push (@{$eibnodex{$inode}->{thrunode}{$ithrunode}->{gbltmstmp}},$igbltmstmp);
   }
}


sub new_tsitstsh {
   my ($igbltmstmp,$ideltastat,$isitname,$inode,$ioriginnode,$iatomize) = @_;
   return if ($ideltastat ne "Y") and ($ideltastat ne "N");
   my $sitkey = $isitname . "|" . $iatomize;
   my $sit_ref = $eventx{$sitkey};
   if (!defined $sit_ref) {
      my %originref = ();
      my %sitref = (
                      sitname => $isitname,
                      atomize => $iatomize,
                      nodes => {},
                      count => 0,
                      open  => 0,
                      close => 0,
                      reeval => 0,                      # 0 for sampled, >0 for pure
                      start => $igbltmstmp,
                      last  => $igbltmstmp,
                      origin => \%originref,
                   );
      $sit_ref = \%sitref;
      $eventx{$sitkey} = \%sitref;
      my $sx = $sitx{$isitname};
      $sit_ref->{reeval} = $sit_reeval[$sx] if defined $sx;
   }
   $sit_ref->{nodes}{$ioriginnode} = 1;
   $sit_ref->{count} += 1;
   $sit_ref->{open} += 1 if $ideltastat eq "Y";
   $sit_ref->{close} += 1 if $ideltastat eq "N";

   if ($igbltmstmp < $sit_ref->{start}) {
      $sit_ref->{start} = $igbltmstmp;
   }
   if ($igbltmstmp > $sit_ref->{last}) {
      $sit_ref->{last} = $igbltmstmp;
   }
    if ($eventx_start == -1) {
       $eventx_start = $igbltmstmp;
       $eventx_last = $igbltmstmp;
    }
    if ($igbltmstmp < $eventx_start) {
       $eventx_start = $igbltmstmp;
    }
    if ($igbltmstmp > $eventx_last) {
       $eventx_last = $igbltmstmp;
    }
    my $okey = $ioriginnode . "|" . $inode;
    my $origin_ref =  $sit_ref->{origin}{$okey};
    if (!defined $origin_ref) {
       my %originref = (
                          node => $ioriginnode,
                          thrunode => $inode,
                          count => 0,
                          open  => 0,
                          close => 0,
                          atomize => 0,
                          start => $igbltmstmp,
                          last  => $igbltmstmp,
                       );
       $origin_ref = \%originref;
       $eventx{$sitkey}->{origin}{$okey} = \%originref;
    }
    $origin_ref->{count} += 1;
    $origin_ref->{open} += 1 if $ideltastat eq "Y";
    $origin_ref->{close} += 1 if $ideltastat eq "N";
    $origin_ref->{atomize} += 1 if $iatomize ne "";

    if ($igbltmstmp < $origin_ref->{start}) {
       $origin_ref->{start} = $igbltmstmp;
    }
    if ($igbltmstmp > $origin_ref->{last}) {
       $origin_ref->{last} = $igbltmstmp;
    }
}


# following routine gets data from txt files. tems2sql.pl is an internal only program which can
# extract data from a TEMS database file.

#perl \rexx\bin\tems2sql.pl -txt -s SITNAME -tlim 0 -tc SITNAME,AUTOSTART,SITINFO,CMD,AUTOSOPT,REEV_DAYS,REEV_TIME,PDT  c:\ibm\itm622\kib.cat  QA1CSITF.DB  > QA1CSITF.DB.TXT
#perl \rexx\bin\tems2sql.pl -txt -s ID -tc ID,FULLNAME  c:\ibm\itm622\kib.cat  QA1DNAME.DB  > QA1DNAME.DB.TXT

sub init_txt {
   my @klst_data;
   my $inode;
   my $inodelist;
   my $inodetype;

   my @ksav_data;
   my $io4online;
   my $iproduct;
   my $iversion;
   my $ihostaddr;
   my $ihostinfo;
   my $ireserved;
   my $ithrunode;
   my $iaffinities;

   my @ksit_data;
   my $isitname;
   my $iautostart;
   my $ireev_days;
   my $ireev_time;
   my $ipdt;
   my $isitinfo;

   my @knam_data;
   my $iid;
   my $ifullname;

   my @kobj_data;
   my $iobjclass;
   my $iobjname;
   my $inodel;

   my @kgrp_data;
   my $igrpclass;
   my $igrpname;

   my @kgrpi_data;

   my @kevsr_data;
   my $ilstdate;
   my $ilstusrprf;

   my @kdsca_data;

   my @kcct_data;
   my $ikey;
   my $iname;

   my @kevmp_data;
   my $imap;

   my @kpcyf_data;
   my $ipcyname;

   my @kactp_data;
   my $itypestr;
   my $iactname;
   my $iactinfo;

   my @kcale_data;

   my @kovrd_data;

   my @kovri_data;
   my $iitemid;
   my $icalid;

   my @keibl_data;
   my $igbltmstmp;
   my $ioperation;
   my $itable;

   my @kstsh_data;
   my $ideltastat;
   my $ioriginnode;
   my $iatomize;

   my @kckpt_data;

   open(KSAV, "< $opt_txt_tnodesav") || die("Could not open TNODESAV $opt_txt_tnodesav\n");
   @ksav_data = <KSAV>;
   close(KSAV);

   # Get data for all TNODESAV records
   $ll = 0;
   foreach $oneline (@ksav_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $inode = substr($oneline,0,32);
      $inode =~ s/\s+$//;   #trim trailing whitespace
      $io4online = substr($oneline,33,1);
      $nsave_offline += ($io4online eq "N");
      $nsave_online += ($io4online eq "Y");
      # if offline with no product, ignore - maybe produce advisory later
      $iproduct = substr($oneline,42,2);
      $iproduct =~ s/\s+$//;   #trim trailing whitespace
      if ($io4online eq "N") {
         next if $iproduct eq "";
      }
      $iversion = substr($oneline,50,8);
      $iversion =~ s/\s+$//;   #trim trailing whitespace
      $ihostaddr = substr($oneline,59,256);
      $ihostaddr =~ s/\s+$//;   #trim trailing whitespace
      $ireserved = substr($oneline,315,64);
      $ireserved =~ s/\s+$//;   #trim trailing whitespace
      $ithrunode = substr($oneline,380,32);
      $ithrunode =~ s/\s+$//;   #trim trailing whitespace
      $ihostinfo = substr($oneline,413,16);
      $ihostinfo =~ s/\s+$//;   #trim trailing whitespace
      $iaffinities = substr($oneline,430,43);
      $iaffinities =~ s/\s+$//;   #trim trailing whitespace
      new_tnodesav($inode,$iproduct,$iversion,$io4online,$ihostaddr,$ireserved,$ithrunode,$ihostinfo,$iaffinities);
   }

   open(KLST, "<$opt_txt_tnodelst") || die("Could not open TNODELST $opt_txt_tnodelst\n");
   @klst_data = <KLST>;
   close(KLST);

   # Get data for all TNODELST type V records
   $ll = 0;
   foreach $oneline (@klst_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $inode = substr($oneline,0,32);
      $inode =~ s/\s+$//;   #trim trailing whitespace
      $inodetype = substr($oneline,33,1);
      $inodelist = substr($oneline,42,32);
      $inodelist =~ s/\s+$//;   #trim trailing whitespace
      if ($inodelist eq "*HUB") {
         $inodetype = "V" if $inodetype eq " ";
         $inodelist = $inode;
      }
      next if $inodetype ne "V";
      $ilstdate = substr($oneline,75,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      new_tnodelstv($inodetype,$inodelist,$inode,$ilstdate);
   }
   fill_tnodelstv();


   # Get data for all TNODELST type M records
   $ll = 0;
   foreach $oneline (@klst_data) {
      $ll += 1;
      next if $ll < 5;
      $inodetype = substr($oneline,33,1);
      $inodelist = substr($oneline,42,32);
      $inodelist =~ s/\s+$//;   #trim trailing whitespace
      $inode = substr($oneline,0,32);
      $inode =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,75,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      if (($inodetype eq " ") and ($inodelist eq "*HUB")) {    # *HUB has blank NODETYPE. Set to M for this calculation
         $inodetype = "M";
         $tx = $temsx{$inode};
         if (defined $tx) {
            $tems_hub[$tx] = 1;
            $hub_tems = $inode;
            $hub_tems_version = $tems_version[$tx];
         } else {
            $hub_tems_no_tnodesav = 1;
            $hub_tems = $inode;
            $hub_tems_version = "";
         }
      }
      next if $inodetype ne "M";
      new_tnodelstm($inodetype,$inodelist,$inode,$ilstdate);
   }

   open(KSIT, "< $opt_txt_tsitdesc") || die("Could not open TSITDESC $opt_txt_tsitdesc\n");
   @ksit_data = <KSIT>;
   close(KSIT);

   # Get data for all TSITDESC records
   $ll = 0;
   foreach $oneline (@ksit_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $isitname = substr($oneline,0,32);
      $isitname =~ s/\s+$//;   #trim trailing whitespace
      $iautostart = substr($oneline,33,4);
      $iautostart =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,38,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $ireev_days = substr($oneline,55,3);
      $ireev_days =~ s/\s+$//;   #trim trailing whitespace
      $ireev_time = substr($oneline,59,6);
      $ireev_time =~ s/\s+$//;   #trim trailing whitespace
      $isitinfo = substr($oneline,68,128);
      $isitinfo =~ s/\s+$//;   #trim trailing whitespace
      $ipdt = substr($oneline,197);
      $ipdt =~ s/\s+$//;   #trim trailing whitespace
      new_tsitdesc($isitname,$iautostart,$ilstdate,$ireev_days,$ireev_time,$isitinfo,$ipdt);
   }

   open(KNAM, "< $opt_txt_tname") || die("Could not open TNAME $opt_txt_tname\n");
   @knam_data = <KNAM>;
   close(KNAM);

   # Get data for all TNAME records
   $ll = 0;
   foreach $oneline (@knam_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iid  = substr($oneline,0,32);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,33,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $ifullname = substr($oneline,50);
      $ifullname =~ s/\s+$//;   #trim trailing whitespace
      new_tname($iid,$ilstdate,$ifullname);
   }

   open(KOBJ, "< $opt_txt_tobjaccl") || die("Could not open TOBJACCL $opt_txt_tobjaccl\n");
   @kobj_data = <KOBJ>;
   close(KOBJ);

   # Get data for all TOBJACCL records
   $ll = 0;
   foreach $oneline (@kobj_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iobjclass = substr($oneline,0,4);
      $iobjclass =~ s/\s+$//;   #trim trailing whitespace
      $iobjname = substr($oneline,9,32);
      $iobjname =~ s/\s+$//;   #trim trailing whitespace
      $inodel = substr($oneline,42,32);
      $inodel =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,75,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      next if ($iobjclass != 5140) and ($iobjclass != 2010);
      new_tobjaccl($iobjclass,$iobjname,$inodel,$ilstdate);
   }

   open(KGRP, "< $opt_txt_tgroup") || die("Could not open TGROUP $opt_txt_tgroup\n");
   @kgrp_data = <KGRP>;
   close(KGRP);

   # Get data for all TGROUP records
   $ll = 0;
   foreach $oneline (@kgrp_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $igrpclass = substr($oneline,0,4);
      $igrpclass =~ s/\s+$//;   #trim trailing whitespace
      $iid  = substr($oneline,9,32);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate  = substr($oneline,42,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $igrpname = substr($oneline,59);
      $igrpname =~ s/\s+$//;   #trim trailing whitespace
      new_tgroup($igrpclass,$iid,$ilstdate,$igrpname);
   }

   open(KGRPI, "< $opt_txt_tgroupi") || die("Could not open TGROUPI $opt_txt_tgroupi\n");
   @kgrpi_data = <KGRPI>;
   close(KGRPI);

   # Get data for all TGROUPI records
   $ll = 0;
   foreach $oneline (@kgrpi_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $igrpclass = substr($oneline,0,4);
      $igrpclass =~ s/\s+$//;   #trim trailing whitespace
      $iid  = substr($oneline,9,32);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate  = substr($oneline,42,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $iobjclass = substr($oneline,59,4);
      $iobjclass =~ s/\s+$//;   #trim trailing whitespace
      $iobjname = substr($oneline,68,32);
      $iobjname =~ s/\s+$//;   #trim trailing whitespace
      new_tgroupi($igrpclass,$iid,$ilstdate,$iobjclass,$iobjname);
   }

   open(KEVSR, "< $opt_txt_evntserver") || die("Could not open EVNTSERVER $opt_txt_evntserver\n");
   @kevsr_data = <KEVSR>;
   close(KEVSR);

   # Get data for all EVNTSERVER records
   $ll = 0;
   foreach $oneline (@kevsr_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iid = substr($oneline,0,3);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,3,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $ilstusrprf = substr($oneline,20,10);
      $ilstusrprf =~ s/\s+$//;   #trim trailing whitespace
      new_evntserver($iid,$ilstdate,$ilstusrprf);
   }

   open(KDSCA, "< $opt_txt_package") || die("Could not open PACKAGE $opt_txt_package\n");
   @kdsca_data = <KDSCA>;
   close(KDSCA);

   # Count entries in PACKAGE file
   $ll = 0;
   foreach $oneline (@kdsca_data) {
      $ll += 1;
      next if $ll < 5;
      $tems_packages += 1;
   }

   open(KCCT, "< $opt_txt_cct") || die("Could not open CCT $opt_txt_cct\n");
   @kcct_data = <KCCT>;
   close(KCCT);

   # Get data for all CCT records
   $ll = 0;
   foreach $oneline (@kcct_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $ikey = substr($oneline,0,32);
      $ikey =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,32,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $iname = substr($oneline,50,128);
      $iname =~ s/\s+$//;   #trim trailing whitespace
      new_cct($ikey,$ilstdate,$iname);
   }

   open(KEVMP, "< $opt_txt_evntmap") || die("Could not open EVNTMAP $opt_txt_evntmap\n");
   @kevmp_data = <KEVMP>;
   close(KEVMP);

   # Get data for all EVNTMAP records
   $ll = 0;
   foreach $oneline (@kevmp_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iid = substr($oneline,0,32);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,32,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $imap = substr($oneline,50,128);
      $imap =~ s/\s+$//;   #trim trailing whitespace
      new_evntmap($iid,$ilstdate,$imap);
   }

   open(KPCYF, "< $opt_txt_tpcydesc") || die("Could not open TPCYDESC $opt_txt_tpcydesc\n");
   @kpcyf_data = <KPCYF>;
   close(KPCYF);

   # Get data for all TPCYDESC records
   $ll = 0;
   foreach $oneline (@kpcyf_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $ipcyname = substr($oneline,0,32);
      $ipcyname =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,32,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $iautostart = substr($oneline,50,4);
      $iautostart =~ s/\s+$//;   #trim trailing whitespace
      new_tpcydesc($ipcyname,$ilstdate,$iautostart);
   }

   open(KACTP, "< $opt_txt_tactypcy") || die("Could not open TACTYPCY $opt_txt_tactypcy\n");
   @kactp_data = <KACTP>;
   close(KACTP);

   # Get data for all TACTYPCY records
   $ll = 0;
   foreach $oneline (@kactp_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iactname = substr($oneline,0,32);
      $iactname =~ s/\s+$//;   #trim trailing whitespace
      $ipcyname = substr($oneline,33,32);
      $ipcyname =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,66,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $itypestr = substr($oneline,83,32);
      $itypestr =~ s/\s+$//;   #trim trailing whitespace
      $iactinfo = substr($oneline,116,252);
      $iactinfo =~ s/\s+$//;   #trim trailing whitespace
      new_tactypcy($iactname,$ipcyname,$ilstdate,$itypestr,$iactinfo);
   }

   open(KCALE, "< $opt_txt_tcalendar") || die("Could not open TCALENDAR $opt_txt_tcalendar\n");
   @kcale_data = <KCALE>;
   close(KCALE);
   # Get data for all TCALENDAR records
   $ll = 0;
   foreach $oneline (@kcale_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iid = substr($oneline,0,32);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,33,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $iname = substr($oneline,50,256);
      $iname =~ s/\s+$//;   #trim trailing whitespace
      new_tcalendar($iid,$ilstdate,$iname);
   }

   open(KOVRD, "< $opt_txt_toverride") || die("Could not open TOVERRIDE $opt_txt_toverride\n");
   @kovrd_data = <KOVRD>;
   close(KOVRD);
   # Get data for all TOVERRIDE records
   $ll = 0;
   foreach $oneline (@kovrd_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iid = substr($oneline,0,32);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,33,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $isitname = substr($oneline,50,32);
      $isitname =~ s/\s+$//;   #trim trailing whitespace
      new_toverride($iid,$ilstdate,$isitname);
   }

   open(KOVRI, "< $opt_txt_toveritem") || die("Could not open TOVERITEM $opt_txt_toveritem\n");
   @kovri_data = <KOVRI>;
   close(KOVRI);
   # Get data for all TOVERITEM records
   $ll = 0;
   foreach $oneline (@kovri_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $iid = substr($oneline,0,32);
      $iid =~ s/\s+$//;   #trim trailing whitespace
      $ilstdate = substr($oneline,33,16);
      $ilstdate =~ s/\s+$//;   #trim trailing whitespace
      $iitemid = substr($oneline,50,32);
      $iitemid =~ s/\s+$//;   #trim trailing whitespace
      $icalid  = substr($oneline,83,32);
      $icalid  =~ s/\s+$//;   #trim trailing whitespace
      new_toveritem($iid,$ilstdate,$iitemid,$icalid);
   }

   open(KEIBL, "< $opt_txt_teiblogt") || die("Could not open TEIBLOGT $opt_txt_teiblogt\n");
   @keibl_data = <KEIBL>;
   close(KEIBL);
   # Get data for all TEIBLOGT records
   $ll = 0;
   foreach $oneline (@keibl_data) {
      $ll += 1;
      next if $ll < 5;
      chop $oneline;
      $oneline .= " " x 400;
      $igbltmstmp = substr($oneline,0,16);
      $igbltmstmp =~ s/\s+$//;   #trim trailing whitespace
      $iobjname = substr($oneline,17,160);
      $iobjname =~ s/\s+$//;   #trim trailing whitespace
      $ioperation = substr($oneline,178,1);
      $ioperation =~ s/\s+$//;   #trim trailing whitespace
      $itable = substr($oneline,188,4);
      $itable =~ s/\s+$//;   #trim trailing whitespace
      next if $ioperation ne "I";
      next if $itable ne "5529";
      new_teiblogt($igbltmstmp,$iobjname,$ioperation,$itable);
   }

   open(KSTSH, "< $opt_txt_tsitstsh") || die("Could not open TSITSTSH $opt_txt_tsitstsh\n");
   @kstsh_data = <KSTSH>;
   close(KSTSH);
   # Get data for all TSITSTSH records
   $ll = 0;
   foreach $oneline (@kstsh_data) {
      $ll += 1;
      next if $ll < 5;
#print STDERR "working on line $ll\n";
      chop $oneline;
      $oneline .= " " x 400;
      $igbltmstmp = substr($oneline,0,16);
      $igbltmstmp =~ s/\s+$//;   #trim trailing whitespace
      next if substr($igbltmstmp,0,1) ne "1";
      $ideltastat = substr($oneline,17,1);
      $ideltastat =~ s/\s+$//;   #trim trailing whitespace
      $isitname = substr($oneline,19,32);
      $isitname =~ s/\s+$//;   #trim trailing whitespace
      $inode = substr($oneline,52,32);
      $inode =~ s/\s+$//;   #trim trailing whitespace
      $ioriginnode = substr($oneline,85,32);
      $ioriginnode =~ s/\s+$//;   #trim trailing whitespace
      $iatomize = substr($oneline,118,128);
      $iatomize =~ s/\s+$//;   #trim trailing whitespace
      new_tsitstsh($igbltmstmp,$ideltastat,$isitname,$inode,$ioriginnode,$iatomize);
   }

   open(KCKPT, "< $opt_txt_tcheckpt") || die("Could not open TCKPT $opt_txt_tcheckpt\n");
   @kckpt_data = <KCKPT>;
   close(KCKPT);
   # Get data for all TCKPT records
   $ll = 0;
   foreach $oneline (@kckpt_data) {
      $ll += 1;
      next if $ll < 4;
      chop $oneline;
      $oneline .= " " x 400;
      $iname = substr($oneline,0,32);
      $ireserved = substr($oneline,33,48);
      $iname =~ s/\s+$//;   #trim trailing whitespace
      $ireserved =~ s/\s+$//;   #trim trailing whitespace
      next if $iname ne "M:STAGEII";
      $opt_fto = $ireserved;
   }

}

# There may be a better way to do this, but this was clear and worked.
# The input $lcount must be matched up to the number of columns
# SELECTED in the SQL.
# [1]  OGRP_59B815CE8A3F4403  OGRP_6F783DF5FF904988  2010  2010

# Parse for KfwSQLClient SQL capture version 0.95000

sub parse_lst {
  my ($lcount,$inline,$cref) = @_;            # count of desired chunks and the input line
  my @retlist = ();                     # an array of strings to return
  my $chunk = "";                       # One chunk
  my $oct = 1;                          # output chunk count
  my $rest;                             # the rest of the line to process
  $inline =~ /\]\s*(.*)/;               # skip by [NNN]  field
  $rest = " " . $1 . "        ";
  my $fixed;
  my $lenrest = length($rest);          # length of $rest string
  my $restpos = 0;                      # postion studied in the $rest string
  my $nextpos = 0;                      # floating next position in $rest string

  # KwfSQLClient logic wraps each column with a leading and trailing blank
  # simple case:  <blank>data<blank><blank>data1<blank>
  # data with embedded blank: <blank>data<blank>data<blank><data1>data1<blank>
  #     every separator is always at least two blanks, so a single blank is always embedded
  # data with trailing blank: <blank>data<blank><blank><blank>data1<blank>
  #     given the rules has to be leading or trailing blank and chose trailing on data
  # data followed by a null data item: <blank>data<blank><blank><blank><blank>
  #                                                            ||
  # data with longer then two blanks embedded must be placed on end, or handled with a cref hash.
  #
  # $restpos always points within the string, always on the blank delimiter at the end
  #
  # The %cref hash specifies chunks that are of guaranteed fixed size... passed in by caller
  while ($restpos < $lenrest) {
     $fixed = $cref->{$oct};                   #
     if (defined $fixed) {
        $chunk = substr($rest,$restpos+1,$fixed);
        push @retlist, $chunk;                 # record null data chunk
        $restpos += 2 + $fixed;
        $chunk = "";
        $oct += 1;
        next;
     }
     if ($oct >= $lcount) {                                   # handle last item
        $chunk = substr($rest,$restpos+1);
        $chunk =~ s/\s+$//;                    # strip trailing blanks
        push @retlist, $chunk;                 # record last data chunk
        last;
     }
     if ((substr($rest,$restpos,3) eq "   ") and (substr($rest,$restpos+3,1) ne " ")) {          # following null entry
        $chunk = "";
        $oct += 1;
        push @retlist, $chunk;                 # record null data chunk
        $restpos += 2;
        next;
     }
     if ((substr($rest,$restpos,2) eq "  ") and (substr($rest,$restpos+2,1) ne " ")) {            # trailing blank on previous chunk so ignore
        $restpos += 1;
        next;
     }

     $nextpos = index($rest," ",$restpos+1);
     if (substr($rest,$nextpos,2) eq "  ") {
        $chunk .= substr($rest,$restpos+1,$nextpos-$restpos-1);
        push @retlist, $chunk;                 # record new chunk
        $chunk = "";                           # prepare for new chunk
        $oct += 1;
        $restpos = $nextpos + 1;
     } else {
        $chunk .= substr($rest,$restpos+1,$nextpos-$restpos); # record new chunk fragment
        $restpos = $nextpos;
     }
  }
  return @retlist;
}

sub init_lst {
   my @klst_data;
   my $inode;
   my $inodelist;
   my $inodetype;

   my @ksav_data;
   my $iproduct;
   my $iversion;
   my $ihostaddr;
   my $ihostinfo;
   my $io4online;
   my $ireserved;
   my $ithrunode;
   my $iaffinities;

   my @ksit_data;
   my $isitname;
   my $iautostart;
   my $ireev_days;
   my $ireev_time;
   my $isitinfo;
   my $ipdt;

   my @knam_data;
   my $iid;
   my $ifullname;

   my @kobj_data;
   my $iobjclass;
   my $iobjname;
   my $inodel;

   my @kgrp_data;
   my $igrpclass;
   my $igrpname;

   my @kgrpi_data;

   my @kevsr_data;
   my $ilstdate;
   my $ilstusrprf;

   my @kcct_data;
   my $ikey;
   my $iname;

   my @kevmp_data;
   my $imap;

   my @kpcyf_data;
   my $ipcyname;

   my @kactp_data;
   my $itypestr;
   my $iactname;
   my $iactinfo;

   my @kcale_data;

   my @kovrd_data;

   my @kovri_data;
   my $iitemid;
   my $icalid;

   my @keibl_data;
   my $igbltmstmp;
   my $ioperation;
   my $itable;

   my @kstsh_data;
   my $ideltastat;
   my $ioriginnode;
   my $iatomize;

   my @kckpt_data;

   # Parsing the KfwSQLClient output has some challenges. For example
   #      [1]  OGRP_59B815CE8A3F4403  2010  Test Group 1
   # Using the blank delimiter is OK for columns that are never blank or have no embedded blanks.
   # In this case the GRPNAME column is "Test Group 1". To manage this the SQL is arranged so
   # that a column with embedded blanks always placed at the end. The one table TSITDESC which has
   # two such columns can be retrieved with two separate SQLs.
   #

   open(KSAV, "< $opt_lst_tnodesav") || die("Could not open TNODESAV $opt_lst_tnodesav\n");
   @ksav_data = <KSAV>;
   close(KSAV);

   # Get data for all TNODESAV records
   $ll = 0;
   foreach $oneline (@ksav_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT NODE,O4ONLINE,PRODUCT,VERSION,HOSTADDR,RESERVED,THRUNODE,HOSTINFO,AFFINITIES FROM O4SRV.TNODESAV" >QA1DNSAV.DB.LST
      #[1]  BNSF:TOIFVCTR2PW:VM  Y  VM  06.22.01  ip.spipe:#10.121.54.28[11853]<NM>TOIFVCTR2PW</NM>  A=00:WIX64;C=06.22.09.00:WIX64;G=06.22.09.00:WINNT;  REMOTE_catrste050bnsxa  000100000000000000000000000000000G0003yw0a7
      ($inode,$io4online,$iproduct,$iversion,$ihostaddr,$ireserved,$ithrunode,$ihostinfo,$iaffinities) = parse_lst(9,$oneline);

      $inode =~ s/\s+$//;   #trim trailing whitespace
      $iproduct =~ s/\s+$//;   #trim trailing whitespace
      $iversion =~ s/\s+$//;   #trim trailing whitespace
      $io4online =~ s/\s+$//;   #trim trailing whitespace
      $ihostaddr =~ s/\s+$//;   #trim trailing whitespace
      $ireserved =~ s/\s+$//;   #trim trailing whitespace
      $ithrunode =~ s/\s+$//;   #trim trailing whitespace
      $ihostinfo =~ s/\s+$//;   #trim trailing whitespace
      $iaffinities =~ s/\s+$//;   #trim trailing whitespace
      $nsave_offline += ($io4online eq "N");
      $nsave_online += ($io4online eq "Y");
      new_tnodesav($inode,$iproduct,$iversion,$io4online,$ihostaddr,$ireserved,$ithrunode,$ihostinfo,$iaffinities);
   }

   open(KLST, "<$opt_lst_tnodelst") || die("Could not open TNODELST $opt_lst_tnodelst\n");
   @klst_data = <KLST>;
   close(KLST);

   # Get data for all TNODELST type V records
   $ll = 0;
   foreach $oneline (@klst_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT NODE,NODETYPE,NODELIST,LSTDATE FROM O4SRV.TNODELST" >QA1CNODL.DB.LST
      ($inode,$inodetype,$inodelist,$ilstdate) = parse_lst(4,$oneline);
      next if $inodetype ne "V";
      new_tnodelstv($inodetype,$inodelist,$inode,$ilstdate);
   }
   fill_tnodelstv();

   # Get data for all TNODELST type M records
   $ll = 0;
   foreach $oneline (@klst_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT NODE,NODETYPE,NODELIST,LSTDATE FROM O4SRV.TNODELST" >QA1CNODL.DB.LST
      ($inode,$inodetype,$inodelist,$ilstdate) = parse_lst(4,$oneline);
      $inodelist =~ s/\s+$//;   #trim trailing whitespace
      $inode =~ s/\s+$//;   #trim trailing whitespace
      if (($inodetype eq "") and ($inodelist eq "*HUB")) {    # *HUB has blank NODETYPE. Set to M for this calculation
         $inodetype = "M";
         $tx = $temsx{$inode};
         if (defined $tx) {
            $tems_hub[$tx] = 1;
            $hub_tems = $inode;
            $hub_tems_version = $tems_version[$tx];
         } else {
            $hub_tems_no_tnodesav = 1;
            $hub_tems = $inode;
            $hub_tems_version = "";
         }
      }
      next if $inodetype ne "M";
      new_tnodelstm($inodetype,$inodelist,$inode,$ilstdate);
   }
   open(KSIT, "< $opt_lst_tsitdesc") || die("Could not open TSITDESC $opt_lst_tsitdesc\n");
   @ksit_data = <KSIT>;
   close(KSIT);

   # Get data for all TSITDESC records
   $ll = 0;
   foreach $oneline (@ksit_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT SITNAME,AUTOSTART,LSTDATE,REEV_DAYS,REEV_TIME,SITINFO,PDT FROM O4SRV.TSITDESC" >QA1CSITF.DB.LST
      ($isitname,$iautostart,$ilstdate,$ireev_days,$ireev_time,$isitinfo,$ipdt) = parse_lst(7,$oneline);
      $isitname =~ s/\s+$//;   #trim trailing whitespace
      $iautostart =~ s/\s+$//;   #trim trailing whitespace
      $isitinfo =~ s/\s+$//;   #trim trailing whitespace
      $ipdt = substr($oneline,33,1);  #???#
      new_tsitdesc($isitname,$iautostart,$ilstdate,$ireev_days,$ireev_time,$isitinfo,$ipdt);
   }

   open(KNAM, "< $opt_lst_tname") || die("Could not open TNAME $opt_lst_tname\n");
   @knam_data = <KNAM>;
   close(KNAM);

   # Get data for all TNAME
   $ll = 0;
   foreach $oneline (@knam_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT ID,LSTDATE,FULLNAME FROM O4SRV.TNAME" >QA1DNAME.DB.LST
      ($iid,$ilstdate,$ifullname) = parse_lst(3,$oneline);
      new_tname($iid,$ilstdate,$ifullname);
   }

   open(KOBJ, "< $opt_lst_tobjaccl") || die("Could not open TOBJACCL $opt_lst_tobjaccl\n");
   @kobj_data = <KOBJ>;
   close(KOBJ);

   # Get data for all TOBJACCL records
   $ll = 0;
   foreach $oneline (@kobj_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT OBJCLASS,OBJNAME,NODEL,LSTDATE FROM O4SRV.TOBJACCL" >QA1DOBJA.DB.LST
      ($iobjclass,$iobjname,$inodel,$ilstdate) = parse_lst(4,$oneline);
      next if ($iobjclass != 5140) and ($iobjclass != 2010);
      new_tobjaccl($iobjclass,$iobjname,$inodel,$ilstdate);
   }

   open(KGRP, "< $opt_lst_tgroup") || die("Could not open TGROUP $opt_lst_tgroup\n");
   @kgrp_data = <KGRP>;
   close(KGRP);

   # Get data for all TGROUP records
   $ll = 0;
   foreach $oneline (@kgrp_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT GRPCLASS,ID,LSTDATE,GRPNAME FROM O4SRV.TGROUP" >QA1DGRPA.DB.LST
      ($igrpclass,$iid,$ilstdate,$igrpname) = parse_lst(4,$oneline);
      new_tgroup($igrpclass,$iid,$ilstdate,$igrpname);
   }

   open(KGRPI, "< $opt_lst_tgroupi") || die("Could not open TGROUPI $opt_lst_tgroupi\n");
   @kgrpi_data = <KGRPI>;
   close(KGRPI);

   # Get data for all TGROUPI records
   $ll = 0;
   foreach $oneline (@kgrpi_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT GRPCLASS,ID,LSTDATE,OBJCLASS,OBJNAME FROM O4SRV.TGROUPI" >QA1DGRPI.DB.LST
      ($igrpclass,$iid,$ilstdate,$iobjclass,$iobjname) = parse_lst(5,$oneline);
      new_tgroupi($igrpclass,$iid,$ilstdate,$iobjclass,$iobjname);
   }

   open(KEVSR, "< $opt_lst_evntserver") || die("Could not open EVNTSERVER $opt_lst_evntserver\n");
   @kevsr_data = <KEVSR>;
   close(KEVSR);

   # Get data for all EVNTSERVER records
   $ll = 0;
   foreach $oneline (@kevsr_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT ID,LSTDATE,LSTUSRPRF FROM O4SRV.EVNTSERVER" >QA1DEVSR.DB.LST
      ($iid,$ilstdate,$ilstusrprf) = parse_lst(3,$oneline);
      new_evntserver($iid,$ilstdate,$ilstusrprf);
   }

#   open(KDSCA, "< $opt_lst_package") || die("Could not open PACKAGE $opt_lst_package\n");
#   @kdsca_data = <KDSCA>;
#   close(KDSCA);

   # Count entries in PACKAGE file
   # for LST type files set $tems_packages set to zero since otherwise unknown
   # leave logic in case it can be performed later

   $tems_packages = 0;

#  open(KDSCA, "< $opt_lst_package") || die("Could not open PACKAGE $opt_lst_package\n");
#  @kdsca_data = <KDSCA>;
#  close(KDSCA);
#
#  # Count entries in PACKAGE file
#  $ll = 0;
#  foreach $oneline (@kdsca_data) {
#     $ll += 1;
#     next if substr($oneline,0,10) eq "KCIIN0187I";      # A Linux/Unix first line
#     $tems_packages += 1;
#  }

   open(KCCT, "< $opt_lst_cct") || die("Could not open CCT $opt_lst_cct\n");
   @kcct_data = <KCCT>;
   close(KCCT);

   $ll = 0;
   foreach $oneline (@kcct_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT KEY,LSTDATE,NAME FROM O4SRV.CCT" >QA1DCCT.DB.LST
      ($ikey,$ilstdate,$iname) = parse_lst(3,$oneline);
      new_cct($ikey,$ilstdate,$iname);
   }

   open(KEVMP, "< $opt_lst_evntmap") || die("Could not open EVNTMAP $opt_lst_evntmap\n");
   @kevmp_data = <KEVMP>;
   close(KEVMP);

   # Get data for all EVNTMAP records
   $ll = 0;
   foreach $oneline (@kevmp_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      # KfwSQLClient /e "SELECT ID,LSTDATE,MAP FROM O4SRV.EVNTMAP" >QA1DEVMP.DB.LST
      ($iid,$ilstdate,$imap) = parse_lst(3,$oneline);
      new_evntmap($iid,$ilstdate,$imap);
   }

   open(KPCYF, "< $opt_lst_tpcydesc") || die("Could not open TPCYDESC $opt_lst_tpcydesc\n");
   @kpcyf_data = <KPCYF>;
   close(KPCYF);

   # Get data for all TPCYDESC records
   $ll = 0;
   foreach $oneline (@kpcyf_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      # KfwSQLClient /e "SELECT PCYNAME,LSTDATE FROM O4SRV.TPCYDESC" >QA1DPCYF.DB.LST
      ($ipcyname,$ilstdate,$iautostart) = parse_lst(3,$oneline);
      new_tpcydesc($ipcyname,$ilstdate,$iautostart);
   }

   open(KACTP, "< $opt_lst_tactypcy") || die("Could not open TACTYPCY $opt_lst_tactypcy\n");
   @kactp_data = <KACTP>;
   close(KACTP);

   # Get data for all TACTYPCY records
   $ll = 0;
   foreach $oneline (@kactp_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      # KfwSQLClient /e "SELECT ACTNAME,PCYNAME,LSTDATE,TYPESTR,ACTINFO FROM O4SRV.TACTYPCY" >QA1DACTP.DB.LST
      ($iactname,$ipcyname,$ilstdate,$itypestr,$iactinfo) = parse_lst(5,$oneline);
      new_tactypcy($iactname,$ipcyname,$ilstdate,$itypestr,$iactinfo);
   }

   open(KCALE, "< $opt_lst_tcalendar") || die("Could not open TCALENDAR $opt_lst_tcalendar\n");
   @kcale_data = <KCALE>;
   close(KCALE);
   # Get data for all TCALENDAR records
   $ll = 0;
   foreach $oneline (@kcale_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      # KfwSQLClient /e "SELECT ID,LSTDATE,NAME FROM O4SRV.TCALENDAR" >QA1DCALE.DB.LST
      ($iid,$ilstdate,$iname) = parse_lst(3,$oneline);
      new_tcalendar($iid,$ilstdate,$iname);
   }

   open(KOVRD, "< $opt_lst_toverride") || die("Could not open TOVERRIDE $opt_lst_toverride\n");
   @kovrd_data = <KOVRD>;
   close(KOVRD);
   # Get data for all TOVERRIDE records
   $ll = 0;
   foreach $oneline (@kovrd_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      # KfwSQLClient /e "SELECT ID,LSTDATE,SITNAME FROM O4SRV.TOVERRIDE" >QA1DOVRD.DB.LST
      ($iid,$ilstdate,$isitname) = parse_lst(3,$oneline);
      new_toverride($iid,$ilstdate,$isitname);
   }

   open(KOVRI, "< $opt_lst_toveritem") || die("Could not open TOVERITEM $opt_lst_toveritem\n");
   @kovri_data = <KOVRI>;
   close(KOVRI);
   # Get data for all TOVERITEM records
   $ll = 0;
   foreach $oneline (@kovri_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      # KfwSQLClient /e "SELECT ID,LSTDATE,ITEMID,CALID FROM O4SRV.TOVERITEM" >QA1DOVRI.DB.LST
      ($iid,$ilstdate,$iitemid,$icalid) = parse_lst(4,$oneline);
      new_toveritem($iid,$ilstdate,$iitemid,$icalid);
   }

   open(KEIBL, "< $opt_lst_teiblogt") || die("Could not open TEIBLOGT $opt_lst_teiblogt\n");
   @keibl_data = <KEIBL>;
   close(KEIBL);
   # Get data for all TEIBLOGT records
   $ll = 0;
   foreach $oneline (@keibl_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      ($igbltmstmp,$iobjname,$ioperation,$itable) = parse_lst(4,$oneline);
      next if $ioperation ne "I";
      next if $itable != 5529;
      new_teiblogt($igbltmstmp,$iobjname,$ioperation,$itable);
   }

   open(KSTSH, "< $opt_lst_tsitstsh") || die("Could not open TSITSTSH $opt_lst_tsitstsh\n");
   @kstsh_data = <KSTSH>;
   close(KSTSH);
   # Get data for all TSITSTSH records
   $ll = 0;
   foreach $oneline (@kstsh_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      ($igbltmstmp,$ideltastat,$isitname,$inode,$ioriginnode,$iatomize) = parse_lst(6,$oneline);
      new_tsitstsh($igbltmstmp,$ideltastat,$isitname,$inode,$ioriginnode,$iatomize);
   }

   open(KCKPT, "< $opt_lst_tcheckpt") || die("Could not open TCHECKPT $opt_lst_tcheckpt\n");
   @kckpt_data = <KCKPT>;
   close(KCKPT);
   # Get data for all TCKPT records
   $ll = 0;
   foreach $oneline (@kckpt_data) {
      $ll += 1;
      next if substr($oneline,0,1) ne "[";                    # Look for starting point
      chop $oneline;
      $oneline .= " " x 400;
      ($iname,$ireserved) = parse_lst(2,$oneline);
      $iname =~ s/\s+$//;   #trim trailing whitespace
      $ireserved =~ s/\s+$//;   #trim trailing whitespace
      next if $iname ne "M:STAGEII";
      $opt_fto = $ireserved;
   }


}


# Get options from command line - first priority
sub init {
   while (@ARGV) {
      if ($ARGV[0] eq "-log") {
         shift(@ARGV);
         $opt_log = shift(@ARGV);
         die "option -log with no following log specification\n" if !defined $opt_log;
      } elsif ( $ARGV[0] eq "-ini") {
         shift(@ARGV);
         $opt_ini = shift(@ARGV);
         die "option -ini with no following ini specification\n" if !defined $opt_ini;
      } elsif ( $ARGV[0] eq "-hub") {
         shift(@ARGV);
         $opt_hub = shift(@ARGV);
         die "option -hub with no following hub specification\n" if !defined $opt_hub;
      } elsif ( $ARGV[0] eq "-debuglevel") {
         shift(@ARGV);
         $opt_debuglevel = shift(@ARGV);
         die "option -debuglevel with no following debuglevel specification\n" if !defined $opt_debuglevel;
      } elsif ( $ARGV[0] eq "-debug") {
         shift(@ARGV);
         $opt_debug = 1;
      } elsif ( $ARGV[0] eq "-h") {
         shift(@ARGV);
         $opt_h = 1;
      } elsif ( $ARGV[0] eq "-o") {
         shift(@ARGV);
         $opt_o = shift(@ARGV);
         die "option -o with no following output file specification\n" if !defined $opt_o;
      } elsif ( $ARGV[0] eq "-s") {
         shift(@ARGV);
         $opt_s = shift(@ARGV);
         die "option -s with no following output file specification\n" if !defined $opt_s;
      } elsif ( $ARGV[0] eq "-workpath") {
         shift(@ARGV);
         $opt_workpath = shift(@ARGV);
         die "option -workpath with no following debuglevel specification\n" if !defined $opt_workpath;
      } elsif ( $ARGV[0] eq "-nohdr") {
         shift(@ARGV);
         $opt_nohdr = 1;
      } elsif ( $ARGV[0] eq "-event") {
         shift(@ARGV);
         $opt_event = 1;
      } elsif ( $ARGV[0] eq "-asysname") {
         shift(@ARGV);
         $opt_asysname = 1;
      } elsif ( $ARGV[0] eq "-txt") {
         shift(@ARGV);
         $opt_txt = 1;
      } elsif ( $ARGV[0] eq "-lst") {
         shift(@ARGV);
         $opt_lst = 1;
      } elsif ( $ARGV[0] eq "-s") {
         shift(@ARGV);
         $opt_s = shift(@ARGV);
         die "option -s with no following debuglevel specification\n" if !defined $opt_s;
      } elsif ( $ARGV[0] eq "-subpc") {
         shift(@ARGV);
         $opt_subpc_warn = shift(@ARGV);
         die "option -subpc with no following per cent specification\n" if !defined $opt_subpc_warn;
      } elsif ( $ARGV[0] eq "-vndx") {
         shift(@ARGV);
         $opt_vndx = 1;
      } elsif ( $ARGV[0] eq "-mndx") {
         shift(@ARGV);
         $opt_mndx = 1;
      } elsif ( $ARGV[0] eq "-miss") {
         shift(@ARGV);
         $opt_miss = 1;
      } elsif ( $ARGV[0] eq "-delu") {
         shift(@ARGV);
         $opt_delu = 1;
      } elsif ( $ARGV[0] eq "-nodist") {
         shift(@ARGV);
         $opt_nodist = shift(@ARGV);
         die "option -nodist with no following name specification\n" if !defined $opt_nodist;
      } elsif ( $ARGV[0] eq "-crit") {
         shift(@ARGV);
         $opt_crit = shift(@ARGV);
         $opt_crit = "" if !defined $opt_crit;
      } else {
         print STDERR "SITAUDIT001E Unrecognized command line option - $ARGV[0]\n";
         exit 1;
      }
   }

   # Following are command line only defaults. All others can be set from the ini file

   if (!defined $opt_ini) {$opt_ini = "datahealth.ini";}         # default control file if not specified
   if ($opt_h) {&GiveHelp;}  # GiveHelp and exit program
   if (!defined $opt_debuglevel) {$opt_debuglevel=90;}         # debug logging level - low number means fewer messages
   if (!defined $opt_debug) {$opt_debug=0;}                    # debug - turn on rare error cases
   if (!defined $opt_nodist) {$opt_nodist="";}                 # don't skip objects
   if (!defined $opt_delu) {$opt_delu = 0;}                    # don't skip objects

   if ($opt_crit ne "") {
      if ($gWin == 1) {
         $opt_crit .= "\\" if substr($opt_crit,-1,1) ne "\\";
      } else {
         $opt_crit .= "\/" if substr($opt_crit,-1,1) ne "\/";
      }
   }

   # ini control file must be present

   if (-e $opt_ini) {                                      # make sure ini file is present

      open( FILE, "< $opt_ini" ) or die "Cannot open ini file $opt_ini : $!";
      my @ips = <FILE>;
      close FILE;

      # typical ini file scraping. Could be improved by validating parameters

      my $l = 0;
      foreach my $oneline (@ips)
      {
         $l++;
         chop $oneline;
         next if (substr($oneline,0,1) eq "#");  # skip comment line
         @words = split(" ",$oneline);
         next if $#words == -1;                  # skip blank line
          if ($#words == 0) {                         # single word parameters
            if ($words[0] eq "verbose") {$opt_v = 1;}
            if ($words[0] eq "event") {$opt_event = 1;}
            elsif ($words[0] eq "traffic") {$opt_vt = 1;}
            else {
               print STDERR "SITAUDIT003E Control without needed parameters $words[0] - $opt_ini [$l]\n";
               $run_status++;
            }
            next;
         }

         if ($#words == 1) {
            # two word controls - option and value
            if ($words[0] eq "log") {$opt_log = $words[1];}
            elsif ($words[0] eq "log") {$opt_log = $words[1];}
            elsif ($words[0] eq "o") {$opt_o = $words[1];}
            elsif ($words[0] eq "s") {$opt_s = $words[1];}
            elsif ($words[0] eq "workpath") {$opt_workpath = $words[1];}
            elsif ($words[0] eq "subpc") {$opt_subpc_warn = $words[1];}
            elsif ($words[0] eq "peak_rate") {$opt_peak_rate = $words[1];}
            elsif ($words[0] eq "hub") {$opt_hub = $words[1];}
            else {
               print STDERR "SITAUDIT005E ini file $l - unknown control $oneline\n"; # kill process after current phase
               $run_status++;
            }
            next;
         }
         print STDERR "SITAUDIT005E ini file $l - unknown control $oneline\n"; # kill process after current phase
         $run_status++;
      }
   }

   # defaults for options not set otherwise

   if (!defined $opt_log) {$opt_log = "datahealth.log";}       # default log file if not specified
   if (!defined $opt_h) {$opt_h=0;}                            # help flag
   if (!defined $opt_v) {$opt_v=0;}                            # verbose flag
   if (!defined $opt_vt) {$opt_vt=0;}                          # verbose traffic default off
   if (!defined $opt_dpr) {$opt_dpr=0;}                        # data dump flag
   if (!defined $opt_o) {$opt_o="datahealth.csv";}             # default report file
   if (!defined $opt_s) {$opt_s="datahealth.txt";}             # default summary line
   if (!defined $opt_workpath) {$opt_workpath="";}             # default is current directory
   if (!defined $opt_txt) {$opt_txt = 0;}                      # default no txt input
   if (!defined $opt_lst) {$opt_lst = 0;}                      # default no lst input
   if (!defined $opt_subpc_warn) {$opt_subpc_warn=90;}         # default warn on 90% of maximum subnode list
   if (!defined $opt_peak_rate) {$opt_peak_rate=64;}           # default warn on 64 virtual hub table updates per second
   if (!defined $opt_vndx) {$opt_vndx=0;}                      # default vndx off
   if (!defined $opt_mndx) {$opt_mndx=0;}                      # default mndx off
   if (!defined $opt_miss) {$opt_miss=0;}                      # default mndx off
   if (!defined $opt_event) {$opt_event=0;}                    # default event report off
   if (!defined $opt_asysname) {$opt_asysname=0;}                # default sysname report off
   if (!defined $opt_hub)  {$opt_hub = "";}                    # external hub nodeid not supplied

   $opt_workpath =~ s/\\/\//g;                                 # convert to standard perl forward slashes
   if ($opt_workpath ne "") {
      $opt_workpath .= "\/" if substr($opt_workpath,length($opt_workpath)-1,1) ne "\/";
   }
   if (defined $opt_txt) {
      $opt_txt_tnodelst = $opt_workpath . "QA1CNODL.DB.TXT";
      $opt_txt_tnodesav = $opt_workpath . "QA1DNSAV.DB.TXT";
      $opt_txt_tsitdesc = $opt_workpath . "QA1CSITF.DB.TXT";
      $opt_txt_tname    = $opt_workpath . "QA1DNAME.DB.TXT";
      $opt_txt_tobjaccl = $opt_workpath . "QA1DOBJA.DB.TXT";
      $opt_txt_tgroup   = $opt_workpath . "QA1DGRPA.DB.TXT";
      $opt_txt_tgroupi  = $opt_workpath . "QA1DGRPI.DB.TXT";
      $opt_txt_evntserver = $opt_workpath . "QA1DEVSR.DB.TXT";
      $opt_txt_package = $opt_workpath . "QA1CDSCA.DB.TXT";
      $opt_txt_cct     = $opt_workpath . "QA1DCCT.DB.TXT";
      $opt_txt_evntmap = $opt_workpath . "QA1DEVMP.DB.TXT";
      $opt_txt_tpcydesc = $opt_workpath . "QA1DPCYF.DB.TXT";
      $opt_txt_tactypcy = $opt_workpath . "QA1DACTP.DB.TXT";
      $opt_txt_tcalendar = $opt_workpath . "QA1DCALE.DB.TXT";
      $opt_txt_toverride = $opt_workpath . "QA1DOVRD.DB.TXT";
      $opt_txt_toveritem = $opt_workpath . "QA1DOVRI.DB.TXT";
      $opt_txt_teiblogt = $opt_workpath . "QA1CEIBL.DB.TXT";
      $opt_txt_tsitstsh = $opt_workpath . "QA1CSTSH.DB.TXT";
      $opt_txt_tcheckpt = $opt_workpath . "QA1CCKPT.DB.TXT";
   }
   if (defined $opt_lst) {
      $opt_lst_tnodesav  = $opt_workpath . "QA1DNSAV.DB.LST";
      $opt_lst_tnodelst  = $opt_workpath . "QA1CNODL.DB.LST";
      $opt_lst_tsitdesc  = $opt_workpath . "QA1CSITF.DB.LST";
      $opt_lst_tname     = $opt_workpath . "QA1DNAME.DB.LST";
      $opt_lst_tobjaccl  = $opt_workpath . "QA1DOBJA.DB.LST";
      $opt_lst_tgroup   = $opt_workpath . "QA1DGRPA.DB.LST";
      $opt_lst_tgroupi  = $opt_workpath . "QA1DGRPI.DB.LST";
      $opt_lst_evntserver = $opt_workpath . "QA1DEVSR.DB.LST";
      $opt_lst_cct = $opt_workpath . "QA1DCCT.DB.LST";
      $opt_lst_evntmap = $opt_workpath . "QA1DEVMP.DB.LST";
      $opt_lst_tpcydesc = $opt_workpath . "QA1DPCYF.DB.LST";
      $opt_lst_tactypcy = $opt_workpath . "QA1DACTP.DB.LST";
      $opt_lst_tcalendar = $opt_workpath . "QA1DCALE.DB.LST";
      $opt_lst_toverride = $opt_workpath . "QA1DOVRD.DB.LST";
      $opt_lst_toveritem = $opt_workpath . "QA1DOVRI.DB.LST";
      $opt_lst_teiblogt = $opt_workpath . "QA1CEIBL.DB.LST";
      $opt_lst_tsitstsh = $opt_workpath . "QA1CSTSH.DB.LST";
      $opt_lst_tcheckpt = $opt_workpath . "QA1CCKPT.DB.LST";
   }
   $opt_vndx_fn = $opt_workpath . "QA1DNSAV.DB.VNDX";
   $opt_mndx_fn = $opt_workpath . "QA1DNSAV.DB.MNDX";
   $opt_miss_fn = $opt_workpath . "MISSING.SQL";
   $opt_delu_cmd = $opt_workpath . "DELETESIT.CMD";
   $opt_delu_sh  = $opt_workpath . "DELETESIT.sh";
   $opt_delu_csv  = $opt_workpath . "DELETE.CSV";
   $opt_asysname_csv  = $opt_workpath . "SYSNAME.CSV";

my ($isec,$imin,$ihour,$imday,$imon,$iyear,$iwday,$iyday,$iisdst) = localtime(time()+86400);
   $tlstdate = "1";
   $tlstdate .= substr($iyear,-2,2);
   $imon += 1;
   $imon = "00" . $imon;
   $tlstdate .= substr($imon,-2,2);
   $imon = "00" . $imday;
   $tlstdate .= substr($imday,-2,2);
   $ihour = "00" . $ihour;
   $tlstdate .= substr($ihour,-2,2);
   $imin = "00" . $imin;
   $tlstdate .= substr($imin,-2,2);
   $isec = "00" . $isec;
   $tlstdate .= substr($isec,-2,2);
   $tlstdate .= "000";

   if ($opt_dpr == 1) {
#     my $module = "Data::Dumper";
#     eval {load $module};
#     if ($@) {
#        print STDERR "Cannot load Data::Dumper - ignoring -dpr option\n";
#        $opt_dpr = 0;
#     }
      $opt_dpr = 0;
   }

   if (($opt_txt + $opt_lst) == 0) {
      $opt_txt = 1 if -e $opt_txt_tnodelst;
      $opt_lst = 1 if -e $opt_lst_tnodelst;
   }


   # complain about options which must be present
   if (($opt_txt + $opt_lst) != 1) {
      print STDERR "SITINFO006E exactly one of txt/lst must be present\n";
      $run_status++;
   }

   # if any errors, then dump log and exit
   # this way we can show multiple errors at startup
   if ($run_status) { exit 1;}

}



#------------------------------------------------------------------------------
sub GiveHelp
{
  $0 =~ s|(.*)/([^/]*)|$2|;
  print <<"EndOFHelp";

  $0 v$gVersion

  This script surveys an ITM environment looking for possibly unhealthy agents
  which are online not responsive.

  Default values:
    log           : sitaudit.log
    ini           : sitaudit.ini
    user          : <none>
    passwd        : <none>
    debuglevel    : 90 [considerable number of messages]
    debug         : 0  when 1 some breakpoints are enabled]
    h             : 0  display help information
    v             : 0  display log messages on console
    vt            : 0  record http traffic on traffic.txt file
    dpr           : 0  dump data structure if Dump::Data installed
    std           : 0  get user/password from stardard input

  Example invovation
    $0  -ini <control file> -pc ux

  Note: $0 uses an initialization file [default sitaudit.ini] for many controls.

EndOFHelp
exit;
}
sub get_epoch {
   use POSIX;
   my $itm_stamp = shift;
   my $unixtime = $epochx{$itm_stamp};
   if (!defined $unixtime) {
     ( my $iyy, my $imo, my $idd, my $ihh, my $imm, my $iss ) =  unpack( "A2 A2 A2 A2 A2 A2", substr( $itm_stamp, 1 ) );
      my $wday = 0;
      my $yday = 0;
      $iyy += 100;
      $unixtime = mktime ($iss, $imm, $ihh, $idd, $imo, $iyy, $wday, $yday);
   }
   return $unixtime;
}

#------------------------------------------------------------------------------
# capture log record
sub logit
{
   my $level = shift;
   if ($level <= $opt_debuglevel) {
      my $iline = shift;
      my $itime = gettime();
      chop($itime);
      $outline = $itime . " " . $level . " " . $iline;
      if ($opt_debuglevel >= 100) {
         my $ofile = (caller(0))[1];
         my $olino = (caller(0))[2];
         if (defined $ofile) {
            $outline = $ofile . ":" . $olino . " " . $outline;
         }
      }
      print FH "$outline\n";
      print "$outline\n" if $opt_v == 1;
   }
}

#------------------------------------------------------------------------------
# capture agent log record
#------------------------------------------------------------------------------
# capture agent error record

# write output log
sub datadumperlog
{
   require Data::Dumper;
   my $dd_msg = shift;
   my $dd_var = shift;
   print FH "$dd_msg\n";
   no strict;
   print FH Data::Dumper->Dumper($dd_var);
}

# return timestamp
sub gettime
{
   my $sec;
   my $min;
   my $hour;
   my $mday;
   my $mon;
   my $year;
   my $wday;
   my $yday;
   my $isdst;
   ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
   return sprintf "%4d-%02d-%02d %02d:%02d:%02d\n",$year+1900,$mon+1,$mday,$hour,$min,$sec;
}

# get current time in ITM standard timestamp form
# History log

# 0.60000  : New script based on ITM Situation Audit 1.14000
# 0.70000  : Advisory when duplicatee HOSTADDR columns
# 0.71000  : Adapt to regression test process
#          : low impact advisory on long node names
# 0.72000  : count size of subnode list and advise if TEMS < "06.23.02" and near 32K
# 0.73000  : Handle duplicate hostaddr with null thrunode better
# 0.75000  : Advisory on invalid nodes and nodelist names
# 0.80000  : Advisory on virtual hub table update agents
#          : Add summary line txt file for caller
#          : Support workpath better
# 0.81000  : Add advisory on TEMA 6.1 level
# 0.82000  : Alert when FTO and agents connect directly to hub TEMS
# 0.83000  : Identify valid agent endings
# 0.84000  : add more known agent MSLs
# 0.85000  : Add TSITDESC and TNAME checking
#          : Handle z/OS no extension agents
#          : Add TNODESAV product to the "might be truncated" messages
#          : make -lst option work
# 0.86000  : Check for TNODELST NODETYPE=V thrunode missing from TNODESAV
# 0.87000  : Add TOBJACCL, TGROUP. TGROUPI checking first stage
# 0.88000  : Identify TEMA version < Agent version, adjust impacts, add more missing tests, change some impacts
# 0.89000  : record TEMS version number
# 0.90000  : detect case where *HUB is missing from TNODELST NODETYPE=M records
# 0.91000  : Check EVNTSERVR for blank LSTDATE and LSTUSRPRF
# 0.92000  : Check Virtual Hub Table counts against TSITDESC UADVISOR AUTOSTART settings
# 0.93000  : Check for invalid TSITDESC.LSTDATE values
# 0.94000  : Check IZ76410 TEMA problem case
# 0.95000  : Refine check for lower level TEMAs
#          : Add summary for TEMA Deficit levels, auto-detect TXT and LST options
#          : Add hub version and fraction TEMA deficit to one line summary for PMR
# 0.96000  : Add check for number of packages close to failure point
# 0.97000  : Full review of TEMA APARs and levels after ITM 6.1 FP6 readme found
# 0.98000  : Reconcile -lst logic
#          : Change 1043E warning for cases where agent is release higher then TEMS
# 0.99000  : Fix deficit% in REFIC line
# 1.00000  : Parse LST files better
#          : Add 1049W/1050W/1051W/1052W to warn of node/nodelist names with embedded blanks
# 1.01000  : Monitor LSTDATE against future dates
#          : Add checking of the rest of the FTO synchronized tables
# 1.02000  : Long sampling interval
# 1.03000  : Correct parse_lst issues versus capture SQL TNAME and TPCYDESC issues
# 1.04000  : Fix Workflow Policy checks to warn on autostart *NO at lower impact, correct TSITDESC -lst capture
# 1.05000  : Improved parse_lst logic
# 1.06000  : Add check for APAR IV50167
# 1.07000  : Improve agent/tema version check - reduce false warnings
#          : Add TEMS architecture
# 1.08000  : Improve APAR deficit calculation, ignore A4 tema version 06.20.20
# 1.09000  : Dislay Days/APAR in deficit calculations
# 1.10000  : Handle divide by zero case when no agents backlevel
# 1.11000  : Add ITM 630 FP5 APARs for TEMA deficit report
# 1.12000  : Add top 10 changed situations
# 1.13000  : record mulitple TEIBLOGT inserts of same object, same day?
# 1.14000  : for multiple inserts, report on counts >= mode of frequency
#            Add report of TEPS version and architecture
# 1.15000  : Add report for i/5 agent levels
# 1.16000  : Add general i5os reports, not just OS Agent
# 1.17000  : Detect FTO hub TEMS at different maintenance levels
#          : Alert on some sampling date/time issues
# 1.18000  : parse_lst handle null chunks correctly
#          : better report on possible duplicate agents, screen TNODELST for just M records
# 1.20000  : Report on Situation Flippers and Fireflys
# 1.21000  : Add TEMA APARs from ITM 630 FP6
# 1.22000  : Reduce some advisory impact levels
#          : correct some titles and add some event related times
# 1.23000  : Handle CF/:CONFIG differently since managed system does not use a TEMA
# 1.24000  : Correct for different Windows KfwSQLClient output formats
# 1.25000  : Handle KfwSQLClient output better
# 1.26000  : Advisory on missing MQ hostname qualifier
# 1.27000  : Calculate rate of event arrivals
#          : parse_lst 0.95000
# 1.28000  : Advisory on duplicate SYSTEM NAMES
#          : Advisory when ::CONFIG agents not connected to hub TEMS.
# 1.29000  : Advisory when CF is on remotes or in FTO environment
#          : Advisory when WPA not configured to hub TEMS
# 1.30000  : Advisory when agent has invalid affinities
# 1.31000  : Add more information on rapidly occuring situation events
# 1.32000  : Add FP7 data
# 1.33000  : end End of Service alerts and report
# 1.34000  : Add advisory for ghost situations, event status history even though deleted situation
# 1.35000  : Eliminate doubled line
#          : advisory on IV18016 case
#          : add advisory explanations to report
#          : add advisories related to too many MS_Offline type situations
#          : Do not do advisory on Sampling Time "0"
#          : Restructure report sequence so advisory comes a just after TEMS summary
# 1.36000  : Report on situation derived dataserver workload
#          : Add advisory on KDEB_INTERFACELIST APAR level issue
#          : Add two advisoreies on too many situations clogging up TEMS startup
#          : Move Agent in APAR danger details to trailing reports
#          : Add advisory on multiple TEMA levels on one system
#          : Reduce impact of DATAHEALTH1023 to 0, more annoyance than actual issue
# 1.37000  : Better logic on multiple TEMA report
# 1.38000  : Add advisory for remote TEMS higher maint level than hub TEMS
# 1.39000  : Add Product Summary Report section
# 1.40000  : Add check for historical data but no WPAs
# 1.41000  : Add tighter check for TOBJACCL checking, 1099W, 1100W, 1101W and revised 1030W
# 1.42000  : Add 1102W for known situation unknown system generated MSL - not so important
#          : Add FTO status  HUB/MIRROR in FTO message
# 1.43000  : HOSTINFO to Agent summary
# 1.44000  : Advisory on MS_Offline with zero sampling interval
#          : Advisory if more than one T3 agent.
# 1.45000  : Correct logic advisory T3 agent
# 1.46000  : Advisory if managing agent is same as agent.
# 1.47000  : Handle datahealth.pl running on a Linux/Unix perl
#          : Correct 1075W logic, should ignore protocol
#          : Add report on mixed up hostnames from same system
# 1.48000  : Add advisory when Agent Operation Log data is collected.
#          : Don't check TEMS for hub-ness if TEMS is offline
# 1.49000  : Add Offline report summarized 5 ways
#          : Add Product Summary Report, Product Code Names when known
#          : Add deduplicate PDT situation report to TEMSNODE report
# 1.50000  : Add TEMS HOSTADDR to summary report
#          : Change DATAHEALTH1101E impact to 25
#          : Add DATAHEALTH1108W to HOSTADDR with <NM> tag
#          : Correct 1086-1089 in from and content
# 1.51000  : Add MS_Offline type report
# 1.52000  : Ignore leaked through remote TEMS databases
# 1.53000  : Add more product names
#          : Add hostaddr to several reports
# 1.54000  : Get some reports sorted for easier regression testing
# 1.55000  : Add some new agent types
#          : Add some table sizes
# 1.56000  : Add some new agent types
# 1.57000  : Add some new agent types
# 1.58000  : Add some new agent types
# 1.59000  : Advisory on agents connected directly to FTO hub TEMSes
#          : Add Report numbers and explanations
# 1.60000  : Position TEMS/TEPS summary report before advisories
#          : Add report020 for details of virtual hub Table impact per TEMS
# 1.61000  : Correct syntax error
# 1.62000  : Handle case of unknown hub TEMS
# 1.63000  : Accept crit directory and populate crit file
# 1.64000  : No crits when not a hub TEMS
# 1.65000  : Add type 1 critical issue for duplicate indexes
# 1.66000  : Correct logic for multiple TEMAs and Multiple hostname reports
#          : Update ITM 623 EOS date
# 1.67000  : Improved duplicate index critical issue report line
# 1.68000  : Improve explanation on ::CONFIG systems
# 1.69000  : Handle managed systems with 4 segments
# 1.70000  : Update some table sizes
#          : Update default VTBL test to 64/second
#          : correct 1109W logic - when no remote TEMSes are present
# 1.71000  : Put Sampload at start
#          : Add duplicate historical data collection report/advisory
#          : Add advisory on KBB_RAS1 trailing single quote
#          : clarify some Agent APAR danger report titles
# 1.72000  : Add number of MS_Offline situations to 4 advisories
#          : Add Service Pack Level for hub TEMS
# 1.73000  : Correct Service Pack Level logic
#          : Advisory on non-distributed situations
#          : Add -delu option to create report/cmd/sh files to delete un-distributed situations
# 1.74000  : Add advistory and report for correlated situations
#            Correct hostname from agentname logic when more than 3 colons
# 1.75000  : Add two more product codes
#            Add - asysname option to create sysname.csv report
#            Add data to report022. the MSLs in trouble
#            Correct logic on missing system generated MSL when > 1
# 1.76000  : Add advisory on hub/630F7 and remote/630FP6 w/ipsipe connections
#          : Add report and advisory on Pure situations with long TTLs
# Following is the embedded "DATA" file used to explain
# advisories the the report. It replaces text in that used
# to be in TEMS Audit Users Guide.docx
__END__
DATAHEALTH1001E
Text: Node present in node status but missing in TNODELST Type V records

Check: For every NODE in TNODESAV, there must be a TNODELST
NODETYPE=V with matching TNODELST column

Meaning: This is sometimes seen after a FTO synchronization
defect. There are likely other unknown causes. A missing
type V records identifies agents where no situations will
be started and real time data may not be available. This
is a severe condition and needs rapid resolution.

There are some cases with z/OS Agents where this condition
exists but is not a problem. That research continues.

Recovery plan: Open a PMR and work with IBM Support on how
to resolve this issue. Sometimes stopping the agent, doing
a Remove Offline Entry from the Managed System List and
restarting agent works�. However that process effectively
deletes all the user defined Managed System List data.
--------------------------------------------------------------

DATAHEALTH1002E
Text: Node without a system generated MSL in TNODELST Type M records

Check: For every NODE in TNODESAV, there must a TNODELST Type M
with matching NODE and with a NODELST starting with an asterisk.

Meaning: This is sometimes seen after a FTO synchronization defect.
There are likely other unknown causes. The MSLs starting with
asterisk are system generated MSLs. For example all Windows OS
Agents should be in *NT_SYSTEM. If there are agents missing, then
situations distributed to *NT_SYSTEM will not include the missing
agents and so some situations will not run as expected. We have
seen rare cases where a customer chose to delete those records and
in so the issue can be ignored in that case.

There are some cases with z/OS Agents where this condition exists
but is not a problem. That research continues.

Recovery plan: Open a PMR and work with IBM Support on how to resolve this issue.
--------------------------------------------------------------

DATAHEALTH1003I
Text: Node present in TNODELST Type M records but missing in Node Status

Check: For every NODE in TNODELST where NODETYPE=M; there should
be a matching TNODESAV NODE.

Meaning: This is a very low severity case where the MSLs have left
over agents which are not in service any more. The adverse impact
is that if a new agent is created with the same name as the out of
service agent unexpected situations may start running.

Recovery plan: In TEP Object Editor, edit the MSLs involved and delete
the unknown agents and perhaps delete no longer used MSLs. One site
had 100,000 TNODELST rows and 35% of them represented obsolete MSLs
that should have been deleted long ago.
--------------------------------------------------------------

DATAHEALTH1004I
Text: Node present in TNODELST Type M records, but missing TNODELST Type V records

Check: For every NODE in TNODELST NODETYPE=M, there should be a
matching TNODELST NODETYPE=V NODE agent.

Meaning: This case may be related to the previous advisory code DATAHEALTH1003I.
If so, after the "missing" agents are removed  from the MSL,
this will not be an advisory. It might also be a case of missing
NODETYPE=V records DATAHEALTH1001E. After the recovery plan for
that case above is performed this will no longer show.

Recovery plan: Open a PMR and work with IBM Support on how to resolve this issue.
--------------------------------------------------------------

DATAHEALTH1005W
Text: Hub TEMS has <count> managed systems which exceeds limits $hub_limit

Check: A Hub TEMS should have no more than 10,000 agents
[ITM 623 and earlier] and no more than 20,000 agents
[ITM 630 and later].

Meaning:  The documented level in the Installation Guide TEMS
sizing section is what ITM R&D and QA have tested and stand behind.
No customer should exceed these limits. The agent count includes
both directly configured agents and also subnode agents such as
Agentless Agent for Linux subnodes. The effect of exceeding this
limit is often seen as Hub TEMS instability. Unfortunately that
is a common problem.

Recovery plan: Create new ITM Hub TEMS islands to manage more agents.
--------------------------------------------------------------

DATAHEALTH1006W
Text: Remote TEMS has <count> managed systems which exceeds limits 1,500

Check: A remote TEMS should have no more than 1,500 agents

Meaning: The count includes subnode agents which connect through a
managing agent. The documented level is what ITM R&D and QA have
tested and stand behind. No customer should exceed these limits.
Unfortunately that is a common issue.

Recovery plan: Create new ITM remote TEMS agents and keep within
the published limits. In production workloads the practical limit
may be less than 1,500 agents depending on workload. One site could
only maintain remote TEMS stability by limiting to 750 agents.
--------------------------------------------------------------

DATAHEALTH1007E
Text: TNODESAV duplicate nodes

Check: TNODESAV.NODE values must be unique.

Meaning: This always means the Index file [.IDX] is out of
sync with the data [.DB]. The one fully diagnosed case where
this was observed was when a customer unwisely replaced a .IDX
file from another TEMS and not the .DB file. It could happen
for many other reasons.

Recovery plan: Open a PMR and work with IBM Support to resolve
this issue.
--------------------------------------------------------------

DATAHEALTH1008E
Text: TNODESAV duplicate nodes

Check: TNODELST NODETYPE=V NODELST values must be unique

Meaning: This always means the Index file [.IDX] is out of
sync with the data [.DB]. It could happen for many other reasons.

Recovery plan: Open a PMR and work with IBM Support to resolve
this issue.
--------------------------------------------------------------

DATAHEALTH1009E
Text: TNODELST Type M duplicate NODE/NODELST

Check: TNODELST NODETYPE=M NODE/NODELST values must be unique.

Meaning: This likely means the Index file [.IDX] is out of sync
with the data [.DB]. It can happen for many other reasons.

Recovery plan:  Open a PMR and work with IBM Support to resolve
this issue.
--------------------------------------------------------------

DATAHEALTH1010W
Text: TNODESAV duplicate hostaddr in [$pagent]

Check: TNODESAV HOSTADDR values must be unique.

Meaning:  For most agents this contains the protocol/ip_addr/port/hostname
value. In a normal running system these will be unique. The $pagent
string shows the managed system names of the agents, the thrunode
and the online status Y or N.
Here is an example advisory

10,DATAHEALTH1010W,
  ip.pipe:#99.99.99.141[10055]<NM>ibmzp1928</NM>,
  TNODESAV duplicate hostaddr in
  [ibmzp1928:PX[REMOTE_ibmptm3c_2][Y]
   ibmzp1928:KUX[REMOTE_ibmptm3c_2][Y] ]

This value ,ip.pipe:#99.99.99.141[10055] names the protocol used,
the ip address and the port number.

The two registered users in this example are

ibmzp1928:PX with thrunode REMOTE_ibmptm3c_2 and is online

ibmzp1928:KUX with the same thrunode REMOTE_ibmptm3c_2 and is also online

But but but!!! two ITM processes cannot ever share listening ports.

This means that one of the two processes is not functional but is
continuing to send node status updates. This is a waste of resources
and confusing at best.

There have been two well diagnosed cases.
- An early config problem at the agent left an offline agent
  with the same HOSTADDR as the existing agent but usually in
  offline [N] status
- A Universal Agent was stopped, but the UA process continued
  updating node status. The new Agent Builder replacement used the
  same listening port. Both were online in the TNODESAV table on
  different remote TEMS. There were no situations assigned to
  that Universal Agent.

There will be many more cases to learn from. These are usually not
big problems. However, they do consume resources and can
create confusion in understanding the ITM environment.
It would be best to fix them.

Recovery plan:  Examine each on a case by case basis. In the case
where one agent was offline, a tacmd cleanms -m <agentname>
resolved the issue. In the UA case, the recovery was simply
to kill the errant UA process. UA then went offline and a tacmd
cleanms -m <ua_agent_name> restored normal functioning. If you
need further help, open a PMR and work with IBM Support
--------------------------------------------------------------

DATAHEALTH1011E
Text: HUB TEMS $hub_tems is present in TNODELST but missing from TNODESAV

Check: Check TNODELST NODETYPE=M and the *HUB entry. The corresponding
TNODESAV data does not contain the Hub TEMS nodeid.

Meaning:  The meaning and impact is unknown. This was observed in some
test environments. It has also been seen when checker run against a
remote TEMS. It is unlikely to be seen in a hub TEMS that is actually
working well.

Recovery plan:  Open a PMR and work with IBM Support on how to resolve
this issue.
--------------------------------------------------------------

DATAHEALTH1012E
Text: No TNODELST NODETYPE=V records

Check: TNODELST NODETYPE=V - no such records

Meaning: This might mean a very bad condition.

Recovery plan:  Open a PMR and work with IBM Support on
how to resolve this issue.
--------------------------------------------------------------

DATAHEALTH1013W
Text:  Node Name at 32 characters and might be truncated

Check: Length of NODE in TNODESAV is 32 characters

Meaning: This *might* mean truncation has happened.
For example, if a hostname is relatively long, it is likely
that the total length of Node Name will exceed 32 characters.
During agent registration, if the constructed Node Name is
longer than 32 characters the node name is silently truncated.
This might be harmless if the node name is unique after
truncation. But it could cause problems where one agent would
masquerade as another and cause lots of overhead and incorrect
monitoring. It could also be that the Node Name is exactly 32
characters long and there is no trouble at all.

Recovery plan: Review nodes. If truncation has occurred,
reconfigure the agent to avoid truncation if a problem exists.
--------------------------------------------------------------

DATAHEALTH1014W
Text:  Subnode Name at 31/32 characters and might be truncated

Check: Length of NODE in TNODESAV is 31 or 32 characters

Meaning: This *might* mean truncation has happened. For a subnode
agent this involves a configuration on the controlling agent.
In one case closely examined there was a 3 byte header RZ: and
a 5 byte trailer:RZB. That left 24 characters for the subnode name.
In all cases the nodename created by the agent was 31 characters,
so there was only 23 characters for identifying the subnode. With
some subnode agents, truncation occurred here and caused problems
with subnode agents going offline invalidly. As described earlier
this may or may not cause a problem. If the subnode specifier was
23 characters anyway there would be no trouble at all.

Recovery plan: Review subnodes. If truncation has occurred,
reconfigure the subnode agent to avoid truncation if a problem exists.
--------------------------------------------------------------

DATAHEALTH1015W
Text: Managing agent subnodelist is <count>,  more than $opt_subpc_warn% of 32768 bytes

Check: For a managing agent, compare the length of subnode string
to 32,768 bytes and alert if more than 80% full
[TEMS prior to ITM 623 FP2].

Meaning: This applies only if the TEMS the managing agent connects
to is at maintenance level before ITM 623 FP2.

Until ITM 623 FP2, there is an absolute limit of 32,768 bytes
for the string of subnode agent names [with blank separator]. If that
is exceeded, the TEMS usually fails. In one case TEMS did not crash
but totally stopped working correctly. This is a very dangerous
condition and must be avoided. The default is 90% of maximum.

Recovery plan:  1) Update TEMS to maintenance levels of ITM 623 or ITM 630.
2) Configure multiple managing agents and divide the workload. The usual
estimate is 800 to 1000 subnode agents per managing agent.  A precise number
is not known because the length of each subnode agent name is not fixed.
--------------------------------------------------------------

DATAHEALTH1016E
Text:  TNODESAV invalid node name

Severity: 50

Check:  Node Names should only use certain characters.

Meaning:  This will usually have little effect unless the
Hub TEMS is configured with CMS_NODE_VALIDATION.  Should
that be set the problem agents will be offline. The legal
characters are:

 A-Z, a-z, 0-9,* _-:@$#

A Node Name can never start with '*',  '#',  '.'  or  ' ' .

In one case, what appeared to be a legal name, contained
an invisible X'08' character [ASCII backspace] and therefore
was in fact an invalid Node Name.

At ITM 6.3, the CMS_NODE_VALIDATION was defaulted to YES.
Nodes like this will fail to connect and that could cause
monitoring disruption.

Recovery plan:  Reconfigure agent using legal characters.
--------------------------------------------------------------

DATAHEALTH1017E
Text:  TNODELST NODETYPE=M invalid nodelist name

Check:  Nodelist names should only use certain characters.

Meaning:  This will usually have little effect unless the
Hub TEMS is configured with CMS_NODE_VALIDATION.  At
ITM 630 this is now the default. Should that be set
the problem agents will  be offline. The legal characters are:

 A-Z, a-z, 0-9,* _-:@$# period and space

A Nodelist Name can never start with '*',  '#',  '.'  or  ' ' .

Recovery plan:  Reconfigure agent using legal characters.
--------------------------------------------------------------

DATAHEALTH1018W
Text:  Virtual Hub Table updates <count> per hour <count> agents
Text:  Virtual Hub Table updates peak <rate> per second more than nominal <rate>,  per hour <count>, total agents <count>

Check: Calculate certain agents and the known update virtual hub table update rate

Meaning: This applies to the following agents
UX - Unix OS Agent
OQ - Microsoft MS-SQL
OR - Oracle
OY - Sybase
Q5 - Microsoft Clustering
HV - Microsoft Hyper-V Server Agent
All agents named use an older technology that causes a hub TEMS
virtual table to be updated synchronously - like every one to
three minutes. When there are large numbers of these agents,
the effect on the Hub TEMS can be destabilizing. In addition,
the resulting summary Hub TEMS virtual tables are always
incomplete and thus of little value. The objects that cause
this activity should be deleted.

In the Total message, the peak rate is the number of updates
coming on from the agent's worst case. That is usually at
6 minutes, 12 minutes. etc after the hour. Some of the agents
update 2 or 3 tables and so it is not a pure count of agents.
The damage occurs when the incoming workload surpasses the ITM
communications capacity. Then other communications fail. There
have been cases with as few as 180 Unix OS Agents caused the
Hub TEMS to be destabilized.

Long term, the agent application support files will be changed
to avoid the issue. For any particular customer, they may already
have taken the recovery action.

Recovery plan: See this blog post https://ibm.biz/BdRW3z for a
fuller explanation of the issue and a recovery process. Often IBM
Support prepares the recovery action for the customer.
--------------------------------------------------------------

DATAHEALTH1019W
Text:  Agent using TEMA at <level> level

Check:  Check the Agent Support Library [TEMA] level for 6.1 or later

Meaning:  Prior to ITM 6.2 the OpenSSL library was used for secure
communications. This needs to be updated to later levels which use
 GSKIT for secure communications.

Recovery plan:  Upgrade the OS Agent which will upgrade the Agent
Support Library to use more recent secure communications logic. If t
he OS Agent is not currently installed then install it. That
case can happen with some agents that are installed alone.
--------------------------------------------------------------

DATAHEALTH1020W
Text:  FTO hub TEMS has <count> agents configured which is against FTO best practice

Check: Count number of agents connecting to a hub TEMS in FTO configuration

Meaning: From the installation guide here https://ibm.biz/BdiZue
you can read a statement that in FTO configuration most agents
should connect via remote TEMS. The only exceptions are TEPS,
WPA and Summarization and Pruning Agent. Any other Agents on
the system running the Hub TEMS should also connect to two
remote TEMSes. That provides continuity of monitoring when
the TEMS has stopped.

It may seem strange that in FTO mode we require two Hub TEMS and
two remote TEMS - even for just a single agent. Following is the
background.

1) If the agent loses contact with the primary Hub TEMS by a
communications failure the agent will attempt to connect to the
other Hub TEMS. However, that is in backup mode and will reject
the attempt to connect. That agent will never be able to report
any monitoring - and that conclusion violates the goal of High
Availability.

2) If an agent is connected to both FTO Hub TEMS, one will be
the normal primary remote TEMS. When an FTO switch has occurred
and the normal backup Hub TEMS take the primary role, the agents
will switch to that Hub TEMS. Later when the normal primary Hub
TEMS is started, that Hub TEMS takes on the backup role.  The
agent connection logic will attempt to switch back to the normal
primary remote TEMS after 75 minutes. Each time that happens,
the situations which should run on the agent will first start
up on the Hub TEMS in backup role. Shortly afterwards the agent
will be instructed to switch to another TEMS. When that agent
connects to the current Hub TEMS, the situations will be started
again and create situation events if the conditions warrant. This
will continue every 75 minutes and that is highly disruptive to
normal monitoring.

Please note that if you do not require FTO, a single Hub TEMS
is a fine configuration.

Recovery plan:  If you are going to configure FTO, then all
agents should be configured to remote TEMS except TEPS, WPA
and Summarization and Pruning Agent. TEPS will need two
separate Portal Servers and WPA and S&P will be configured
to both Hub TEMS.
--------------------------------------------------------------

DATAHEALTH1021E
Text:  TSITDESC duplicate nodes

Check: TSITDESC SITNAME values must be unique.

Meaning: This always means the Index file [.IDX] is out of
sync with the data [.DB]. The one fully diagnosed case where
this was observed was when a customer unwisely replaced an .IDX
file from another TEMS and not the .DB file. It could happen
for many other reasons.

Recovery plan: Open a PMR and work with IBM Support on how to
resolve this issue.
--------------------------------------------------------------

DATAHEALTH1022E
Text:  TNAME duplicate nodes

Check: TNAME ID values must be unique.
Meaning: This always means the Index file [.IDX] is out of sync
with the data [.DB]. The one fully diagnosed case where this was
observed was when a customer unwisely replaced an .IDX file from
another TEMS and not the .DB file. It could happen for many other
reasons.

Recovery plan:   Open a PMR and work with IBM Support on how to
resolve this issue.
--------------------------------------------------------------

DATAHEALTH1023W

Text:  TNAME ID index missing in TSITDESC

Check: TNAME ID should have matching TSITDESC SITNAME column

Meaning: This likely has little impact however it means the
TNAME FULLNAME could not be used. It could mean that some
data has been lost from the TSITDESC table.

Recovery plan: Open a PMR and work with IBM Support on
how to resolve this issue.
--------------------------------------------------------------

DATAHEALTH1024E
Text:  Situation Formula *SIT [ <situation> Missing from TSITDESC table

Check: Validate that situation references in the TSITDESC PDT match other TSITDESC SITNAMEs

Meaning: The affected situations will not run as expected.
It could mean that some data has been lost from the TSITDESC table.

Recovery plan:   Rewrite the situation and the situation editor
will force situations selected are correct.
--------------------------------------------------------------

DATAHEALTH1025E
Text:  TNODELST Type V Thrunode <thrunode>  missing in Node Status

Check: Validate that a thrunode reference in a TNODELST NODETYPE=V
object is represented in the TNODESAV table.

Meaning: This could mean that monitoring is not happening on the
node involved. Often this shows as other error checks.

Recovery plan:   Open a PMR and work with IBM Support on how to
resolve this issue.
--------------------------------------------------------------

DATAHEALTH1026E
Text:  TNODELST Type V node invalid name

Check:  Node names should only use certain characters.

Meaning:  This will usually have little effect unless the Hub TEMS
is configured with CMS_NODE_VALIDATION.  Should that be set the
problem agents will  be offline. The legal characters are:

 A-Z, a-z, 0-9,* _-:@$# period and space

A Nodelist Name can never start with '*',  '#',  '.'  or  ' '

Recovery plan:  Reconfigure agent and use legal characters.
--------------------------------------------------------------

DATAHEALTH1027E
Text:  TNODELST Type V Thrunode <node> invalid name

Check:  Nodelist names should only use certain characters.

Meaning:  This will usually have little effect unless the
Hub TEMS is configured with CMS_NODE_VALIDATION.  Should
that be set the problem agents will  be offline. The legal
characters are:

A-Z, a-z, 0-9,* _-:@$# period and space

A Nodelist Name can never start with '*',  '#',  '.'  or  ' '

Recovery plan:  Reconfigure nodelist and use legal characters.
--------------------------------------------------------------

DATAHEALTH1028E
Text:  TOBJACCL duplicate nodes

Check: TOBJACCL.NODE values must be unique.

Meaning: This always means the Index file [.IDX] is out of sync
with the data [.DB].

Recovery plan: Open a PMR and work with IBM Support on how to
resolve this issue.
--------------------------------------------------------------

DATAHEALTH1029W
Text:  TOBJACCL Nodel $nodel1 Apparent MSL but missing from TNODELST

Check: TOBJACCL.NODEL values should be present in TNODELST.

Meaning: This is a meaningless distribution.

Recovery plan: Review entry and delete if no longer needed.
--------------------------------------------------------------

DATAHEALTH1030W
Text:  "TOBJACCL unknown Situation with a unknown MSN/MSL name distribution

Check: TOBJACCL.OBJNAME values should be present in TNODESAV

Meaning: This is a meaningless distribution.

Recovery plan: Review entry and delete if no longer needed.
--------------------------------------------------------------

DATAHEALTH1031E
Text:  TGROUPI [$key] unknown TGROUP ID

Check: TGROUPI ID should match a TGROUP ID

Meaning: This could prevent Situation Group Distribution

Recovery plan: Review Situation Group entries and correct.
--------------------------------------------------------------

DATAHEALTH1032E
Text:  TGROUPI [$key] unknown group objectname

Check: TGROUPI OBJNAME should match a TGROUP ID

Meaning: This could prevent Situation Group Distribution

Recovery plan: Review Situation Group entries and correct.
--------------------------------------------------------------

DATAHEALTH1033E
Text:  TGROUPI [$key] unknown situation objectname

Check: TGROUPI OBJNAME should match a Situation name

Meaning: This could prevent Situation Group Distribution

Recovery plan: Review Situation Group entries and correct.
--------------------------------------------------------------

DATAHEALTH1034W
Text:  TGROUP ID $f not distributed in TOBJACCL

Check: Validate that a Situation Group ID is distributed.

Meaning: This could mean that monitoring is not happening on
the Situation Group. In some cases the data is used for reference only.

Recovery plan:   Review situation group and see if it should be
distributed.
--------------------------------------------------------------

DATAHEALTH1035W
Text:  TOBJACCL Group name missing in Situation Group

Check: Validate that a Group distribution exists in Situation Group

Meaning: This likely a left over distribution for a deleted situation group.

Recovery plan:   Review distribution and delete if no longer needed.
--------------------------------------------------------------

DATAHEALTH1036E
Text:  Invalid Agent version [agent_version] in node <nodename> in tnodesav

Check: Versions should be nn.nn.nn

Meaning: Probably a left over from a bad install, but it could prevent normal agent operation.

Recovery plan: review agent configuration
--------------------------------------------------------------

DATAHEALTH1037W
Text:  Agent at version [agent_version] using TEMA at lower release [TEMA_version]

Check: Compare TEMA and Agent version

Meaning: This may work OK but there is little experience and no IBM
testing at all. Older TEMA levels are missing APAR fixes and that
can increase the number of problems seen.

Recovery plan:   upgrade OS Agent to higher release level.
--------------------------------------------------------------

DATAHEALTH1038E
Text:  *HUB node missing from TNODELST Type M records"

Check: Check for presence of *HUB

Meaning: This is usually a severe problem where the TNODELST
has been damaged and needs rebuilding. It can also mean the
program was run on a remote TEMS in error.

Recovery plan:   Consult IBM Support if needed.
--------------------------------------------------------------

DATAHEALTH1039E
Text:  table LSTDATE is blank and will not synchronize in FTO configuration

Check: Check for blank column in table

Meaning: This is a FTO configuration and these IDs will not be
synchronized to the backup hub TEMS. This can lead to loss of
events at event receiver. If not FTO then not a problem. This
was an object created before ITM the objects were synchronized.

Recovery plan:   In some cases you can use tacmd functions to
delete and recreate the data. In other cases contact IBM Support
for advice.
--------------------------------------------------------------

DATAHEALTH1040E
Text:  LSTDATE for [comment] value in the future date

Check: Check for future date in that field and ensure FTO is configured

Meaning: This condition was corrected by APAR IV60288 at ITM 630 FP3.
Before that time, if the future LSTDATE was processed by a FTO Backup
hub TEMS, that would prevent other updates from being synchronized.
That means FTO would not work properly.

Recovery plan:   Upgrade to ITM 630 FP3. Otherwise contact IBM Support
for a recovery action plan.
--------------------------------------------------------------

DATAHEALTH1041W
Text:  table LSTDATE value in the future <date>

Check: Check for future date in that field and ensure FTO is not configured

Meaning: This has no effect when FTO is not configured but would
definitely be a problem if FTO was configured later on.

Recovery plan:   Upgrade to ITM 630 FP3. Otherwise contact IBM Support
in case a FTO configuration is planned for the future.
--------------------------------------------------------------

DATAHEALTH1042E
Text: Agents[count] using TEMA in IZ76410 danger zone

Check: Check for agent level

Meaning: TEMA in the range ITM 621 before FP3 and ITM 622 before
FP3 had a severe defect whereby an agent could be connected to
two remote TEMS at the same time. This would occur following a
switch to secondary remote TEMS and an automatic switch back.
The issues were many including situations running multiple
times, Agent crashes, no situations running and many more.

Recovery plan:   Upgrade OS Agent to levels past the danger zone.
Alternatively only configure agent to a single remote TEMS.
For more information contact IBM Support.
--------------------------------------------------------------

DATAHEALTH1043E
Text:  Agent with TEMA at [version] later than TEMS $tems1 at [version]

Check: Check for agent level and TEMS level

Meaning: Agents should be at a TEMA level equal or below the
TEMS version level. This case is not supported and is not
tested. It may work but is considered risky.

Recovery plan:   Upgrade the TEMS to the agent level or higher.
If needed a new remote TEMS at an equal or higher level can be
used. TEMSes can connect to other TEMS any order high to low
or low to high.
--------------------------------------------------------------

DATAHEALTH1044E
Text:  Agent with unknown TEMA level [version]

Check: Check for agent level

Meaning: This has been seen in a few cases and the exact impact
is unknown. However it does not seem to be a safe condition. This
might also suggest a new Database Health Checker version is needed.

Recovery plan: Reinstall the agent or contact IBM Support for advice.
--------------------------------------------------------------

DATAHEALTH1045E
Text:  TEMS with unknown version [version]

Check: Check for TEMS level

Meaning: This has never been seen and the exact impact is unknown.
However it does not seem to be a safe condition. This might also
suggest a new Database Health Checker version is needed.

Recovery plan: Contact IBM Support for advice
--------------------------------------------------------------

DATAHEALTH1046W
Text:  Total TEMS Packages [.cat files] count [count] exceeds nominal [500]

Check: Check for number of catalogs [IBM internal usage only]

Meaning: TEMS has an absolute maximum of 512 catalog files. If
one more is added then TEMS will fail to initialize.

Recovery plan: Remove unneeded .cat and related .atr files.
--------------------------------------------------------------

DATAHEALTH1047E
Text:  EVNTMAP ID[id] Unknown Situation in mapping - sitname

Check: See if event mapping references a known situation name

Meaning: This was probably left over when a situation was deleted.
This has relatively little impact.

Recovery plan: If concerned contact IBM Support to get help on
removing data.
--------------------------------------------------------------

DATAHEALTH1048E
Text:  Total TEMS Packages [.cat files] count count] close to TEMS failure point of 513"

Check: Check for number of catalogs [IBM internal usage only]

Meaning: TEMS has an absolute maximum of 512 catalog files. If one
more is added then TEMS will fail to initialize. This is when total
is more than 510 and failure is very close.

Recovery plan: Remove unneeded .cat and related .atr files.
--------------------------------------------------------------

DATAHEALTH1049W
Text:  TNODESAV node name with embedded blank

Check: Check for nodes with embedded blanks

Meaning: Agent names are allowed to have embedded blanks, however
it is usually a configuration error and confusing at best.

Recovery plan: Reconfigure agent without embedded blanks in name.
--------------------------------------------------------------

DATAHEALTH1050W
Text: TNODELST TYPE V node name with embedded blank

Check: Check for TNODELST TYPE V nodes with embedded blanks

Meaning:  This is likely a side effect of DATAHEALTH1049W.
Agent names are allowed to have embedded blanks, however
it is usually a configuration error and confusing at best.

Recovery plan: Reconfigure agent without embedded blanks in name.
--------------------------------------------------------------

DATAHEALTH1051W
Text:  TNODELST TYPE V Thrunode [thrunode] with embedded blank

Check: Check for TNODELST TYPE V thrunode with embedded blanks

Meaning:  This is likely a side effect of DATAHEALTH1049W. Agent
names are allowed to have embedded blanks, however it is usually
a configuration error and confusing at best.

Recovery plan: Reconfigure remote TEMS without embedded blanks
in name
--------------------------------------------------------------

DATAHEALTH1052W
Text:  TNODELST NODETYPE=M nodelist with embedded blank

Check: Check for TNODELST TYPE M nodelist with embedded blanks

Meaning:  Nodelist names are allowed to have embedded blanks,
however it is usually a configuration error and confusing at best.

Recovery plan: Reconfigure remote TEMS without embedded blanks
in name.
--------------------------------------------------------------

DATAHEALTH1053E
Text:  EVNTMAP Situation reference missing

Check: EVNTMAP Situation tag in MAP column

Meaning:  The Event Mapping does not reference a situation and
so cannot be applied. If an event mapping was expected, it will
not work.

Recovery plan: Work with IBM Support on how to remove the data.
--------------------------------------------------------------

DATAHEALTH1054E
Text:  TPCYDESC duplicate key PCYNAME

Check: TPCYDESC should have unique policy names

Meaning: This always means the Index file [.IDX] is out of sync
 with the data [.DB]. This usually means the workflow policy
 process is not working as expected.

Recovery plan: Open a PMR and work with IBM Support to resolve
this issue.
--------------------------------------------------------------

DATAHEALTH1055E
Text: Policy Activity [ACTNAME=name] Unknown policy name

Check: TACTYPCY should have reference a known policy name

Meaning: This is likely a left over activity from a deleted
workflow policy. It has no impact unless a new policy is
created using the old name in which case the new policy
might behave unexpectedly.

Recovery plan: If this is a concern, open a PMR and work
with IBM Support to resolve this issue.
--------------------------------------------------------------

DATAHEALTH1056E
Text: Policy Activity [ACTNAME=name] Unknown policy name

Check: Check that Workflow Policy activities reference
known situations.

Meaning: This usually means the workflow policy process is
not working as expected. Usually this means that the situation
was deleted.

Recovery plan: If the workflow policy is no longer used it
should be deleted or rewritten.
--------------------------------------------------------------

DATAHEALTH1057E
Text:  TPCYDESC Evaluate Sit Now - unknown situation sitname

Check: Check that Workflow Policy activities reference known
situations.

Meaning: This usually means the workflow policy process is
not working as expected. Usually this means that the situation
was deleted.

Recovery plan: If the workflow policy is no longer used
it should be deleted or rewritten.
--------------------------------------------------------------

DATAHEALTH1058E
Text:  TCALENDAR duplicate key ID

Check: TCALENDAR should have unique keys

Meaning: This always means the Index file [.IDX] is out of sync
with the data [.DB]. This usually means the workflow policy process
is not working as expected.

Recovery plan: Open a PMR and work with IBM Support to resolve
this issue.
--------------------------------------------------------------

DATAHEALTH1059E
Text:  TOVERRIDE duplicate key ID

Check: TOVERRIDE should have unique keys

Meaning: This always means the Index file [.IDX] is out of sync
with the data [.DB]. This usually means the workflow policy process
is not working as expected.

Recovery plan: Open a PMR and work with IBM Support to resolve
this issue.
--------------------------------------------------------------

DATAHEALTH1060E
Text:  TOVERRIDE Unknown Situation [sitname] in override

Check: TOVERRIDE should reference a known situation

Meaning: This usually means the situation was deleted and
has relatively low impact.

Recovery plan: If this is concerning, work with IBM Support
to delete the data.
--------------------------------------------------------------

DATAHEALTH1061E
Text:  TOVERITEM Unknown Calendar ID calid

Check: TOVERITEM should reference a known calendar if specified

Meaning: This could mean the situation override is not working as expected.

Recovery plan: Review override and validate it is correctly defined.
--------------------------------------------------------------

DATAHEALTH1062E
Text:  TOVERITEM Unknown TOVERRIDE ID id

Check: TOVERITEM should reference a known TOVERRIDE object

Meaning: This could mean the situation override is not working as expected.

Recovery plan: Review override and validate it is correctly defined.
--------------------------------------------------------------

DATAHEALTH1063W

Text:  table LSTDATE is blank and will not synchronize in FTO configuration
Check: LSTDATE should not be blank

Meaning: This is an error condition but it has no effect and
FTO is not defined.

Recovery plan: If FTO is planned in future, work with IBM Support
to correct data.
--------------------------------------------------------------

DATAHEALTH1064W
Text:  Situation Sampling Interval value seconds - higher then danger level danger

Check: situation sampling interval should be maximum 4 days

Meaning: This a recently identified issue. On Linux/Unix/Windows
it just doesn't work as expected on z/OS it can result in excessive
CPU resource used,

Recovery plan: Change sampling interval to 4 days or less.
--------------------------------------------------------------

DATAHEALTH1065W
Text: TPCYDESC Wait on SIT or Sit reset - unknown situation sitname but policy not autostarted

Check: Check that Workflow Policy activities reference known situations.

Meaning: This usually means the workflow policy process would not
work as expected if started. Usually this means that the situation
was deleted.

Recovery plan: If the workflow policy is no longer used it should be deleted or rewritten.
--------------------------------------------------------------

DATAHEALTH1066W
Text: TPCYDESC Evaluate Sit Now - unknown situation sitname but policy not autostarted

Check: Check that Workflow Policy activities reference known situations.

Meaning: This usually means the workflow policy process would not
work as expected if started. Usually this means that the situation
was deleted.

Recovery plan: If the workflow policy is no longer used it should be deleted or rewritten.
--------------------------------------------------------------

DATAHEALTH1067E
Text:  Danger of TEMS crash sending events to receiver APAR IV50167

Check: Check TEMS maintenance level.

Meaning: At ITM 630 FP2 there were a number of serious problems. The most
severe was APAR IV50167.

Using Msg Slot Customization with Event Forwarding may crash 6.3 FP2 TEMS
http://www-01.ibm.com/support/docview.wss?uid=swg21656217

With some customers no crash was seen. With others it was a couple times
a week. With others the crashing was constant after some point.

Here is a partial list of other known issues

APARs opened against IBM Tivoli Monitoring (ITM) V63 FP2
http://www-01.ibm.com/support/docview.wss?uid=swg21659707

Recovery plan: Upgrade the hub TEMS to a later maintenance level such as

IBM Tivoli Monitoring 6.3.0 Fix Pack 7 (6.3.0-TIV-ITM-FP0007)
http://www-01.ibm.com/support/docview.wss?uid=swg24041633
--------------------------------------------------------------

DATAHEALTH1068E
Text: Agent registering [count] times: possible duplicate agent names

Check: Check TEIBLOGT table

Meaning: It is quite possible to accidentally have multiple agents
with the same name. This contradicts a basic ITM requirement of each
managed system name being unique. The impact is a failure to monitor
as expected. It can also have severe impacts on TEMS and TEPS
performance. This Database Health Checker process identifies some
but not all of the problems. Another symptom of the issue is relatively
 constant "Navigator Updates Pending" messages in the Portal Client.

See the Database Health Checker report section showing the
top 20 agents which *may* be having a problem. There may be
no real problems if the hub TEMS has been running for a long
time and no agent is seen with unusually large counts. See the
recovery plan section below for a general way to identify all
such issue.

Recovery plan: See the following blog post
Sitworld: TEPS Audit https://ibm.biz/BdXNvy

The report shows all the duplicate agent names that affect the
TEPS. In the portal client this is seen as excessive
"Navigator Updates Pending" conditions. There is other work
underway to identify more cases.

Recovery is to configure the agents to have unique names.
--------------------------------------------------------------

DATAHEALTH1069E
Text:  FTO hub TEMS have different version levels [nodeid=version;�]

Check: Check definition of hub TEMSes

Meaning: FTO hub TEMSes should have the same maintenance level. It is
possible to run for a while at different levels such as while
installing new maintenance. However to minimize problems avoiding
this condition is required.

Recovery plan: Apply maintenance to backlevel TEMS so they run at the same level.
--------------------------------------------------------------

DATAHEALTH1070W
Text:  Agent There are count hub TEMS [nodeid=version;�]

Check: Check definition of hub TEMSes

Meaning: An ITM configuration can validly have one or two hub
TEMSes. This advisory is created when three or more hub
TEMSes are found. It is currently unknown if this causes
any actual problems, but it is often an accident. There is
a transient configuration with two FTO hub TEMSes and another
hub TEMS in Hot Backup mode, so condition could be normal.

Recovery plan: Correct the ITM to have only one or two hub TEMSes.
--------------------------------------------------------------

DATAHEALTH1071W
Text:  Situation with invalid sampling days [days]

Check: Check Situation Sampling Interval days

Meaning: The Situation Sampling interval days should be a number
from 1 to 3 digits. This advisory is produced if the number is
empty or more than 3 digits. If this condition exists, it might
cause situations to behave abnormally
--------------------------------------------------------------

DATAHEALTH1072W
Text:  Situation with invalid sampling time [time]

Check: Check Situation Sampling Interval time

Meaning: The Situation Sampling interval time should
be a 6 digit number representing hhmmss. Cases have been
seen where this is "0" or "0000". In those cases it caused
incorrect sampled situation behavior and monitoring did
not take place as expected.

Recovery plan: Re-write the situation if it is still useful,
otherwise delete it.
--------------------------------------------------------------

DATAHEALTH1073W
Text:  MQ Agent name has missing hostname qualifier

Check: MQ Agent name has missing hostname qualifier

Meaning: MQ agents should specify the hostname using
this control in the mq.cfg file:

SET AGENT NAME(<hostname>)

Without that it is quite easy to get accidental
duplicate names for different agents. That can
lead to confusion and excessive TEMS and TEPS work.

Recovery plan: Add the above control.
--------------------------------------------------------------

DATAHEALTH1074W
Text:  Situation Event arriving $psit_rate per minute

Check: Check situations and eliminate the reason for excessive event rates.

Meaning: Events that arrive in high volume can sometimes
de-stabilize the hub and remote TEMSes. Situation events should
be for rare and exceptional circumstances where a recovery action
is possible to correct the condition.

In the example customer situation, a Windows login rejected alert
was arriving hundreds of time per second and prevented the TEMS
from doing any other work including servicing TEPS and working
with the FTO backup hub TEMS.

The Database Health Checker "Top 20 Situation Event Report"
section will display more information including three example
offending agents.

Recovery plan: Stop the situation and investigate. Remove the
cause of the alert or, if condition is actually normal change
the situation to stop warning on this normal condition.
--------------------------------------------------------------

DATAHEALTH1075W
Text:  TNODESAV duplicate 2 SYSTEM_NAMEs in [...]

Check: Check managed systems for duplicate System Names on different systems

Meaning: The Portal Client Navigator layout is depended on
the Agent System Name. Usually that is identical to the Agent
Host Name which derives from the system hostname. However,
using CTIRA_HOSTNAME and CTIRA_SYSTEM_NAME an agent can be
configured to have almost any value. When a Hostname is
duplicated, you often see duplicate agent names, which
causes significant issues. When a System Name is duplicated,
there is a significant possibility of confusion.
Each of the agents will be shown in the Navigation tree under
the same node.

In one case, there were 500+ Windows OS Agents all under the
same navigation node. This caused great distress.

Recovery plan: Reconfigure the agents involved. Usually that
means making sure the Hostname and System Name are equivalent
and unique across all agents.
--------------------------------------------------------------

DATAHEALTH1076W
Text:  CF Agent configured to $thrunode1 which is not the hub TEMS

Check: Check managed systems for CF Agents not configured to the hub TEMS.

Meaning: The CF Agent - name ends ::CONFIG is part of the
MQ Configuration Agent. By product design there should be only
one such agent in an ITM environment and it must be configured
only to the hub TEMS.

The formal product name is ITCAM Configure for MQ and is also
known as ITCAM MQ Configuration. At this writing [Feb 2019) Version
710 and 730 are supported.

The CONFIG process is used by XXX::RCACFG agents. The extra CONFIG
systems on remote TEMSes have no purpose and will cause remote TEMS
and hub TEMS resource drains to no benefit.

Recovery plan: For each remote TEMS with this issue make these
changes and recycle the remote TEMS.

Windows: Remove "KCFFEPRB.KCFCCTII" from KDS_RUN in
<installdir>\cms\KBBENV.

Linux/Unix: Remove "KCFFEPRB.KCFCCTII" from KDS_RUN in
<installdir>/tables/<temsnodeid>/KBBENV

and

<installdir>/config/kbbenv.ini

In the future, only configure that agent to the hub TEMS.
--------------------------------------------------------------

DATAHEALTH1077E
Text:  CF Agent not supported in FTO mode

Check: Check managed systems for CF configured to hub TEMS in FTO mode

Meaning: The CF Agent - name ends in ::CONFIG is part of the
MQ Configuration Agent. By product design there should be
only one such agent in an ITM environment and it must be
configured only to the hub TEMS and the TEMS must not be
in FTO mode.

The formal product name is ITCAM Configure for MQ and is also
known as ITCAM MQ Configuration. At this writing Version
710 and 730 are supported.

Recovery plan: For each TEMS where this component is not
needed make the changes below and recycle the TEMS.

Windows: Remove "KCFFEPRB.KCFCCTII" from KDS_RUN in
<installdir>\cms\KBBENV.

Linux/Unix: Remove "KCFFEPRB.KCFCCTII" from KDS_RUN in
<installdir>/tables/<temsnodeid>/KBBENV

and

<installdir>/config/kbbenv.ini

In the future, only configure that agent to the hub TEMS.
--------------------------------------------------------------

DATAHEALTH1078W
Text:  WPA connected to $thrunode1 which is not the hub TEMS

Check: Check managed systems for WPA connected to remote TEMS

Meaning: The Warehouse Proxy Agent must only be configured
to the hub TEMS. If there is to be a WPA installed on each
remote TEMS [definitely best practice] each WPA must connect
to the hub TEMS and use an environment variable to specify
which remote TEMS it is responsible for.

While this is the normal condition, a number of user have
configured a TEMS specific WPA to connect to that TEMS only
and it usually works well.

Recovery plan: Configure each WPA to connect and register with
the hub TEMS and use the KHD_WAREHOUSE_TEMS_LIST environment
variable to specify the remote TEMS nodeid that the WPA will be
responsible for.
--------------------------------------------------------------

DATAHEALTH1079E
Text:  TNODESAV invalid affinities [aff] for node

Check: TNODESAV AFFINITIES

Meaning: Something is really wrong with the agent.

Recovery plan: Reinstall agent. If this does not cure issue
then contact IBM Support.
--------------------------------------------------------------

DATAHEALTH1080W
Text:  Situation Status Events arriving num per minute

Check: SITSTSH

Meaning: This means situation status events are arrive more than
60 per minute long term. Many hub TEMS cannot sustain such a rate
and will be unstable. Large systems may sustain such a rate with
success.

Recovery plan: Monitor system for stability. Change situation
definitions to reduce work. Create multiple hub TEMS for large
environments.
--------------------------------------------------------------

Recovery plan: Upgrade OS Agent to a supported level.

DATAHEALTH1081W
Text:  End of Service agents maint[level] count[num] date[date]

Check: TNODESAV

Meaning: This records that there are out of service
TEMA [Agent Support Library] levels. That usually corresponds
to OS Agent levels since they are bundled together. While
IBM Support will give aid when possible but it will be
impossible to do deep level diagnosis and APAR fix creation.

See separate report section.

Recovery plan: Upgrade OS Agent to a supported level.
--------------------------------------------------------------

DATAHEALTH1082W
Text:  End of Service agents maint[level] count[num] date[date]

Check: TNODESAV

Meaning: This records that there are some agents that will be
out of service TEMA [Agent Support Library] levels in the future.
That usually corresponds to OS Agent levels since they are bundled
together. After that date, IBM Support will give aid when possible
but it will be impossible to do deep level diagnosis and APAR
fix creation. See separate report section.

Recovery plan:  Upgrade the agent before the end of support date.
--------------------------------------------------------------

DATAHEALTH1083W
Text:  End of Service TEMS tems maint[level] date[date]

Check: TNODESAV

Meaning: This records that the TEMS is out of service maintenance
level. IBM Support will give aid when possible but it will be
impossible to do deep level diagnosis and APAR fix creation.

Recovery plan:  Upgrade the TEMS to a supported level before the
end of support date.
--------------------------------------------------------------

DATAHEALTH1084W
Text:  Future End of Service TEMS tems maint[level] date[date]

Check: TNODESAV

Meaning: This records that the TEMS will be out of service
maintenance level at a future date. IBM Support will give aid
when possible but it will be impossible to do deep level diagnosis
and APAR fix creation.

Recovery plan:  Upgrade the TEMS to a supported level before the
end of support date.
--------------------------------------------------------------

DATAHEALTH1085W
Text:  Situation undefined but Events arriving from nodes[nodes]

Check: TSITSTSH

Meaning: This means that situation event status are arriving for
a situation that is not defined in the current database. Depending
on volume of incoming work this can have a profound effect and
often goes unnoticed. The advisory is tagged with Situation and
the Atomize value if present.

The TEMS sends an order to the agent to stop the situation but
sometimes the agent does not get the instruction. This can happen
at any maintenance level.

Recovery plan:  At recent maintenance levels, where agent and TEMS
are at ITM 623 FP2 or higher, when the agent starts up with the hub
TEMS they will validate exactly what situations should running
and made any needed adjustments. An agent recycle will correct the
condition.

If either TEMS or agent is below that maintenance level, the
procedure documented here can be used - in the local workaround
section:

http://www.ibm.com/support/docview.wss?uid=swg1IV10164

The agent is stopped, the situation persistence file is deleted and the agent is started.
--------------------------------------------------------------

DATAHEALTH1086W
Text:  MS_Offline[count] dataserver evaluation rate count per second somewhat high

Check: TSITDESC and TNODESAV

Meaning: There are more than 30 INODESTS evaluations per second
in the TEMS dataserver. This is associated with MS_Offline type
situations.

count is the number of MS_Offline type situations.

Recovery plan:  Run fewer MS_Offline type situations to avoid
performance problems.
--------------------------------------------------------------

DATAHEALTH1087E
Text:  MS_Offline[count] dataserver evaluation rate count per second dangerously high

Check: TSITDESC and TNODESAV

Meaning: There are more than 200 INODESTS evaluations per second
in the TEMS dataserver. This is associated with MS_Offline type
situations. This can destablize hub TEMS operations.

count is the number of MS_Offline type situations.

Recovery plan:  Run fewer MS_Offline type situations to avoid
problems.
--------------------------------------------------------------

DATAHEALTH1088W
Text:  MS_Offline[count] SITMON evaluation rate count per second somewhat high

Check: TSITDESC and TNODESAV

Meaning: There are more than 30 SITMODE evaluations per second
in the TEMS dataserver. This is associated with MS_Offline type
situations using Persist>1.

count is the number of MS_Offline type situations.

Recovery plan:  Avoid using MS_Offline type situations with
Persist, which can cause severe performance problems.
performance problems.
--------------------------------------------------------------

DATAHEALTH1089E
Text:  MS_Offline[count] SITMON evaluation rate count per second dangerously high

Check: TSITDESC and TNODESAV

Meaning: There are more than 200 SITMODE evaluations per second
in the TEMS dataserver. This is associated with MS_Offline type
situations using Persist>1.

count is the number of MS_Offline type situations.

Recovery plan:  Avoid using MS_Offline type situations with
Persist, which can cause severe performance problems.
performance problems and TEMS instability.
--------------------------------------------------------------

DATAHEALTH1090W
Text:  Agent [agent name] using TEMA at version [version] in IV18016 danger zone

Check: Check for agent level

See DATAREPORT012 for meaning and recovery details.
--------------------------------------------------------------

DATAHEALTH1091W
Text:  Autostarted Situation to Online Agent ratio[percent] - dangerously high

Check: Check for situations versus agents

Meaning: Hub and remote TEMS can become unstable if too many
situations are running. This has been seen when separate situations
are distributed to specific agents instead of multiple agents. The
test here is 100%.

The TEMS dataserver [SQL processor] runs logic for each situation
which is distributed. In the key problem case there were 7,000
situations and 700 agents. The TEMS became so unstable it stopped
processing events entirely.

Recovery plan: Reduce the number of situations by using MSLs to
distribute a single situation to multuple agents. If this logic
is absolutely necessary, create multuple hub TEMSes to manage
the workload.
--------------------------------------------------------------

DATAHEALTH1092W
Text:  TEMS Dataserver SQL Situation Load $psit_rate per second more than 4.00/second

Check: Check for too many situations running

Meaning: Hub and remote TEMS can become unstable if too many
situations are running. The TEMS dataserver - SQL processor -
evaluates at each sampling interval. In one case a hub TEMS
failed when processing evaluations at 12 per second. The
problem level depends on many factors including how powerful
the system is running the TEMS.

This is a new area of interest and so is more of a warning than
a predicted error case.

Recovery plan: Reduce the number of situations by using MSLs to
distribute a single situation to multuple agents. Also you can
increase the sampling intervals and create remote TEMSes to
spread out the workload.
--------------------------------------------------------------

DATAHEALTH1093W
Text:  Agents[count] using TEMA in IV30473 danger zone

Check: Check for agent level

See DATAREPORT013 for meaning and recovery details.
--------------------------------------------------------------

DATAHEALTH1094W
Text:  TEMS Dataserver SQL Situation Startup total $sit_total more than 2000

Check: Check for too many situations running

Meaning: When a TEMS starts up, autostart situations must
be compiled and delivered to the online agents. If there
are a large number, this can take such a long time that
the TEMS loses contact with hub TEMS. On a remote TEMS
contact is eventually restored, however the condition is
abnormal and should be avoided.

Recovery plan: Reduce the number of situations or create
remote TEMSes to spread out the workload.
--------------------------------------------------------------

DATAHEALTH1095W
Text:  HUB TEMS Dataserver SQL Situation Startup total $sit_total more than 2000

Check: Check for too many situations running

Meaning: When a TEMS starts up, autostart situations must
be compiled and delivered to the online agents. If there
are a large number, this can take such a long time that
the TEMS loses contact with hub TEMS. On a hub TEMS
contact is never restored and the hub TEMS is effectively
disabled.

One case where this condition was fully diagnosed the
environment was a hub TEMS [no remote TEMS] with 700 agents
and 7500 autostated.

Recovery plan: Reduce the number of situations or create
remote TEMSes to spread out the workload.
--------------------------------------------------------------

DATAHEALTH1096W
Text:  Systems [count] running agents with multiple TEMA levels - see later report

Check: TNODESAV check for agent TEMA levels

Meaning: Each ITM agent requires an Agent Support library
TEMA and usually these share the OS Agent TEMS. When there
are multiple levels, that usually reflects 32-bit agents
with 64-bit OS agents. The 32-bit TEMAs are not updated
when 64-bit OS Agents are upgraded.

This can also be cases where agents are installed in different
installation directories.

The impact is that some agents are running back level TEMA
levels and thus are exposed to known defects.

Recovery plan: Correct the issue. The following command

tacmd updateFramework

can be used to upgrade all TEMAs including 32-bit.

Consult IBM Support if there are questions.
--------------------------------------------------------------

DATAHEALTH1097W
Text:  Remote TEMS nodeid maint[level] is later level than Hub TEMS nodeid maint[level]

Check: TNODESAV and TNODELST checks

Meaning: In general hub TEMS levels can be lower than
remote TEMS levels. However there is less customer experience
in that environment. In one recent case of a z/OS remote
TEMS at ITM 630 FP6 and a Windows hub TEMS at ITM 622 FP9
a SQL failure was observed as the remote TEMS was updating the
hub TEMS. The issue is rare and so impact level set low.

The issue is more problematical if the hub and remote TEMSes are
are at different release levels. Many such case will appear
to work but can fail under extreme circumstances.

Recovery plan: Update the hub TEMS.
--------------------------------------------------------------

DATAHEALTH1098E
Text:  UADVISOR Historical Situations enabled [count] but no online WPAs seen

Check: TNODESAV and TSITDESC checks

Meaning: This means uadvisor historical data situations are
collecting data at agents [or TEMS] however no Warehouse
Proxy Agents are online. This means that historical data
will collect at the agents [or TEMS] can can trigger an
out of disk storage condition.

Recovery plan: Install some WPAs or turn off historical data
collection.
--------------------------------------------------------------

DATAHEALTH1099W
Text:  TOBJACCL Unknown Situation with a known MSL name distribution

Check: TSITDESC and TNODESAV and TNODELST checks

Meaning: A situation is mentioned in the distribution table
TOBJACCL with a known managed system list - however the
situation is not defined.

This suggests a situation might be missing and not running
as it would be expected to. However if it was not supposed to be
running there is no effect.


Recovery plan: Review the conditions and see what was planned.
IBM Support can help you eliminate any false records.
collection.
--------------------------------------------------------------

DATAHEALTH1100W
Text:  TOBJACCL Unknown Situation with a known MSN name distribution";

Check: TSITDESC and TNODESAV and TNODELST checks

Meaning: A situation is mentioned in the distribution table
TOBJACCL with a known managed system name list - however the
situation is not defined.

This suggests a situation might be missing and not running
as it would be expected to. However if it was not supposed to be
running there is no effect.


Recovery plan: Review the conditions and see what was planned.
IBM Support can help you eliminate any false records.
collection.
--------------------------------------------------------------

DATAHEALTH1101E
Text:  TOBJACCL known Situation with a unknown MSN/MSL $nodel1 distribution

Check: TSITDESC and TNODESAV and TNODELST checks

Meaning: A situation is mentioned in the distribution table
and the situation is known. However the distribution target
(managed system list or managed system name) is unknown.

This strongly suggest that a situation should be running but is
is not. On one occasion a database file condition caused the
temporary loss of thousands of Managed System List objects
and then result was that many many situations were not running
as expected. That is a severe condition.


Recovery plan: Work with IBM Support to recover from this
severe condition. Having a good backup of the TEMS database
files could help recover. See this document

Sitworld: Best Practice TEMS Database Backup and Recovery
https://ibm.biz/BdRKKH
--------------------------------------------------------------

DATAHEALTH1102W
Text:  TOBJACCL known Situation with a unknown system generated MSL name

Check: TSITDESC and TNODESAV and TNODELST checks

Meaning: A situation is mentioned in the distribution table
and the situation is known. However the distribution target
(system generated managed system list) is unknown.

This is almost certainly a case where a application support
has been installed, the situations have been configured to
run but no agents are currently running. This has a small
effect on TEMS startup time but is not otherwise a problem.

Recovery plan: Probably ignore issue.
--------------------------------------------------------------

DATAHEALTH1103W
Text:  MS_Offline type situation with 0 sampling rate - cannot work correctly

Check: TSITDESC

Meaning: A MS_Offline type situation is inherently a
sampled situation. This alerts to cases where the
sampling interval is zero. At the best the situation
will not fire as expected. At the worst it could cause
TEMS instability or crash.

Recovery plan: Stop the situation and re-author it correctly.
--------------------------------------------------------------

DATAHEALTH1104E
Text:  This ITM has count AMC [:T3] agents and only one is allowed

Check: TNODESAV check

Meaning: The T3 agent is and central control for
ITMCAM for Transactions. By that product design there
must be only one T3 agent in an ITM environment. If this
is violated the product will not work as expected.

for more details see https://goo.gl/8Lqr9Z

Recovery plan: Eliminate the extra T3 agents or set up
separate ITM environments to host them.
--------------------------------------------------------------

DATAHEALTH1105E
Text:  TNODELST Type V Node is same as Thrunode - illegal

Check: TNODELST check

Meaning: Each node will have a managing node. Often that
is a hub or remote TEMS. However it could be a product
like Tivoli Log Agent which has a managing node xxx:LO and
potentially many subnode agents LO:sssss.

Node same as thrunode is illegal has has seen to create
instability in a remote TEMS including crashes.

Recovery plan: Work with IBM Support to eliminate the false
TNODELIST NODETYPE=V object.
--------------------------------------------------------------

DATAHEALTH1106W
Text:  Systems [$iprerr_ct] with agents that disagree on hostname

Check: TNODESAV and TNODELST check

Meaning: The hostname is always a part of the agent name.
Usually the hostname command is used but this can be configured
using the CTIRA_HOSTNAME environment variable. When there are
differences, this can prevent remote deploy from working. It
may also be a symptom of accidental duplicate agent names.

Recovery plan: Reconfigure the agents such that their agent name
includes the comparable hostname values.
--------------------------------------------------------------

DATAHEALTH1107W
Text:  Agent Operation Log Historical Data Collection can cause communications instability

Check: TSITDESC and TOBJACCL check

Meaning: Historical Data Collection for Agent Operation Log
[in the CCC Logs section] is rare. In a recent case this caused
communications instability and effective outage of a remote TEMS.
The agent(s) involved were at ITM 622 or earlier [6+ years old at
the time of this writing].

If you are seeing the symptoms of high numbers of offline agents,
and you are collecting Agent Operation Log, please turn off that
historical data collection and observe for increased stability.

In most people's opinion, that collected data is not terribly
worthwhile because the data collected is mostly for the use of
IBM Support diagnostics. The format is not publicly documented.

Recovery plan: Consider turning off historical data collection
of the CCC Logs - Agent Operation Logs.
--------------------------------------------------------------

DATAHEALTH1108W
Text:  Agent with hostaddr [hostaddr] missing the <NM>..</NM> hostname setting

Check: TNODESAV check

Meaning: In this condition, the EIF event transmitter logic
looks up the hostname based on the ip address. In one challenging
case, the ip addresses were missing in the environment. The
resulting slowdown in EIF caused a dramatic impact on TEPS, making
it almost unusable.

In the end, the ip addresses were added to the Linux /etc/hosts
file and the problem was ended.

Recovery plan: Check for such cases by doing a manual
nslookup ip_addr. If this takes a long time add the correct
entries into the /etc/hosts file or to the DNS data the system
is configured to use.
--------------------------------------------------------------

DATAHEALTH1109W
Text:  Agents [count] connected via hub TEMS when Remote TEMS are available

Check: TNODESAV/TNODELST check

Meaning: When remote TEMSes are available, agents connecting to
a hub TEMS have been seen to create instability. In one case
the agent was configured to a remote TEMS and the hub TEMS as
backup. When the remote TEMS was not available at agent startup,
the agent took the hub TEMS as its primary connection. Subsequently
the hub TEMS experienced instability and had to be recycled.

Of course this does not apply to a single hub TEMS ITM environment.

In addition it does not apply to agents which *must* connect to a
hub TEMS - TEPS, WPA and S&P.

Recovery plan: Reconfigure the agents to remote TEMSes whenever possible.
--------------------------------------------------------------

DATAHEALTH1110W
Text:  Agents [count] unable to use Remote Deploy because of OS Agent hostname conflict

Check: TNODESAV/TNODELST check

Meaning: In order to perform a remote deploy operation such as a
upgrade or even a tacmd settrace, the agent name must have a
hostname where there is a matching OS Agent with the same name.

Most often this is because there is a CTIRA_HOSTNAME and a
CTIRA_SYSTEM_NAME which has been specified unwisely.

Recovery plan: Reconfigure the agents so agent hostname match
the OS Agent hostname.
--------------------------------------------------------------

DATAHEALTH1111W
Text:  Historical UADVISORs [count] duplicate collections on table $f

Check: TSITDESC/TNODELST/TOBJACCL check

Meaning: See DATAREPORT022 explanation.

Recovery plan: Change historical data collection to avoid duplicate
historical data collection.
--------------------------------------------------------------

DATAHEALTH1112W
Text:  Situation not distributed by MSN/MSL/SitGroup

Check: TSITDESC/TNODELST/TOBJACCL/TGROUP/TGROUPI

Meaning: Situations that are AUTOSTART=*YES but have no distribution cause
excess work at the hub and remote TEMSes and should be avoided.

Recovery plan: Delete situations which are not distributed.
--------------------------------------------------------------

DATAHEALTH1113W
Text:  Correlated Situations [count] at count per hour

Check: TSITDESC

Meaning: Correlated situation can be very resource intensive
At this warning level the extra work happens at 12 an hour or
under and is unlikely to cause serious problems.

Recovery plan: Avoid correlated situations
--------------------------------------------------------------

DATAHEALTH1114E
Text:  Correlated Situations [count] at count per hour

Check: TSITDESC

Meaning: Correlated situation can be very resource intensive
At this warning level the extra work happens at over 12 per hour
and is very likely to cause serious problems.

Recovery plan: Avoid correlated situations
--------------------------------------------------------------

DATAHEALTH1115W
Text:  Remote TEMS temsnodeid with ip.spipe connections may be unstable

Check: TNODELST,TNODESAV

Meaning: This is produced when

   1) HUB tems is at ITM 630 FP7 or later
   2) Remote TEMS is at ITM 630 FP6
   3) Remote TEMS has some ip.spipe agent connections

At two sites, the agents connecting to the remote TEMS created an
unstable condition. One or more agents could not connect but
the remote TEMS was stuck trying to connect. As a result the
remote TEMS went offline at the TEMS.

Recovery plan: Upgrade the remote TEMS to ITM 630 FP7 or later
--------------------------------------------------------------

DATAHEALTH1116W
Text:  Pure situations with TTL > 15 minutes [count]

Check: TSITDESC

Meaning: See REPORT024 for details.

Recovery plan: Edit Pure Situations and make *TTL a small-ish time.
--------------------------------------------------------------

DATAREPORT001
Text: Summary of TEMS/TEPS/FTO etc

Sample Report
Hub,HUB_girsm03x,3360
TEMS,HUB_girsm03x,333,Online,06.30.07,aix536,<IP.SPIPE>#141.171.252.32[3660]</IP.SPIPE>
TEMS,REMOTE_gsrsm01x,75,Online,06.30.07,aix536,<IP.SPIPE>#195.75.20.30[3660]</IP.SPIPE>

Meaning: A high level summary of TEMS and TEPS and FTO.

Recovery plan: Use to get overview of environment.
--------------------------------------------------------------

DATAREPORT002
Text: Top 20 most recently added or changed Situations

Sample Report
LSTDATE,Situation,Formula
="1180507145438000",K08_GSMA_Linux_OS_Status_Warn,*IF *VALUE K08_RESOURCESTATUS.RC *EQ 2,

Meaning: Sometimes knowing the most recent situations added will point out performance
problem cases.

Recovery plan: Use to get overview of environment.
--------------------------------------------------------------

DATAREPORT003
Text: TEMA Deficit Report Summary - 132 TEMA APARs to latest maintenance ITM 630 FP6

Sample Report
3242,Agents with TEMA,
119,Agents with TEMA version same as TEMS version,
3123,Agents with TEMA version lower than TEMS version,

Meaning: This report records how far behind in maintenance the agents are.

Recovery plan: Keep agents and central services up to date.
--------------------------------------------------------------

DATAREPORT004
Text: Product Summary Report

Sample Report
Product[Agent],Count,Versions,TEMAs,Name,
01,1,Versions[01.00.00.00(1)],TEMAs[06.30.05(1)],INFOs[Win2008~6.1-SP1(1)],Agent-Builder-01,
06,612,Versions[02.10.00.00(1) 02.20.00.07(400) 02.30.00.08(158) 03.01.00.00(1) 03.01.00.05(47) 03.10.00.00(5)],TEMAs[06.23.03(1) 06.30.00(2) 06.30.04(428) 06.30.05(181)],INFOs[Win2003~5.2-SP2(11) Win2008~6.0-SP2(13) Win2008~6.1-SP1(312) Windows~6.2(276)],Monitoring Agent for GSMA BlueCARE Windows OS,
07,341,Versions[01.10.00.00(1) 02.20.00.05(3) 02.31.00.05(203) 02.50.00.07(21) 03.00.00.00(43) 03.01.00.00(1) 03.10.00.00(22) 03.11.00.00(7) 03.12.00.00(40)],TEMAs[06.23.02(1) 06.30.00(2) 06.30.04(16) 06.30.05(289) 06.30.07(33)],INFOs[AIX~5.3(1) AIX~6.1(34) AIX~7.1(296) AIX~7.2(10)],Monitoring Agent for GSMA BlueCARE AIX OS,

Meaning: This report records what agents are discovred product version and TEMA version are
being used.

Recovery plan: Increase awareness of what agents are running.
--------------------------------------------------------------

DATAREPORT005
Text: Flapper Situation Report

Sample Report
[to be added]

Meaning: Note what situations are opening and closing a lot.
This could be a signal of a bad situation - one not really
very useful or other conditions such as duplicate agents.

Recovery plan: Study such cases and justify that the situation
should be running.
--------------------------------------------------------------

DATAREPORT006
Text: Pure Situations with DisplayItems Report

Sample Report
[to be added]

Meaning: Pure situations with DisplayItems can create
storage growth issues at the remote TEMS [or any TEMS
the agent connects to.]

Recovery plan: Study such cases and justify that the situation
needs to be running with DisplayItem configured.
--------------------------------------------------------------

DATAREPORT007
Text: End of Service TEMAs

Sample Report
Node,Maint,Type,Date
Primary:ams_ams2kwa01as:KYNA,06.22.02,EOS,04/28/2018,ip.spipe:#10.7.49.35[20045]<NM>ams_ams2kwa01as</NM>,
Primary:ams_ams3kwa01as:KYNA,06.22.02,EOS,04/28/2018,ip.spipe:#10.7.50.231[15949]<NM>ams_ams3kwa01as</NM>,

Meaning: Products go through End of Service and this report
tells what agents and TEMS in the environment are at
End of Service [EOS] or Future End of Service [FEOS].

IBM will give a best efforts in this cases, however deep support
will not be available including APARs and fixes. It is possible
to purchase extended support contracts.

Recovery plan: Keep agents and TEMS within supported
service levels.
--------------------------------------------------------------

DATAREPORT008
Text: Maximum Top 20 agents showing online status more than count times - the most common number

Sample Report
OnlineCount,Node,ThrunodeCount,Thrunodes
42,ams_ams4dwh11ls:LZ,2,*LINUX_SYSTEM:REMOTE_tivgwlmh1,
8,ams_os1_tu_int:LZ,3,*LINUX_SYSTEM:REMOTE_tivgwlmh1:REMOTE_tivgwodc1,

Meaning: Agents which repeatedly go online are abnormal. The most
common reason is duplicate agent names. Another cause is agent
mal-configuration.

Recovery plan: Investigate such cases and correct the agent
configurations.
--------------------------------------------------------------

DATAREPORT009
Text: Top 20 Situation Event Report

Sample Report
Situation,Count,Open,Close,NodeCount,Interval,Atomize,Rate,Nodes
all_evtlog_gnt3_win_logret_v2,1204,1204,0,1,0,Unable to log events to security log:,20.33,vig_s-flo-vm-020:NT|REMOTE_tivgwlmh1;,
all_logscrp_g06w_win,379,373,6,379,540,N/A,24.04,acs_zigchan01:06|REMOTE_sibwi070;ams_ams0adm01ws:06|REMOTE_tivgwlmh1;ams_ams0adm11ws:06|REMOTE_tivgwlmh1;,

Meaning: When situation events arise at a rapid rate, this
often indicates a problem situation. Situation events
should be Rare, Exceptional, Fixable, and being fixed. If
some situation event appears overy often that usually rules
it out from Rare and Exceptional.

Recovery plan: Investigate such situation and justify why they
need to be running.
--------------------------------------------------------------

DATAREPORT010
Text: TEMS Situation Load Impact Report

Sample Report
Hub,HUB_girsm03x,3360
,TEMSnodeid,Count,Status,Version,Arch,SampSit,SampLoad/min,PureSit,DDSampSit,DDSampLoad/min,DDPureSit,Max1,Max1_ct,Max5,Max5_ct,DDMax1,DDMax1_ct,DDMax5,DDMax5_ct,
TEMS,HUB_girsm03x,333,Online,06.30.07,aix536,287,69.33,112,250,64.00,107,276,0,403,1,247,1,370,1
TEMS,REMOTE_gsrsm01x,75,Online,06.30.07,aix536,219,38.05,36,169,29.91,35,213,0,233,1,166,1,182,1

Meaning: ITM environments have been seen where too many situations
are running. The extreme case is when a situation is given to
each agent separately instead of distributed via MSL. In that
case the TEMS dataserver SQL can be loaded down and cause
extreme TEMS throughput issues.

Recovery plan: Use MSLs to distribute situations.
--------------------------------------------------------------

DATAREPORT011
Text: TEMA Agent(s) at APAR IZ76410 risk [could be connected to two TEMS at same time

Sample Report
Agent,Hostaddr,TEMAver,
Primary:ams_ams2kwa01as:KYNA,ip.spipe:#10.7.49.35[20045]<NM>ams_ams2kwa01as</NM>,06.22.02,
Primary:ams_ams3kwa01as:KYNA,ip.spipe:#10.7.50.231[15949]<NM>ams_ams3kwa01as</NM>,06.22.02,

Meaning: TEMA in the range ITM 621 before FP3 and ITM 622 before
FP3 had a severe defect whereby an agent could be connected to
two remote TEMS at the same time. This would occur following a
switch to secondary remote TEMS and an automatic switch back.
The issues were many including situations running multiple
times, Agent crashes, no situations running and many more.

Recovery plan:   Upgrade OS Agent to levels past the danger zone.
Alternatively only configure agent to a single remote TEMS.
--------------------------------------------------------------

DATAREPORT012
Text: TEMA Agent(s) in APAR IV18016 danger zone [Agent high CPU with embedded situations]

Sample Report
Agent,Hostaddr,TEMAver,
ams_ams4dwh11ls:12,ip.spipe:#10.7.50.40[7757]<NM>ams_ams4dwh11ls</NM>,06.23.01,
ams_ibmpsmtp1:LZ,ip.spipe:#10.72.41.4[7757]<NM>ams_ibmpsmtp1</NM>,06.23.01,

Meaning: TEMA at ITM 622 FP7 and ITM 623 FP1 have a risk of
looping during TEMS connection. This occurs sometimes when
embedded situations are in the situation formula. The result
is high agent CPU until the agent is recycled.

Recovery plan:   Upgrade OS Agent to levels past the danger zone.
--------------------------------------------------------------

DATAREPORT013
Text: TEMA Agent(s) in APAR IV30473 danger zone [KDEB_INTERFACELIST conflicts]

Sample Report
Agent,Hostaddr,TEMAver,
ams_ams4dwh11ls:12,ip.spipe:#10.7.50.40[7757]<NM>ams_ams4dwh11ls</NM>,06.23.01,
ams_dwh-dbms:08,ip.spipe:#10.7.48.177[15949]<NM>ams_dwh-dbms</NM>,06.23.02,

Meaning: At ITM maintenance levels 622 FP7-FP7 and 623 GA-FP2
a defect was present which cause problems using the
KDEB_INTERFACELIST and KDEB_INTERFACELIST_IPV6 controls.

Anytime these are present and used to force exclusive bind

KDEB_INTERFACELIST=!xxx.xxx.xxx

that usage must be coordinated for all ITM processes. For
example all processes must use exclusive bind OR all processes
must use non-exclusive bind. If usage is accidentally mixed
severe problems are caused which cause TEMS disruption and
lack of monitoring.

This has always been true, and is true at the latest levels.

At the problematic maintenance levels, changes were introduced
which would create exclusive binds when not intended. For example

KDEB_INTERFACELIST=xxx.xxx.xxx

would be treated exactly like

KDEB_INTERFACELIST=!xxx.xxx.xxx

Thus you could get severe problems without indending them.

Recovery plan: Review the ITM processes to see if that environment
variable is being used at the agents. If not you can ignore the
issue. If so you have choices:

Best practice is to upgrade the OS Agent to a
more recent level to avoid the issue.

If that is impossible update the uses of KDEB_INTERFACELIST so
they are coordinated amoung all uses... all exclusive or all
non-exclusive.
--------------------------------------------------------------

DATAREPORT014
Text: Systems with Multiple TEMA levels

Sample Report
IP_Address,Agent,TEMAver,TEMAarch,
#10.132.57.4,afisd:hpv_deehqap020hatxm:UD,06.30.05.00,aix526,
#10.132.57.4,dwhp:hpv_deehqap020hatxm:UD,06.30.00.00,aix523,

Meaning: An agent package consists of a TEMA [knows how to
contact the TEMS, runs situations, etc] and a data collection
process to gather the defined attribute groups. If a single
system is using multiple TEMA levels, that means some known
problems are not fixed. In the example above there are two
UD agents, they are at different levels. The apparent reason
here is that one is 64 bit and one is 32 bit.

Recovery: Review such cases and if upgrade agents to make
sure the maximum number of APAR fixes are present.
--------------------------------------------------------------

DATAREPORT015
Text: Multiple hostname report

Sample Report
IP_Address,Hostname,Agents,
#10.210.112.14,srt_srtchfsclus00,(srt_srtchfsclus00:Q5 )
#10.210.112.14,srt_srtchvws0005,(srt_srtchvws0005:06 srt_srtchvws0005:NT )

Meaning: An agent name by default uses the local system hostname.
However using CTIRA_HOSTNAME and CTIRA_SYSTEM_NAME this can
be changed. When there are agents on the same system which
report under different hostname, this is sometimes an error
and almost always leads to confusion.

In the example report one agent srt_srtchfsclus00:Q5 implies
a hostname of srt_srtchfsclus00 and two other agents imply
a hostname of srt_srtchvws0005.

Recovery: Review such cases and if possible configure all
agents to represent the same hostname. This is mainly to
avoid confusion but sometimes results in duplicate agent
name cases.
--------------------------------------------------------------

DATAREPORT016
Text: TEMS Offline Reports

Sample Report
Offline by Thrunode
Thrunode,Count,
REMOTE_sibwi070,2,

Meaning: This report section shows how offline agents are
found in multiple slices

Offline by Thrunode
Offline by Product
Offline by Product-Version
Offline by TEMA
Offline by Agents

Recovery: Review these and see if there is a pattern. Perhaps
some agents need to be upgraded to avoid known problems.
--------------------------------------------------------------

DATAREPORT017
Text: MS_Offline-type Situation Report

Sample Report
Sitname,Eval/hour,Eval%,kds/sec,kds%,SITMON/sec,SITMON%,Notes,
MS_Offline,12.00,33.33%,11.21,33.33%,11.21,49.99%,Persist=6 >1;,
Primary_Offline,12.00,33.33%,11.21,33.33%,11.21,49.99%,Persist=12 >1;,

Meaning: MS_Offline type situations can be seriously impactful
to hub TEMS performance. See this document which explains
many of the powerful yet dangerous aspects:

Sitworld: MS_Offline: Myth and Reality
https://www.ibm.com/developerworks/community/blogs/jalvord/entry/ms_offline_myth_and_reality?lang=en

Recovery: Minimze the use of MS_Offline type situations, especially
those with Persist>1.
--------------------------------------------------------------

DATAREPORT018
Text: Agents online to hub TEMS

Sample Report
Node,Product,
BRIODB:ibu_busapp02blu:UD,UD,
IBMATADM:iat_ibmatadm:VM,VM,

Meaning: In large environments only a minimum of agents
should be directly connected to the hub TEMS. This report
tells what agents are connected.

Recovery: Minimze the number of agents that connect directly
to the hub TEMS.
--------------------------------------------------------------

DATAREPORT019
Text: Normal Agents online to hub TEMS

Sample Report
Node,Product,
iat_tivgwlmh1:Warehouse,HD,
iat_tivgwodc1:Warehouse,HD,
ibm_girsm01x:SY,SY,

Meaning: These are the agents that should be connected to
the hub TEMS.

Recovery: Better view of environment
--------------------------------------------------------------

DATAREPORT020
Text: Virtual Hub Table impact by TEMS

Sample Report
TEMS,Nodes,Hour,Peak_Second,Details,
HUB_us98fam030wlpxa,0,0,0,,
REMOTE_va10plvapp302,21,2520,84,[OQ/21/2520/84],
REMOTE_va10plvtem022,37,4440,148,[OQ/37/4440/148],

Meaning: See DATAHEALTH1018W advisory explanation above . This
report shows which TEMSes are most heavily impacted. The remote
TEMS get impacted and this followed by a hub TEMS impact.

The details represent

Poduct Code
Number of Agents
Virtual Hub Table updates per hour
Virtual Hub Table peak updates in a single second

Recovery: Follow the recovery action documented here
https://ibm.biz/BdRW3z.
--------------------------------------------------------------

DATAREPORT021
Text: Agents unable to use Remote Deploy because of OS Agent hostname conflict

Sample Report
Agent,Agent_Hostname,OS_Hostname,IP_Addr,OS_Agent,
MSSQLSERVER:aia_id_cgkdcpwscm01a,MSSQLSERVER,aia_id_cgkdcpwscm01a,#9.9.9.9,aia_id_cgkdcpwscm01a:NT,
Primary:aia_cgkdcplcase01a:KYJA,aia_cgkdcplcase01a,aia_id_cgkdcplcase01a,#9.9.9.8,aia_id_cgkdcplcase01a:LZ,
MSSQLSERVER:aia_shadcpwscl01n2:M,aia_shadcpwscl01n2,aia_cn_shadcpwscl01n2,#9.9.9.7,aia_cn_shadcpwscl01n2:NT,

Meaning: See DATAHEALTH1110W advisory explanation above . This
report shows which agents are unable to use remote deploy functions.

Recovery: Reconfigure the agents so the hostname matches the
OS Agent hostname.
--------------------------------------------------------------

DATAREPORT022
Text: Agents experiencing duplicate historical data collection

Sample Report
DATAREPORT022: Agents experiencing duplicate historical data collection
Node,Type/Target/Situation/Table,
bl58lp3:LZ,MSL|*LINUX_SYSTEM|Linux_test_disk1|KLZ.KLZDISK|Linux_one.
bl58lp3:LZ,TEMS|REM_NMP183|Linux_test_disk|KLZ.KLZDISK,
nmp180:LZ,MSL|*LINUX_SYSTEM|Linux_test_disk1|KLZ.KLZDISK|Linux_one,
nmp180:LZ,TEMS|HUB_NMP180|Linux_test_disk|KLZ.KLZDISK,

Meaning: If agents appear in multiple definitions for
historical data collection, data will be collected multiple
times which at best leads to confusion.

The duplication can occur at

NODE - distributed directly to node
MSL - distributed via MSL to this node
TEMS - Distributed via TEMS distribution to this node

For TEMS distribution, you will see a large number of
duplicate cases. In this case the request to collect
historical data is broadcast to all connected agents,
and agents that don't collect that information silently
ignore the instruction. So, you get a large number of
duplications but actually only a few collect duplicate
historical data.

Recovery: Change historial data collection so agents are
do not have duplicate historical data collection.
--------------------------------------------------------------

DATAREPORT023
Text: Correlated Situation Report

Sample Report
DATAREPORT023: Correlated Situation Report
Situation,

Meaning: See Advisories DATAHEALTH1113W and DATAHEALTH1114E.

Recovery: Avoid Correlated Situations.
--------------------------------------------------------------

DATAREPORT024
Text: Pure Situations with TTL More than 15 minutes

Sample Report
Situation,secs,ttl,
RRT_Verification_Point_Failure,3600,0:00:60:00,
bic_b1meini_gqbw_msbz,86400,1:00:00:00,
all_diaglog_gudc_db2gsma_2,259200,3:00:00:00,

Meaning: Pure situations with long Time To Live times
will remain in storage for long periods and this can
result in large than expected TEMS process space sizes.

Recovery: Change the TTL to something like 5 minutes to
avoid increasing TEMS process space sizes.
--------------------------------------------------------------
